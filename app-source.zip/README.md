# Rasputim v5.4 Cloud Lite

Edição transparente para Windows com 4 GB de RAM. O projeto usa Node.js e IA
online, sem carregar o modelo local de 9 GB.

## Segurança desta edição

- nenhum arquivo BAT, CMD, PS1 ou VBS;
- nenhuma tentativa de desativar ou contornar antivírus;
- nenhuma janela ou processo oculto;
- nenhum download ou execução automática de programas;
- servidor limitado a `127.0.0.1` por padrão;
- chaves armazenadas somente no arquivo local `.env`;
- dependências fixadas pelo `package-lock.json`.

Essas medidas reduzem os padrões que provocam alertas heurísticos, mas não é
possível garantir a decisão de toda versão futura de qualquer antivírus.

## Uso no Windows

Instale o Node.js 22 LTS pelo site oficial. Extraia o ZIP, abra a pasta, clique
na barra de endereço do Explorador, digite `cmd` e pressione Enter.

Configure uma vez:

```text
npm run configure
```

Inicie o servidor:

```text
npm start
```

Abra `http://127.0.0.1:3333` no navegador. Para encerrar, pressione `Ctrl+C`.

Diagnóstico local:

```text
npm run diagnose
```

Se as dependências precisarem ser reinstaladas:

```text
npm run install:safe
```

O modo seguro de instalação impede scripts automáticos de pacotes. Componentes
nativos opcionais, como o renderizador de certos PDFs, podem exigir instalação
normal a partir do registro oficial do npm em uma manutenção controlada.

## Recursos preservados

- chat por API compatível com OpenAI/OpenRouter;
- memória local;
- leitura de XLSX, DOCX, PDF textual, CSV, OBJ, DAE e contêineres de projeto;
- análise de orçamento e lista de materiais;
- plano de corte, cálculo de sobras e exportação Excel;
- pesquisa de mercado com Serper ou Brave;
- bloqueio de leitura de endereços locais/privados pela ferramenta web.

Nunca envie o arquivo `.env` nem capturas que mostrem suas chaves.
