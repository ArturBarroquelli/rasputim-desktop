import dns from "node:dns/promises";
import { CONFIG, configuracaoPesquisa } from "./config.js";

function hostPesquisa() {
  if (CONFIG.searchProvider === "brave") return "api.search.brave.com";
  return process.env.SERPER_API_KEY ? "google.serper.dev" : "api.search.brave.com";
}

function hostIA() {
  try { return new URL(CONFIG.aiBaseUrl).hostname; }
  catch { return "openrouter.ai"; }
}

async function testarHost(host) {
  const resultado = { host, dns: false, https: false, internet: false };
  try {
    const endereco = await dns.lookup(host);
    resultado.dns = true;
    resultado.ip = endereco.address;
  } catch (error) {
    resultado.codigo = error.code || "DNS_ERROR";
    resultado.erro = error.message;
    return resultado;
  }

  try {
    const resposta = await fetch(`https://${host}`, {
      method: "GET",
      redirect: "manual",
      signal: AbortSignal.timeout(Math.min(CONFIG.searchTimeoutMs, 8000))
    });
    resultado.https = true;
    resultado.internet = true;
    resultado.statusHttp = resposta.status;
  } catch (error) {
    resultado.codigo = error?.cause?.code || error?.code || "HTTPS_ERROR";
    resultado.erro = error.message;
  }
  return resultado;
}

export async function diagnosticarInternet() {
  const [ia, pesquisa] = await Promise.all([
    testarHost(hostIA()),
    testarHost(hostPesquisa())
  ]);
  return {
    verificadoEm: new Date().toISOString(),
    host: ia.host,
    dns: ia.dns,
    https: ia.https,
    internet: ia.internet || pesquisa.internet,
    codigo: !ia.internet && !pesquisa.internet ? (ia.codigo || pesquisa.codigo) : undefined,
    erro: !ia.internet && !pesquisa.internet ? (ia.erro || pesquisa.erro) : undefined,
    ia,
    busca: pesquisa,
    pesquisa: configuracaoPesquisa()
  };
}
