import fs from "node:fs";
import path from "node:path";

function carregarEnvLocal() {
  const arquivo = path.resolve(".env");
  if (!fs.existsSync(arquivo)) return;

  for (const linha of fs.readFileSync(arquivo, "utf8").split(/\r?\n/)) {
    const limpa = linha.trim();
    if (!limpa || limpa.startsWith("#")) continue;
    const separador = limpa.indexOf("=");
    if (separador < 1) continue;
    const chave = limpa.slice(0, separador).trim();
    let valor = limpa.slice(separador + 1).trim();
    if ((valor.startsWith('"') && valor.endsWith('"')) || (valor.startsWith("'") && valor.endsWith("'"))) {
      valor = valor.slice(1, -1);
    }
    if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(chave) && process.env[chave] === undefined) {
      process.env[chave] = valor;
    }
  }
}

carregarEnvLocal();

function inteiroAmbiente(nome, padrao, minimo, maximo) {
  const valor = Number.parseInt(process.env[nome] || "", 10);
  if (!Number.isFinite(valor)) return padrao;
  return Math.min(Math.max(valor, minimo), maximo);
}

function removerBarraFinal(valor) {
  return String(valor || "").trim().replace(/\/+$/, "");
}

const modoSolicitado = String(process.env.AI_MODE || "cloud").trim().toLowerCase();
const aiMode = modoSolicitado === "local" ? "local" : "cloud";
const aiProvider = String(aiMode === "cloud" ? (process.env.AI_PROVIDER || "openrouter") : "llama.cpp")
  .trim()
  .toLowerCase();
const aiBaseUrl = removerBarraFinal(
  aiMode === "cloud"
    ? process.env.AI_BASE_URL || "https://openrouter.ai/api/v1"
    : `${removerBarraFinal(process.env.LLAMA_BASE_URL || "http://127.0.0.1:8080")}/v1`
);
const aiModelName = String(
  aiMode === "cloud"
    ? process.env.AI_MODEL || "qwen/qwen3-14b"
    : process.env.LLAMA_MODEL_NAME || "Qwen3-14B-Q4_K_M"
).trim();
const aiApiKey = aiMode === "cloud"
  ? String(process.env.AI_API_KEY || process.env.OPENROUTER_API_KEY || "").trim()
  : "";

export const CONFIG = Object.freeze({
  port: inteiroAmbiente("PORT", 3333, 1, 65535),
  allowedOrigin: process.env.ALLOWED_ORIGIN || "",
  aiMode,
  aiProvider,
  aiBaseUrl,
  aiModelName,
  aiApiKey,
  aiSiteUrl: String(process.env.AI_SITE_URL || "http://127.0.0.1:3333").trim(),
  aiAppName: String(process.env.AI_APP_NAME || "Rasputim Cloud Lite").trim(),
  aiTimeoutMs: inteiroAmbiente("AI_TIMEOUT_MS", inteiroAmbiente("LLAMA_TIMEOUT_MS", 180000, 5000, 600000), 5000, 600000),
  chatMaxTokens: inteiroAmbiente("CHAT_MAX_TOKENS", 900, 128, 8192),
  researchMaxTokens: inteiroAmbiente("RESEARCH_MAX_TOKENS", 1800, 256, 16384),
  searchProvider: String(process.env.SEARCH_PROVIDER || "auto").toLowerCase(),
  searchMaxResults: inteiroAmbiente("SEARCH_MAX_RESULTS", 5, 1, 10),
  searchMaxPages: inteiroAmbiente("SEARCH_MAX_PAGES", 3, 0, 5),
  searchPageChars: inteiroAmbiente("SEARCH_PAGE_CHARS", 6000, 1000, 15000),
  searchTimeoutMs: inteiroAmbiente("SEARCH_TIMEOUT_MS", 15000, 3000, 60000),
  dataDir: "./dados",
  researchDir: "./dados/pesquisas",
  budgetsDir: "./orcamentos"
});

export function configuracaoIA() {
  return {
    modo: CONFIG.aiMode,
    provedor: CONFIG.aiProvider,
    modelo: CONFIG.aiModelName,
    configurado: CONFIG.aiMode === "local" || Boolean(CONFIG.aiApiKey),
    endereco: CONFIG.aiBaseUrl
  };
}

export function configuracaoPesquisa() {
  return {
    providerPreferido: CONFIG.searchProvider,
    serperConfigurado: Boolean(process.env.SERPER_API_KEY),
    braveConfigurado: Boolean(process.env.BRAVE_API_KEY),
    maxResultados: CONFIG.searchMaxResults,
    maxPaginas: CONFIG.searchMaxPages,
    timeoutMs: CONFIG.searchTimeoutMs
  };
}
