import fs from "node:fs/promises";
import path from "node:path";
import { CONFIG } from "./config.js";
import { AppError } from "./errors.js";
import { nomeSeguro } from "./utils.js";

export async function salvarPesquisa(relatorio) {
  await fs.mkdir(CONFIG.researchDir, { recursive: true });
  const id = relatorio.id || crypto.randomUUID();
  const nome = `${new Date().toISOString().slice(0, 10)}_${nomeSeguro(relatorio.consulta, "pesquisa")}_${id.slice(0, 8)}.json`;
  const arquivo = path.resolve(CONFIG.researchDir, nome);
  const dados = { ...relatorio, id };
  await fs.writeFile(arquivo, `${JSON.stringify(dados, null, 2)}\n`, "utf8");
  return { id, arquivo, nome };
}

export async function listarPesquisas(limite = 30) {
  await fs.mkdir(CONFIG.researchDir, { recursive: true });
  const nomes = (await fs.readdir(CONFIG.researchDir)).filter(nome => nome.endsWith(".json"));
  const registros = await Promise.all(nomes.map(async nome => {
    try {
      const arquivo = path.resolve(CONFIG.researchDir, nome);
      const stat = await fs.stat(arquivo);
      const dados = JSON.parse(await fs.readFile(arquivo, "utf8"));
      return {
        id: dados.id,
        consulta: dados.consulta,
        produto: dados.produto,
        regiao: dados.regiao,
        coletadoEm: dados.coletadoEm,
        ofertas: Array.isArray(dados.ofertas) ? dados.ofertas.length : 0,
        totalFontes: Array.isArray(dados.fontes) ? dados.fontes.length : 0,
        nome,
        modificadoEm: stat.mtime.toISOString()
      };
    } catch {
      return null;
    }
  }));

  return registros
    .filter(Boolean)
    .sort((a, b) => b.modificadoEm.localeCompare(a.modificadoEm))
    .slice(0, Math.min(Math.max(Number(limite) || 30, 1), 100));
}

export async function carregarPesquisa(id) {
  const registros = await listarPesquisas(100);
  const registro = registros.find(item => item.id === id || item.nome === id);
  if (!registro) throw new AppError("Pesquisa não encontrada.", { status: 404, code: "RESEARCH_NOT_FOUND" });
  return JSON.parse(await fs.readFile(path.resolve(CONFIG.researchDir, registro.nome), "utf8"));
}
