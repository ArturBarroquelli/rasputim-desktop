import fs from "node:fs";
import path from "node:path";
import readline from "node:readline/promises";
import { fileURLToPath } from "node:url";
import { stdin, stdout } from "node:process";

const raiz = path.dirname(fileURLToPath(import.meta.url));
const envPath = path.join(raiz, ".env");
const exemploPath = path.join(raiz, ".env.example");
const interfaceLeitura = readline.createInterface({ input: stdin, output: stdout });

function atualizar(linhas, nome, valor) {
  const prefixo = `${nome}=`;
  const indice = linhas.findIndex(linha => linha.toUpperCase().startsWith(prefixo.toUpperCase()));
  if (indice >= 0) linhas[indice] = `${prefixo}${valor}`;
  else linhas.push(`${prefixo}${valor}`);
}

try {
  if (!fs.existsSync(envPath)) fs.copyFileSync(exemploPath, envPath);
  const linhas = fs.readFileSync(envPath, "utf8").split(/\r?\n/);

  console.log("\nRASPUTIM v5.4 - CONFIGURACAO SEGURA\n");
  console.log("As chaves serao gravadas somente no arquivo .env desta pasta.");
  const ia = (await interfaceLeitura.question("Cole a chave do OpenRouter: ")).trim();
  const provedor = (await interfaceLeitura.question("Pesquisa: Serper (S), Brave (B) ou nenhuma (N)? ")).trim().toUpperCase();

  if (ia) {
    atualizar(linhas, "AI_MODE", "cloud");
    atualizar(linhas, "AI_PROVIDER", "openrouter");
    atualizar(linhas, "AI_BASE_URL", "https://openrouter.ai/api/v1");
    atualizar(linhas, "AI_MODEL", "qwen/qwen3-14b");
    atualizar(linhas, "AI_API_KEY", ia);
  }

  if (provedor === "S" || provedor === "B") {
    const nome = provedor === "S" ? "SERPER_API_KEY" : "BRAVE_API_KEY";
    const chave = (await interfaceLeitura.question(`Cole a chave ${provedor === "S" ? "Serper" : "Brave"}: `)).trim();
    if (chave) atualizar(linhas, nome, chave);
  }

  fs.writeFileSync(envPath, linhas.join("\n"), { encoding: "utf8", mode: 0o600 });
  console.log("\nConfiguracao salva. Execute: npm start");
} finally {
  interfaceLeitura.close();
}
