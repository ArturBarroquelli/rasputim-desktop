import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { CONFIG, configuracaoPesquisa } from "./config.js";
import { serializarErro, AppError } from "./errors.js";
import { perguntarRasputim } from "./chat-service.js";
import { diagnosticarInternet } from "./network-diagnostics.js";
import { verificarModelo } from "./llama-client.js";
import { executarPesquisaMercado } from "./market-research.js";
import { pesquisarWeb } from "./web-search.js";
import { analisarPlanilhaMateriais } from "./spreadsheet-analysis.js";
import { analisarArquivoLocal, EXTENSOES_ARQUIVO_SUPORTADAS } from "./document-analysis.js";
import { calcularPecasModuloCaixa, otimizarBarras, otimizarChapas } from "./cutting-optimizer.js";
import { carregarPesquisa, listarPesquisas } from "./research-store.js";
import { carregarMemorias, salvarMemoria } from "./memory.js";
import {
  gerarOrcamentoMoveis,
  gerarPlanilhaPlanoCorte,
  gerarPlanilhaPesquisaMercado,
  lerPlanilhaExcel
} from "./excel-orcamento.js";
import { caminhoFilhoSeguro, texto } from "./utils.js";

const HOST = "127.0.0.1";
const MAX_BODY_BYTES = 36 * 1024 * 1024;
const MAX_UPLOAD_BYTES = 24 * 1024 * 1024;
const EXTENSOES_PLANILHA = [".xlsx", ".xlsm"];
const EXTENSOES_LEITURA = [...EXTENSOES_PLANILHA, ...EXTENSOES_ARQUIVO_SUPORTADAS];

function cabecalhosCors() {
  const cabecalhos = {
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "X-Content-Type-Options": "nosniff"
  };
  if (CONFIG.allowedOrigin) cabecalhos["Access-Control-Allow-Origin"] = CONFIG.allowedOrigin;
  return cabecalhos;
}

function enviarJSON(res, status, dados) {
  res.writeHead(status, {
    ...cabecalhosCors(),
    "Content-Type": "application/json; charset=utf-8"
  });
  res.end(JSON.stringify(dados, null, 2));
}

function lerBody(req) {
  return new Promise((resolve, reject) => {
    const partes = [];
    let tamanho = 0;
    let excedeuLimite = false;

    req.on("data", parte => {
      if (excedeuLimite) return;
      tamanho += parte.length;
      if (tamanho > MAX_BODY_BYTES) {
        excedeuLimite = true;
        reject(new AppError("A requisição excedeu 36 MB.", { status: 413, code: "BODY_TOO_LARGE" }));
        return;
      }
      partes.push(parte);
    });

    req.on("end", () => {
      if (excedeuLimite) return;
      if (!partes.length) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(partes).toString("utf8")));
      } catch {
        reject(new AppError("JSON inválido.", { status: 400, code: "INVALID_JSON" }));
      }
    });
    req.on("error", reject);
  });
}

function detectarMemoria(valor) {
  const comando = texto(valor, 10000).match(/^(?:lembre|memorize|guarde|salve|aprenda)\s+(?:que\s+)?(.+)/i);
  return comando?.[1]?.trim() || null;
}

async function servirPublico(res, nome) {
  const arquivo = caminhoFilhoSeguro("./public", nome);
  const extensao = path.extname(arquivo).toLowerCase();
  const tipos = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".svg": "image/svg+xml"
  };

  try {
    const conteudo = await fs.readFile(arquivo);
    res.writeHead(200, {
      ...cabecalhosCors(),
      "Content-Type": tipos[extensao] || "application/octet-stream"
    });
    res.end(conteudo);
  } catch {
    enviarJSON(res, 404, { erro: "Arquivo não encontrado.", codigo: "FILE_NOT_FOUND" });
  }
}

async function enviarDownload(res, diretorio, nomeArquivo) {
  const arquivo = caminhoFilhoSeguro(diretorio, nomeArquivo);
  try {
    const buffer = await fs.readFile(arquivo);
    res.writeHead(200, {
      ...cabecalhosCors(),
      "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "Content-Disposition": `attachment; filename="${path.basename(arquivo).replace(/"/g, "")}"`
    });
    res.end(buffer);
  } catch {
    enviarJSON(res, 404, { erro: "Arquivo não encontrado.", codigo: "FILE_NOT_FOUND" });
  }
}

async function obterCaminhoArquivo(body, extensoes, rotulo = "arquivo") {
  if (body.caminho) {
    const caminho = path.resolve(String(body.caminho));
    if (!extensoes.includes(path.extname(caminho).toLowerCase())) {
      throw new AppError(`Formato de ${rotulo} não suportado.`, { status: 415, code: "FILE_TYPE_UNSUPPORTED" });
    }
    const estatistica = await fs.stat(caminho).catch(() => null);
    if (!estatistica?.isFile()) throw new AppError("Arquivo não encontrado.", { status: 404, code: "FILE_NOT_FOUND" });
    if (estatistica.size > MAX_UPLOAD_BYTES) {
      throw new AppError("O arquivo excede o limite de 24 MB desta edição para computadores com 4 GB de RAM.", { status: 413, code: "FILE_TOO_LARGE" });
    }
    return { caminho, temporario: false, nomeArquivo: path.basename(caminho) };
  }

  if (body.arquivoBase64) {
    const nome = path.basename(body.nomeArquivo || "arquivo");
    if (!extensoes.includes(path.extname(nome).toLowerCase())) {
      throw new AppError(`Formato de ${rotulo} não suportado.`, { status: 415, code: "FILE_TYPE_UNSUPPORTED" });
    }
    const pasta = path.resolve("./dados/uploads");
    await fs.mkdir(pasta, { recursive: true });
    const base64 = String(body.arquivoBase64).replace(/^data:.*?;base64,/, "");
    const buffer = Buffer.from(base64, "base64");
    if (!buffer.length) throw new AppError("O arquivo está vazio ou inválido.", { status: 422, code: "FILE_EMPTY" });
    if (buffer.length > MAX_UPLOAD_BYTES) {
      throw new AppError("O arquivo excede o limite de 24 MB desta edição para computadores com 4 GB de RAM.", { status: 413, code: "FILE_TOO_LARGE" });
    }
    const caminho = path.resolve(pasta, `${Date.now()}_${nome}`);
    await fs.writeFile(caminho, buffer);
    return { caminho, temporario: true, nomeArquivo: nome };
  }

  throw new AppError("Informe 'caminho' ou envie 'arquivoBase64'.", { status: 400, code: "FILE_MISSING" });
}

function obterCaminhoPlanilha(body) {
  return obterCaminhoArquivo(body, EXTENSOES_PLANILHA, "planilha");
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || "/", `http://${req.headers.host || `${HOST}:${CONFIG.port}`}`);

  try {
    if (req.method === "OPTIONS") {
      res.writeHead(204, cabecalhosCors());
      res.end();
      return;
    }

    if (req.method === "GET" && url.pathname === "/") {
      await servirPublico(res, "index.html");
      return;
    }
    if (req.method === "GET" && url.pathname === "/app.js") {
      await servirPublico(res, "app.js");
      return;
    }
    if (req.method === "GET" && url.pathname === "/style.css") {
      await servirPublico(res, "style.css");
      return;
    }

    if (req.method === "GET" && url.pathname === "/status") {
      const modelo = await verificarModelo();
      enviarJSON(res, 200, {
        status: "online",
        versao: "5.3.0",
        edicao: "Cloud Lite 4 GB",
        nome: "Rasputim",
        endereco: `http://${HOST}:${CONFIG.port}`,
        modeloEsperado: CONFIG.aiModelName,
        modelo,
        pesquisa: configuracaoPesquisa(),
        modulos: [
          "memoria_persistente",
          "chat_ia_online",
          "pesquisa_web_com_fontes",
          "pesquisa_mercado",
          "diagnostico_rede",
          "excel_leitura",
          "excel_extracao_materiais",
          "pdf_leitura_textual",
          "docx_leitura_texto_tabelas",
          "sketchup_skp_metadados",
          "modelos_3d_dae_obj_stl",
          "promob_projetos_e_listas",
          "excel_orcamentos",
          "excel_pesquisa_mercado",
          "otimizacao_chapas_2d",
          "otimizacao_barras_1d",
          "gerador_modulo_caixa"
        ]
      });
      return;
    }

    if (req.method === "GET" && url.pathname === "/health/internet") {
      const diagnostico = await diagnosticarInternet();
      enviarJSON(res, diagnostico.internet ? 200 : 503, diagnostico);
      return;
    }

    if (req.method === "GET" && url.pathname === "/health/modelo") {
      const modelo = await verificarModelo();
      enviarJSON(res, modelo.online ? 200 : 503, modelo);
      return;
    }

    if (req.method === "GET" && url.pathname.startsWith("/arquivos/")) {
      await enviarDownload(res, CONFIG.budgetsDir, decodeURIComponent(url.pathname.slice("/arquivos/".length)));
      return;
    }

    if (req.method === "GET" && url.pathname.startsWith("/orcamentos/")) {
      await enviarDownload(res, CONFIG.budgetsDir, decodeURIComponent(url.pathname.slice("/orcamentos/".length)));
      return;
    }

    if (req.method === "GET" && url.pathname === "/memorias") {
      enviarJSON(res, 200, { memorias: await carregarMemorias() });
      return;
    }

    if (req.method === "GET" && url.pathname === "/pesquisas") {
      enviarJSON(res, 200, { pesquisas: await listarPesquisas(url.searchParams.get("limite") || 30) });
      return;
    }

    if (req.method === "GET" && url.pathname.startsWith("/pesquisas/")) {
      const id = decodeURIComponent(url.pathname.slice("/pesquisas/".length));
      enviarJSON(res, 200, await carregarPesquisa(id));
      return;
    }

    if (req.method === "POST" && url.pathname === "/memorizar") {
      const body = await lerBody(req);
      const memoria = await salvarMemoria(body.conteudo, body.tipo || "memoria", body.metadados || {});
      enviarJSON(res, 201, { mensagem: "Memória salva.", memoria });
      return;
    }

    if (req.method === "POST" && url.pathname === "/pesquisar") {
      const body = await lerBody(req);
      const pesquisa = await pesquisarWeb(body.consulta, {
        limite: body.limite,
        modo: body.modo,
        provedor: body.provedor
      });
      enviarJSON(res, 200, pesquisa);
      return;
    }

    if (req.method === "POST" && url.pathname === "/pesquisa/mercado") {
      const body = await lerBody(req);
      const relatorio = await executarPesquisaMercado(body);
      let download = null;
      if (body.gerarExcel !== false) {
        const arquivo = await gerarPlanilhaPesquisaMercado(relatorio);
        download = `/arquivos/${encodeURIComponent(path.basename(arquivo))}`;
      }
      enviarJSON(res, 200, { ...relatorio, download });
      return;
    }

    if (req.method === "POST" && url.pathname === "/orcamento/moveis") {
      const dados = await lerBody(req);
      const arquivo = await gerarOrcamentoMoveis(dados);
      enviarJSON(res, 201, {
        mensagem: "Orçamento gerado.",
        download: `/arquivos/${encodeURIComponent(path.basename(arquivo))}`
      });
      return;
    }

    if (req.method === "POST" && url.pathname === "/materiais/calcular-modulo") {
      const body = await lerBody(req);
      enviarJSON(res, 200, calcularPecasModuloCaixa(body));
      return;
    }

    if (req.method === "POST" && ["/materiais/otimizar-chapas", "/otimizar/chapas"].includes(url.pathname)) {
      const body = await lerBody(req);
      const plano = otimizarChapas(body);
      let download = null;
      if (body.gerarExcel !== false) {
        const arquivo = await gerarPlanilhaPlanoCorte(plano);
        download = `/arquivos/${encodeURIComponent(path.basename(arquivo))}`;
      }
      enviarJSON(res, 200, { ...plano, download });
      return;
    }

    if (req.method === "POST" && ["/materiais/otimizar-barras", "/otimizar/barras"].includes(url.pathname)) {
      const body = await lerBody(req);
      const plano = otimizarBarras(body);
      let download = null;
      if (body.gerarExcel !== false) {
        const arquivo = await gerarPlanilhaPlanoCorte(plano);
        download = `/arquivos/${encodeURIComponent(path.basename(arquivo))}`;
      }
      enviarJSON(res, 200, { ...plano, download });
      return;
    }

    if (req.method === "POST" && ["/excel/ler", "/planilha/analisar"].includes(url.pathname)) {
      const body = await lerBody(req);
      const planilha = await obterCaminhoPlanilha(body);
      try {
        const conteudo = await lerPlanilhaExcel(planilha.caminho);
        const analise = analisarPlanilhaMateriais(conteudo);
        enviarJSON(res, 200, { tipoEntrada: "planilha", mensagem: "Planilha lida e analisada.", conteudo, analise });
      } finally {
        if (planilha.temporario) await fs.rm(planilha.caminho, { force: true });
      }
      return;
    }

    if (req.method === "POST" && ["/arquivo/analisar", "/documento/analisar"].includes(url.pathname)) {
      const body = await lerBody(req);
      const arquivo = await obterCaminhoArquivo(body, EXTENSOES_LEITURA, "arquivo");
      try {
        const extensao = path.extname(arquivo.nomeArquivo).toLowerCase();
        if (EXTENSOES_PLANILHA.includes(extensao)) {
          const conteudo = await lerPlanilhaExcel(arquivo.caminho);
          const analise = analisarPlanilhaMateriais(conteudo);
          enviarJSON(res, 200, { tipoEntrada: "planilha", mensagem: "Planilha lida e analisada.", conteudo, analise });
        } else {
          const analise = await analisarArquivoLocal(arquivo.caminho, arquivo.nomeArquivo);
          enviarJSON(res, 200, { tipoEntrada: analise.categoria, mensagem: "Arquivo lido e analisado.", analise });
        }
      } finally {
        if (arquivo.temporario) await fs.rm(arquivo.caminho, { force: true });
      }
      return;
    }

    if (req.method === "POST" && ["/perguntar", "/chat", "/api/chat"].includes(url.pathname)) {
      const body = await lerBody(req);
      const pergunta = body.pergunta || body.message || body.mensagem || body.prompt;
      const memoriaDetectada = detectarMemoria(pergunta);

      if (memoriaDetectada) {
        const memoria = await salvarMemoria(memoriaDetectada, "aprendizado_usuario");
        enviarJSON(res, 201, { resposta: `Memória salva: ${memoria.conteudo}`, memoria });
        return;
      }

      const resultado = await perguntarRasputim(pergunta, {
        usarInternet: body.usarInternet ?? "auto",
        contextoArquivo: body.contextoArquivo
      });
      enviarJSON(res, 200, resultado);
      return;
    }

    enviarJSON(res, 404, { erro: "Rota não encontrada.", codigo: "ROUTE_NOT_FOUND" });
  } catch (error) {
    console.error(`[${new Date().toISOString()}]`, error);
    enviarJSON(res, error.status || 500, serializarErro(error));
  }
});

server.listen(CONFIG.port, HOST, async () => {
  await fs.mkdir(CONFIG.dataDir, { recursive: true });
  await fs.mkdir(CONFIG.researchDir, { recursive: true });
  await fs.mkdir(CONFIG.budgetsDir, { recursive: true });
  console.log(`Rasputim v5.4 Cloud Lite: http://${HOST}:${CONFIG.port}`);
  console.log(`IA ${CONFIG.aiMode}: ${CONFIG.aiModelName} em ${CONFIG.aiBaseUrl}`);
  console.log(`Pesquisa: ${configuracaoPesquisa().serperConfigurado || configuracaoPesquisa().braveConfigurado ? "configurada" : "aguardando chave no .env"}`);
});

function encerrar() {
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on("SIGINT", encerrar);
process.on("SIGTERM", encerrar);
