import { CONFIG, configuracaoIA } from "./config.js";
import { AppError } from "./errors.js";
import { removerRaciocinio } from "./utils.js";

function timeoutSignal(ms) {
  return AbortSignal.timeout(ms);
}

export function cabecalhosIA(incluirConteudo = false) {
  const cabecalhos = {};
  if (incluirConteudo) cabecalhos["Content-Type"] = "application/json";
  if (CONFIG.aiApiKey) cabecalhos.Authorization = `Bearer ${CONFIG.aiApiKey}`;
  if (CONFIG.aiProvider === "openrouter") {
    if (CONFIG.aiSiteUrl) cabecalhos["HTTP-Referer"] = CONFIG.aiSiteUrl;
    if (CONFIG.aiAppName) cabecalhos["X-OpenRouter-Title"] = CONFIG.aiAppName;
  }
  return cabecalhos;
}

function erroHttp(status, detalhe) {
  const mensagens = {
    401: "A chave da IA online foi recusada. Execute npm run configure e confira a chave.",
    402: "A conta da IA online está sem saldo disponível.",
    403: "A conta da IA online não tem permissão para usar este modelo.",
    404: "O modelo configurado não foi encontrado no provedor online.",
    429: "O limite de uso da IA online foi atingido. Aguarde um pouco e tente novamente."
  };
  return new AppError(mensagens[status] || `O serviço de IA respondeu HTTP ${status}.`, {
    status: status === 429 ? 429 : 502,
    code: `AI_HTTP_${status}`,
    details: detalhe
  });
}

export async function chamarModelo(messages, opcoes = {}) {
  if (CONFIG.aiMode === "cloud" && !CONFIG.aiApiKey) {
    throw new AppError("A IA online ainda não foi configurada. Execute npm run configure.", {
      status: 503,
      code: "AI_NOT_CONFIGURED"
    });
  }

  const maxTokens = opcoes.maxTokens || CONFIG.chatMaxTokens;
  const corpo = {
    model: CONFIG.aiModelName,
    messages,
    temperature: opcoes.temperature ?? 0.35,
    top_p: opcoes.topP ?? 0.85,
    max_tokens: maxTokens,
    stream: false
  };

  if (opcoes.responseFormat === "json") {
    corpo.response_format = { type: "json_object" };
  }

  let resposta;
  try {
    resposta = await fetch(`${CONFIG.aiBaseUrl}/chat/completions`, {
      method: "POST",
      headers: cabecalhosIA(true),
      body: JSON.stringify(corpo),
      signal: timeoutSignal(CONFIG.aiTimeoutMs)
    });
  } catch (error) {
    throw new AppError("O serviço de IA não respondeu.", {
      status: 503,
      code: error?.name === "TimeoutError" ? "AI_TIMEOUT" : "AI_OFFLINE",
      details: { endereco: CONFIG.aiBaseUrl, causa: error?.cause?.code || error?.message }
    });
  }

  if (!resposta.ok) {
    const detalhe = (await resposta.text()).slice(0, 1000);
    throw erroHttp(resposta.status, detalhe);
  }

  const dados = await resposta.json();
  const conteudo = dados?.choices?.[0]?.message?.content;
  if (!conteudo?.trim()) {
    throw new AppError("O serviço de IA retornou uma resposta vazia.", {
      status: 502,
      code: "AI_EMPTY_RESPONSE"
    });
  }

  return removerRaciocinio(conteudo);
}

let cacheEstado = null;
let cacheAte = 0;

export async function verificarModelo({ ignorarCache = false } = {}) {
  const configuracao = configuracaoIA();
  if (!configuracao.configurado) {
    return {
      ...configuracao,
      online: false,
      erro: "AI_NOT_CONFIGURED"
    };
  }
  if (!ignorarCache && cacheEstado && Date.now() < cacheAte) return cacheEstado;

  try {
    const resposta = await fetch(`${CONFIG.aiBaseUrl}/models`, {
      headers: cabecalhosIA(false),
      signal: timeoutSignal(6000)
    });
    const dados = resposta.ok ? await resposta.json() : null;
    const modelos = dados?.data?.map(item => item.id).filter(Boolean) || [];
    cacheEstado = {
      ...configuracao,
      online: resposta.ok,
      statusHttp: resposta.status,
      modeloDisponivel: resposta.ok && (!modelos.length || modelos.includes(CONFIG.aiModelName)),
      modelos: modelos.includes(CONFIG.aiModelName) ? [CONFIG.aiModelName] : []
    };
    cacheAte = Date.now() + 60_000;
    return cacheEstado;
  } catch (error) {
    cacheEstado = {
      ...configuracao,
      online: false,
      erro: error?.cause?.code || error?.message
    };
    cacheAte = Date.now() + 10_000;
    return cacheEstado;
  }
}
