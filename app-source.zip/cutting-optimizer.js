import { AppError } from "./errors.js";
import { nomeSeguro, normalizarTexto, texto } from "./utils.js";

const MAX_PECAS_EXPANDIDAS = 1000;
const EPSILON = 0.000001;

function numero(valor, nome, { minimo = 0, maximo = 10_000_000, obrigatorio = true } = {}) {
  if ((valor == null || valor === "") && !obrigatorio) return null;
  const convertido = Number(valor);
  if (!Number.isFinite(convertido) || convertido < minimo || convertido > maximo) {
    throw new AppError(`O campo '${nome}' deve ser um número entre ${minimo} e ${maximo}.`, {
      status: 400,
      code: "CUT_INVALID_NUMBER",
      details: { campo: nome, valor }
    });
  }
  return convertido;
}

function inteiro(valor, nome, { minimo = 1, maximo = 10000 } = {}) {
  const convertido = Number(valor);
  if (!Number.isInteger(convertido) || convertido < minimo || convertido > maximo) {
    throw new AppError(`O campo '${nome}' deve ser um número inteiro entre ${minimo} e ${maximo}.`, {
      status: 400,
      code: "CUT_INVALID_INTEGER",
      details: { campo: nome, valor }
    });
  }
  return convertido;
}

function arredondar(valor, casas = 3) {
  const fator = 10 ** casas;
  return Math.round((valor + Number.EPSILON) * fator) / fator;
}

function areaM2(areaMm2) {
  return arredondar(areaMm2 / 1_000_000, 4);
}

function normalizarChapas(entrada) {
  const fontes = Array.isArray(entrada.chapas) && entrada.chapas.length
    ? entrada.chapas
    : [entrada.chapa || {
        nome: entrada.nomeChapa,
        largura: entrada.larguraChapa ?? 2750,
        altura: entrada.alturaChapa ?? 1850,
        preco: entrada.precoChapa
      }];

  return fontes.map((chapa, indice) => {
    const largura = numero(chapa.largura, `chapas[${indice}].largura`, { minimo: 1 });
    const altura = numero(chapa.altura, `chapas[${indice}].altura`, { minimo: 1 });
    return {
      id: texto(chapa.id || `CHAPA-${indice + 1}`, 80),
      nome: texto(chapa.nome || `${largura} × ${altura} mm`, 200),
      largura,
      altura,
      preco: numero(chapa.preco, `chapas[${indice}].preco`, { minimo: 0, obrigatorio: false })
    };
  });
}

function normalizarPecas2D(pecas) {
  if (!Array.isArray(pecas) || !pecas.length) {
    throw new AppError("Informe pelo menos uma peça para o plano de corte.", {
      status: 400,
      code: "CUT_PIECES_EMPTY"
    });
  }

  const expandidas = [];
  pecas.forEach((peca, indice) => {
    const largura = numero(peca.largura, `pecas[${indice}].largura`, { minimo: 1 });
    const altura = numero(peca.altura, `pecas[${indice}].altura`, { minimo: 1 });
    const quantidade = inteiro(peca.quantidade ?? 1, `pecas[${indice}].quantidade`);
    const nome = texto(peca.nome || peca.descricao || `Peça ${indice + 1}`, 300);
    const veio = ["livre", "direcional"].includes(normalizarTexto(peca.veio))
      ? normalizarTexto(peca.veio)
      : "livre";
    const permitirGiro = peca.permitirGiro !== false && veio === "livre";
    const grupoId = texto(peca.id || nomeSeguro(nome, `peca_${indice + 1}`), 100);

    if (expandidas.length + quantidade > MAX_PECAS_EXPANDIDAS) {
      throw new AppError(`O limite é de ${MAX_PECAS_EXPANDIDAS} peças por cálculo.`, {
        status: 413,
        code: "CUT_TOO_MANY_PIECES"
      });
    }

    for (let repeticao = 0; repeticao < quantidade; repeticao++) {
      expandidas.push({
        id: `${grupoId}-${repeticao + 1}`,
        grupoId,
        nome,
        largura,
        altura,
        quantidadeOriginal: quantidade,
        permitirGiro,
        veio,
        ordemOriginal: indice,
        repeticao: repeticao + 1
      });
    }
  });
  return expandidas;
}

function orientacoes(peca) {
  const valores = [{ largura: peca.largura, altura: peca.altura, girada: false }];
  if (peca.permitirGiro && Math.abs(peca.largura - peca.altura) > EPSILON) {
    valores.push({ largura: peca.altura, altura: peca.largura, girada: true });
  }
  return valores;
}

function compararTuplas(a, b) {
  const tamanho = Math.max(a.length, b.length);
  for (let i = 0; i < tamanho; i++) {
    const diferenca = (a[i] ?? 0) - (b[i] ?? 0);
    if (Math.abs(diferenca) > EPSILON) return diferenca;
  }
  return 0;
}

function scoreEncaixe(livre, orientacao, modo) {
  const sobraL = livre.largura - orientacao.largura;
  const sobraA = livre.altura - orientacao.altura;
  const areaLivre = livre.largura * livre.altura - orientacao.largura * orientacao.altura;
  const curta = Math.min(sobraL, sobraA);
  const longa = Math.max(sobraL, sobraA);
  if (modo === "lado_curto") return [curta, longa, areaLivre];
  if (modo === "lado_longo") return [longa, curta, areaLivre];
  return [areaLivre, curta, longa];
}

function escolherColocacao(chapas, peca, modoEncaixe) {
  let melhor = null;
  for (let indiceChapa = 0; indiceChapa < chapas.length; indiceChapa++) {
    const chapa = chapas[indiceChapa];
    for (let indiceLivre = 0; indiceLivre < chapa.livres.length; indiceLivre++) {
      const livre = chapa.livres[indiceLivre];
      for (const orientacao of orientacoes(peca)) {
        if (orientacao.largura > livre.largura + EPSILON || orientacao.altura > livre.altura + EPSILON) continue;
        const score = [...scoreEncaixe(livre, orientacao, modoEncaixe), indiceChapa, indiceLivre, orientacao.girada ? 1 : 0];
        if (!melhor || compararTuplas(score, melhor.score) < 0) {
          melhor = { indiceChapa, indiceLivre, livre, orientacao, score };
        }
      }
    }
  }
  return melhor;
}

function modoDivisaoEfetivo(modo, sobraL, sobraA) {
  if (modo === "vertical" || modo === "horizontal") return modo;
  if (modo === "lado_curto") return sobraL <= sobraA ? "vertical" : "horizontal";
  return sobraL >= sobraA ? "vertical" : "horizontal";
}

function retanguloValido(retangulo) {
  return retangulo.largura > EPSILON && retangulo.altura > EPSILON;
}

function aplicarColocacao(chapa, colocacao, peca, serra, modoDivisao) {
  const { livre, orientacao, indiceLivre } = colocacao;
  chapa.livres.splice(indiceLivre, 1);
  const sobraL = Math.max(0, livre.largura - orientacao.largura);
  const sobraA = Math.max(0, livre.altura - orientacao.altura);
  const folgaL = sobraL > EPSILON ? Math.min(serra, sobraL) : 0;
  const folgaA = sobraA > EPSILON ? Math.min(serra, sobraA) : 0;
  const divisao = modoDivisaoEfetivo(modoDivisao, sobraL, sobraA);
  const novos = [];

  if (divisao === "vertical") {
    novos.push({
      x: livre.x + orientacao.largura + folgaL,
      y: livre.y,
      largura: sobraL - folgaL,
      altura: livre.altura
    });
    novos.push({
      x: livre.x,
      y: livre.y + orientacao.altura + folgaA,
      largura: orientacao.largura,
      altura: sobraA - folgaA
    });
  } else {
    novos.push({
      x: livre.x,
      y: livre.y + orientacao.altura + folgaA,
      largura: livre.largura,
      altura: sobraA - folgaA
    });
    novos.push({
      x: livre.x + orientacao.largura + folgaL,
      y: livre.y,
      largura: sobraL - folgaL,
      altura: orientacao.altura
    });
  }

  chapa.livres.push(...novos.filter(retanguloValido));
  chapa.pecas.push({
    id: peca.id,
    grupoId: peca.grupoId,
    nome: peca.nome,
    x: arredondar(livre.x),
    y: arredondar(livre.y),
    largura: orientacao.largura,
    altura: orientacao.altura,
    larguraOriginal: peca.largura,
    alturaOriginal: peca.altura,
    girada: orientacao.girada,
    veio: peca.veio
  });
  chapa.cortesEstimados += (sobraL > EPSILON ? 1 : 0) + (sobraA > EPSILON ? 1 : 0);
}

function comparadorPecas(modo) {
  const valor = peca => {
    if (modo === "lado_maior") return Math.max(peca.largura, peca.altura);
    if (modo === "largura") return peca.largura;
    if (modo === "altura") return peca.altura;
    if (modo === "perimetro") return 2 * (peca.largura + peca.altura);
    return peca.largura * peca.altura;
  };
  return (a, b) => valor(b) - valor(a) || Math.max(b.largura, b.altura) - Math.max(a.largura, a.altura) || a.id.localeCompare(b.id);
}

function novaChapa(indice, estoque, refilo) {
  return {
    indice,
    largura: estoque.largura,
    altura: estoque.altura,
    pecas: [],
    livres: [{
      x: refilo,
      y: refilo,
      largura: estoque.largura - 2 * refilo,
      altura: estoque.altura - 2 * refilo
    }],
    cortesEstimados: 0
  };
}

function validarPecasCabem(pecas, estoque, refilo) {
  const utilL = estoque.largura - 2 * refilo;
  const utilA = estoque.altura - 2 * refilo;
  if (utilL <= 0 || utilA <= 0) {
    throw new AppError("O refilo deixa a chapa sem área útil.", { status: 400, code: "CUT_TRIM_TOO_LARGE" });
  }
  const invalidas = pecas.filter(peca => !orientacoes(peca).some(o => o.largura <= utilL + EPSILON && o.altura <= utilA + EPSILON));
  if (invalidas.length) {
    throw new AppError(`${invalidas.length} peça(s) não cabem na chapa '${estoque.nome}'.`, {
      status: 422,
      code: "CUT_PIECE_TOO_LARGE",
      details: invalidas.slice(0, 20).map(peca => ({ nome: peca.nome, largura: peca.largura, altura: peca.altura, permitirGiro: peca.permitirGiro }))
    });
  }
}

function executarEstrategia2D(pecasOriginais, estoque, parametros, estrategia) {
  validarPecasCabem(pecasOriginais, estoque, parametros.refilo);
  const pecas = [...pecasOriginais].sort(comparadorPecas(estrategia.ordem));
  const chapas = [];

  for (const peca of pecas) {
    let colocacao = escolherColocacao(chapas, peca, estrategia.encaixe);
    if (!colocacao) {
      chapas.push(novaChapa(chapas.length + 1, estoque, parametros.refilo));
      colocacao = escolherColocacao(chapas.slice(-1), peca, estrategia.encaixe);
      if (colocacao) colocacao.indiceChapa = chapas.length - 1;
    }
    if (!colocacao) throw new Error(`Falha interna ao posicionar ${peca.nome}.`);
    aplicarColocacao(chapas[colocacao.indiceChapa], colocacao, peca, parametros.serra, estrategia.divisao);
  }

  const areaPecas = pecas.reduce((soma, peca) => soma + peca.largura * peca.altura, 0);
  const areaComprada = chapas.length * estoque.largura * estoque.altura;
  const areaUtilPorChapa = (estoque.largura - 2 * parametros.refilo) * (estoque.altura - 2 * parametros.refilo);
  const areaLivre = chapas.reduce((soma, chapa) => soma + chapa.livres.reduce((subtotal, livre) => subtotal + livre.largura * livre.altura, 0), 0);
  const sobrasReutilizaveis = chapas.flatMap(chapa => chapa.livres
    .filter(livre => Math.min(livre.largura, livre.altura) >= Math.min(parametros.sobraMinLargura, parametros.sobraMinAltura) &&
      Math.max(livre.largura, livre.altura) >= Math.max(parametros.sobraMinLargura, parametros.sobraMinAltura))
    .map((livre, indice) => ({ chapa: chapa.indice, id: `S${chapa.indice}-${indice + 1}`, ...livre, areaM2: areaM2(livre.largura * livre.altura) })));
  const areaReutilizavel = sobrasReutilizaveis.reduce((soma, sobra) => soma + sobra.largura * sobra.altura, 0);
  const perdaTecnica = Math.max(0, areaComprada - areaPecas - areaLivre);

  return {
    estoque,
    estrategia,
    quantidadeChapas: chapas.length,
    chapas,
    sobrasReutilizaveis,
    metricas: {
      areaPecasM2: areaM2(areaPecas),
      areaCompradaM2: areaM2(areaComprada),
      areaUtilDisponivelM2: areaM2(areaUtilPorChapa * chapas.length),
      areaLivreM2: areaM2(areaLivre),
      areaReutilizavelM2: areaM2(areaReutilizavel),
      perdaTotalM2: areaM2(areaComprada - areaPecas),
      perdaTecnicaM2: areaM2(perdaTecnica),
      aproveitamentoPercentual: arredondar(areaPecas / areaComprada * 100, 2),
      aproveitamentoAreaUtilPercentual: arredondar(areaPecas / (areaUtilPorChapa * chapas.length) * 100, 2),
      cortesEstimados: chapas.reduce((soma, chapa) => soma + chapa.cortesEstimados, 0),
      custoTotal: estoque.preco == null ? null : arredondar(estoque.preco * chapas.length, 2),
      custoPorM2Util: estoque.preco == null ? null : arredondar(estoque.preco * chapas.length / (areaPecas / 1_000_000), 2)
    }
  };
}

function melhorSolucaoMesmoEstoque(solucoes) {
  return solucoes.sort((a, b) => compararTuplas([
    a.quantidadeChapas,
    a.metricas.perdaTecnicaM2,
    -a.metricas.areaReutilizavelM2,
    a.sobrasReutilizaveis.length
  ], [
    b.quantidadeChapas,
    b.metricas.perdaTecnicaM2,
    -b.metricas.areaReutilizavelM2,
    b.sobrasReutilizaveis.length
  ]))[0];
}

function resumoAlternativa(solucao) {
  return {
    chapa: solucao.estoque,
    quantidadeChapas: solucao.quantidadeChapas,
    custoTotal: solucao.metricas.custoTotal,
    areaCompradaM2: solucao.metricas.areaCompradaM2,
    perdaTotalM2: solucao.metricas.perdaTotalM2,
    aproveitamentoPercentual: solucao.metricas.aproveitamentoPercentual
  };
}

export function otimizarChapas(entrada = {}) {
  const pecas = normalizarPecas2D(entrada.pecas);
  const estoques = normalizarChapas(entrada);
  const parametros = {
    serra: numero(entrada.serra ?? entrada.espessuraCorte ?? 3, "serra", { minimo: 0, maximo: 30 }),
    refilo: numero(entrada.refilo ?? entrada.margem ?? 10, "refilo", { minimo: 0, maximo: 200 }),
    sobraMinLargura: numero(entrada.sobraMinima?.largura ?? entrada.sobraMinLargura ?? 150, "sobraMinima.largura", { minimo: 0 }),
    sobraMinAltura: numero(entrada.sobraMinima?.altura ?? entrada.sobraMinAltura ?? 150, "sobraMinima.altura", { minimo: 0 })
  };
  const estrategias = [];
  for (const ordem of ["area", "lado_maior", "largura", "altura", "perimetro"]) {
    for (const encaixe of ["area", "lado_curto", "lado_longo"]) {
      for (const divisao of ["vertical", "horizontal", "lado_curto", "lado_longo"]) {
        estrategias.push({ ordem, encaixe, divisao });
      }
    }
  }

  const solucoes = [];
  const alternativasInvalidas = [];
  for (const estoque of estoques) {
    try {
      const tentativas = estrategias.map(estrategia => executarEstrategia2D(pecas, estoque, parametros, estrategia));
      solucoes.push(melhorSolucaoMesmoEstoque(tentativas));
    } catch (error) {
      if (error instanceof AppError && error.code === "CUT_PIECE_TOO_LARGE") {
        alternativasInvalidas.push({ chapa: estoque, erro: error.message, detalhes: error.details });
        continue;
      }
      throw error;
    }
  }

  if (!solucoes.length) {
    throw new AppError("Nenhuma das chapas informadas comporta todas as peças.", {
      status: 422,
      code: "CUT_NO_STOCK_FITS",
      details: alternativasInvalidas
    });
  }

  const objetivoSolicitado = normalizarTexto(entrada.objetivo);
  const objetivo = objetivoSolicitado === "desperdicio" || objetivoSolicitado === "menor desperdicio"
    ? "desperdicio"
    : solucoes.every(solucao => solucao.estoque.preco != null) ? "custo" : "desperdicio";
  solucoes.sort((a, b) => objetivo === "custo"
    ? compararTuplas([a.metricas.custoTotal, a.metricas.perdaTotalM2, a.quantidadeChapas], [b.metricas.custoTotal, b.metricas.perdaTotalM2, b.quantidadeChapas])
    : compararTuplas([a.metricas.perdaTotalM2, a.metricas.custoTotal ?? Infinity, a.quantidadeChapas], [b.metricas.perdaTotalM2, b.metricas.custoTotal ?? Infinity, b.quantidadeChapas]));

  const melhor = solucoes[0];
  return {
    tipo: "otimizacao_chapas_2d",
    calculadoEm: new Date().toISOString(),
    material: texto(entrada.material || entrada.nomeMaterial || "Material em chapa", 300),
    unidade: "mm",
    objetivo,
    parametros,
    quantidadePecas: pecas.length,
    gruposPecas: Array.isArray(entrada.pecas) ? entrada.pecas.length : 0,
    compra: {
      chapa: melhor.estoque,
      quantidade: melhor.quantidadeChapas,
      custoTotal: melhor.metricas.custoTotal
    },
    metricas: melhor.metricas,
    chapas: melhor.chapas,
    sobrasReutilizaveis: melhor.sobrasReutilizaveis,
    alternativas: solucoes.map(resumoAlternativa),
    alternativasInvalidas,
    alertas: [
      "O cálculo inclui refilo e espessura da serra; confira essas medidas na máquina antes do corte.",
      "O plano minimiza a perda entre as estratégias testadas, mas não garante o ótimo matemático para todo caso possível.",
      "Confirme sentido do veio, face decorativa, defeitos da chapa e sequência de corte com o profissional responsável."
    ]
  };
}

function normalizarBarras(entrada) {
  const fontes = Array.isArray(entrada.barras) && entrada.barras.length
    ? entrada.barras
    : [entrada.barra || {
        nome: entrada.nomeBarra,
        comprimento: entrada.comprimentoBarra ?? 3000,
        preco: entrada.precoBarra
      }];
  return fontes.map((barra, indice) => ({
    id: texto(barra.id || `BARRA-${indice + 1}`, 80),
    nome: texto(barra.nome || `${barra.comprimento ?? 3000} mm`, 200),
    comprimento: numero(barra.comprimento, `barras[${indice}].comprimento`, { minimo: 1 }),
    preco: numero(barra.preco, `barras[${indice}].preco`, { minimo: 0, obrigatorio: false })
  }));
}

function normalizarPecas1D(pecas) {
  if (!Array.isArray(pecas) || !pecas.length) {
    throw new AppError("Informe pelo menos uma peça linear.", { status: 400, code: "CUT_LINEAR_PIECES_EMPTY" });
  }
  const expandidas = [];
  pecas.forEach((peca, indice) => {
    const comprimento = numero(peca.comprimento, `pecas[${indice}].comprimento`, { minimo: 1 });
    const quantidade = inteiro(peca.quantidade ?? 1, `pecas[${indice}].quantidade`);
    const nome = texto(peca.nome || `Peça ${indice + 1}`, 300);
    const grupoId = texto(peca.id || nomeSeguro(nome, `peca_${indice + 1}`), 100);
    if (expandidas.length + quantidade > MAX_PECAS_EXPANDIDAS) {
      throw new AppError(`O limite é de ${MAX_PECAS_EXPANDIDAS} peças por cálculo.`, { status: 413, code: "CUT_TOO_MANY_PIECES" });
    }
    for (let i = 0; i < quantidade; i++) expandidas.push({ id: `${grupoId}-${i + 1}`, grupoId, nome, comprimento, ordemOriginal: indice });
  });
  return expandidas;
}

function executarLinear(pecasOriginais, estoque, parametros, modo) {
  const util = estoque.comprimento - 2 * parametros.refilo;
  if (util <= 0) throw new AppError("O refilo deixa a barra sem comprimento útil.", { status: 400, code: "CUT_TRIM_TOO_LARGE" });
  const grandes = pecasOriginais.filter(peca => peca.comprimento > util + EPSILON);
  if (grandes.length) {
    throw new AppError(`${grandes.length} peça(s) não cabem na barra '${estoque.nome}'.`, {
      status: 422,
      code: "CUT_PIECE_TOO_LARGE",
      details: grandes.slice(0, 20)
    });
  }

  const pecas = [...pecasOriginais].sort((a, b) => b.comprimento - a.comprimento || a.id.localeCompare(b.id));
  const barras = [];
  for (const peca of pecas) {
    const candidatas = barras.map((barra, indice) => {
      const adicional = peca.comprimento + (barra.pecas.length ? parametros.serra : 0);
      return { indice, restanteDepois: barra.restante - adicional, adicional };
    }).filter(candidata => candidata.restanteDepois >= -EPSILON);

    const candidata = modo === "primeiro"
      ? candidatas[0]
      : candidatas.sort((a, b) => a.restanteDepois - b.restanteDepois || a.indice - b.indice)[0];
    let barra;
    if (!candidata) {
      barra = { indice: barras.length + 1, comprimento: estoque.comprimento, inicioUtil: parametros.refilo, usado: 0, restante: util, pecas: [] };
      barras.push(barra);
    } else barra = barras[candidata.indice];

    const folga = barra.pecas.length ? parametros.serra : 0;
    const inicio = parametros.refilo + barra.usado + folga;
    barra.usado += folga + peca.comprimento;
    barra.restante = Math.max(0, util - barra.usado);
    barra.pecas.push({ id: peca.id, grupoId: peca.grupoId, nome: peca.nome, inicio: arredondar(inicio), comprimento: peca.comprimento });
  }

  const comprimentoPecas = pecas.reduce((soma, peca) => soma + peca.comprimento, 0);
  const comprado = barras.length * estoque.comprimento;
  const sobras = barras.map(barra => ({ barra: barra.indice, comprimento: arredondar(barra.restante) })).filter(sobra => sobra.comprimento >= parametros.sobraMinima);
  return {
    estoque,
    barras,
    quantidadeBarras: barras.length,
    sobrasReutilizaveis: sobras,
    metricas: {
      comprimentoPecasM: arredondar(comprimentoPecas / 1000, 3),
      comprimentoCompradoM: arredondar(comprado / 1000, 3),
      sobraTotalM: arredondar((comprado - comprimentoPecas) / 1000, 3),
      sobraReutilizavelM: arredondar(sobras.reduce((soma, sobra) => soma + sobra.comprimento, 0) / 1000, 3),
      aproveitamentoPercentual: arredondar(comprimentoPecas / comprado * 100, 2),
      cortesEstimados: pecas.length,
      custoTotal: estoque.preco == null ? null : arredondar(estoque.preco * barras.length, 2)
    }
  };
}

export function otimizarBarras(entrada = {}) {
  const pecas = normalizarPecas1D(entrada.pecas);
  const estoques = normalizarBarras(entrada);
  const parametros = {
    serra: numero(entrada.serra ?? entrada.espessuraCorte ?? 3, "serra", { minimo: 0, maximo: 30 }),
    refilo: numero(entrada.refilo ?? entrada.margem ?? 5, "refilo", { minimo: 0, maximo: 200 }),
    sobraMinima: numero(entrada.sobraMinima ?? 150, "sobraMinima", { minimo: 0 })
  };
  const solucoes = [];
  const alternativasInvalidas = [];
  for (const estoque of estoques) {
    try {
      const tentativas = ["melhor", "primeiro"].map(modo => executarLinear(pecas, estoque, parametros, modo));
      tentativas.sort((a, b) => compararTuplas([a.quantidadeBarras, -a.metricas.sobraReutilizavelM], [b.quantidadeBarras, -b.metricas.sobraReutilizavelM]));
      solucoes.push(tentativas[0]);
    } catch (error) {
      if (error instanceof AppError && error.code === "CUT_PIECE_TOO_LARGE") {
        alternativasInvalidas.push({ barra: estoque, erro: error.message, detalhes: error.details });
        continue;
      }
      throw error;
    }
  }
  if (!solucoes.length) throw new AppError("Nenhuma barra informada comporta todas as peças.", { status: 422, code: "CUT_NO_STOCK_FITS", details: alternativasInvalidas });

  const comPreco = solucoes.every(solucao => solucao.estoque.preco != null);
  solucoes.sort((a, b) => comPreco
    ? compararTuplas([a.metricas.custoTotal, a.metricas.sobraTotalM], [b.metricas.custoTotal, b.metricas.sobraTotalM])
    : compararTuplas([a.metricas.sobraTotalM, a.quantidadeBarras], [b.metricas.sobraTotalM, b.quantidadeBarras]));
  const melhor = solucoes[0];
  return {
    tipo: "otimizacao_barras_1d",
    calculadoEm: new Date().toISOString(),
    material: texto(entrada.material || entrada.nomeMaterial || "Material linear", 300),
    unidade: "mm",
    parametros,
    quantidadePecas: pecas.length,
    compra: { barra: melhor.estoque, quantidade: melhor.quantidadeBarras, custoTotal: melhor.metricas.custoTotal },
    metricas: melhor.metricas,
    barras: melhor.barras,
    sobrasReutilizaveis: melhor.sobrasReutilizaveis,
    alternativas: solucoes.map(solucao => ({ barra: solucao.estoque, quantidadeBarras: solucao.quantidadeBarras, ...solucao.metricas })),
    alternativasInvalidas,
    alertas: [
      "Confira a espessura real do corte e o refilo antes de produzir.",
      "O cálculo não considera emendas; cada peça precisa sair inteira de uma barra."
    ]
  };
}

export function calcularPecasModuloCaixa(entrada = {}) {
  const nome = texto(entrada.nome || entrada.modulo || "Módulo", 200);
  const largura = numero(entrada.largura ?? entrada.larguraExterna, "largura", { minimo: 1 });
  const altura = numero(entrada.altura ?? entrada.alturaExterna, "altura", { minimo: 1 });
  const profundidade = numero(entrada.profundidade, "profundidade", { minimo: 1 });
  const espessura = numero(entrada.espessura ?? 18, "espessura", { minimo: 1, maximo: 100 });
  const quantidade = inteiro(entrada.quantidade ?? 1, "quantidade", { minimo: 1, maximo: 1000 });
  const prateleiras = inteiro(entrada.prateleiras ?? 0, "prateleiras", { minimo: 0, maximo: 100 });
  const recuoPrateleira = numero(entrada.recuoPrateleira ?? 0, "recuoPrateleira", { minimo: 0, maximo: profundidade - EPSILON });
  const montagem = normalizarTexto(entrada.montagem) === "tampo sobre laterais" || normalizarTexto(entrada.montagem) === "sobre_laterais"
    ? "sobre_laterais"
    : "entre_laterais";

  const larguraInterna = largura - 2 * espessura;
  const alturaInterna = altura - 2 * espessura;
  if (larguraInterna <= 0 || alturaInterna <= 0) {
    throw new AppError("As dimensões externas precisam ser maiores que duas vezes a espessura do material.", {
      status: 400,
      code: "MODULE_DIMENSIONS_INVALID",
      details: { largura, altura, espessura }
    });
  }

  const pecas = montagem === "entre_laterais"
    ? [
        { nome: `${nome} — Lateral`, largura: altura, altura: profundidade, quantidade: 2 * quantidade, veio: "direcional", permitirGiro: false },
        { nome: `${nome} — Tampo/Base`, largura: larguraInterna, altura: profundidade, quantidade: 2 * quantidade, veio: "direcional", permitirGiro: false }
      ]
    : [
        { nome: `${nome} — Lateral`, largura: alturaInterna, altura: profundidade, quantidade: 2 * quantidade, veio: "direcional", permitirGiro: false },
        { nome: `${nome} — Tampo/Base`, largura, altura: profundidade, quantidade: 2 * quantidade, veio: "direcional", permitirGiro: false }
      ];

  if (prateleiras > 0) {
    pecas.push({
      nome: `${nome} — Prateleira`,
      largura: larguraInterna,
      altura: profundidade - recuoPrateleira,
      quantidade: prateleiras * quantidade,
      veio: "direcional",
      permitirGiro: false
    });
  }

  return {
    tipo: "modulo_caixa",
    nome,
    dimensoesExternas: { largura, altura, profundidade },
    espessura,
    quantidade,
    montagem,
    prateleiras,
    recuoPrateleira,
    dimensoesInternas: { largura: larguraInterna, altura: alturaInterna },
    pecas,
    alertas: [
      "O cálculo inclui somente caixa, tampo, base e prateleiras.",
      "Portas, frentes, fundo, travessas, folgas, fita de borda e ferragens dependem do padrão construtivo e devem ser informados separadamente.",
      "Confira a orientação de largura/altura e o sentido do veio antes de produzir."
    ]
  };
}
