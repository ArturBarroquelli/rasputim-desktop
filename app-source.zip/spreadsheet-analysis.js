import { normalizarTexto, texto } from "./utils.js";

function valorCelula(valor) {
  if (valor == null) return null;
  if (valor instanceof Date) return valor.toISOString();
  if (typeof valor !== "object") return valor;
  if ("formula" in valor) return valor.resultado ?? valor.result ?? null;
  if (Array.isArray(valor.richText)) return valor.richText.map(parte => parte.text || "").join("");
  if (valor.text != null) return valor.text;
  if (valor.error) return valor.error;
  return texto(JSON.stringify(valor), 1000);
}

function numeroCelula(valor) {
  const simples = valorCelula(valor);
  if (typeof simples === "number") return Number.isFinite(simples) ? simples : null;
  const bruto = texto(simples, 100).replace(/[^\d,.-]/g, "");
  if (!bruto) return null;
  const normalizado = bruto.includes(",") && bruto.includes(".")
    ? bruto.replace(/\./g, "").replace(",", ".")
    : bruto.replace(",", ".");
  const numero = Number(normalizado);
  return Number.isFinite(numero) ? numero : null;
}

function cabecalhoReconhecido(valor) {
  const normalizado = normalizarTexto(valor);
  if (!normalizado) return null;
  if (/^(material|materiais|produto|produtos|descricao|descrição|item)$/.test(normalizado)) return "material";
  if (/^(unid|unidade|und|un)$/.test(normalizado)) return "unidade";
  if (/^(quant|quantidade|qtd|qtde)$/.test(normalizado)) return "quantidade";
  if (/^(n|nº|no|numero|codigo|cod)$/.test(normalizado)) return "numero";
  if (/^(valor unit|valor unitario|preco unit|preco unitario|vl unit|unitario)$/.test(normalizado)) return "valorUnitario";
  if (/^(total|valor total)$/.test(normalizado)) return "total";
  return null;
}

function localizarCabecalhos(linhas) {
  const encontrados = [];
  for (const linha of linhas) {
    const colunas = {};
    linha.valores.forEach((valor, indice) => {
      const tipo = cabecalhoReconhecido(valorCelula(valor));
      if (tipo && colunas[tipo] == null) colunas[tipo] = indice;
    });
    if (colunas.material != null && (colunas.unidade != null || colunas.quantidade != null)) {
      encontrados.push({ linha: linha.linha, colunas, valores: linha.valores });
    }
  }
  return encontrados;
}

function erroFormula(valor) {
  if (!valor || typeof valor !== "object" || !("formula" in valor)) return null;
  const formula = String(valor.formula || "");
  const resultado = valor.resultado ?? valor.result;
  const resultadoErro = resultado && typeof resultado === "object" ? resultado.error : resultado;
  if (/#(?:REF|DIV\/0|VALUE|NAME\?|N\/A|NUM|NULL)!?/i.test(formula) || /^#/.test(String(resultadoErro || ""))) {
    return { formula, erro: String(resultadoErro || "erro de referência") };
  }
  return null;
}

function fornecedoresDoCabecalho(cabecalho) {
  const { colunas, valores } = cabecalho;
  const inicio = (colunas.quantidade ?? colunas.unidade ?? colunas.material) + 1;
  const fim = colunas.valorUnitario ?? colunas.total ?? valores.length;
  const fornecedores = [];
  for (let indice = inicio; indice < fim; indice++) {
    const nome = texto(valorCelula(valores[indice]), 100);
    if (nome && !cabecalhoReconhecido(nome)) fornecedores.push({ indice, nome });
  }
  return fornecedores;
}

function extrairItensAba(aba, cabecalho, proximoCabecalhoLinha) {
  const itens = [];
  const fornecedores = fornecedoresDoCabecalho(cabecalho);
  let categoria = null;
  const fim = proximoCabecalhoLinha || Number.POSITIVE_INFINITY;

  for (const linha of aba.linhas) {
    if (linha.linha <= cabecalho.linha || linha.linha >= fim) continue;
    const material = texto(valorCelula(linha.valores[cabecalho.colunas.material]), 500);
    if (!material) continue;

    const unidade = texto(valorCelula(linha.valores[cabecalho.colunas.unidade]), 80) || null;
    const quantidade = numeroCelula(linha.valores[cabecalho.colunas.quantidade]);
    const numero = texto(valorCelula(linha.valores[cabecalho.colunas.numero]), 80) || null;

    if (!unidade && quantidade == null) {
      categoria = material;
      continue;
    }

    const cotacoesExistentes = fornecedores.map(fornecedor => ({
      fornecedor: fornecedor.nome,
      valor: numeroCelula(linha.valores[fornecedor.indice])
    })).filter(cotacao => cotacao.valor != null);

    itens.push({
      id: `${normalizarTexto(aba.aba).replace(/\W+/g, "_")}_${linha.linha}`,
      aba: aba.aba,
      linha: linha.linha,
      numero,
      categoria,
      material,
      unidade,
      quantidade,
      valorUnitario: numeroCelula(linha.valores[cabecalho.colunas.valorUnitario]),
      total: numeroCelula(linha.valores[cabecalho.colunas.total]),
      cotacoesExistentes
    });
  }
  return itens;
}

export function analisarPlanilhaMateriais(conteudo = []) {
  const abas = [];
  const itens = [];
  const errosFormula = [];

  for (const aba of Array.isArray(conteudo) ? conteudo : []) {
    const cabecalhos = localizarCabecalhos(aba.linhas || []);
    const itensAba = [];
    cabecalhos.forEach((cabecalho, indice) => {
      itensAba.push(...extrairItensAba(aba, cabecalho, cabecalhos[indice + 1]?.linha));
    });

    for (const linha of aba.linhas || []) {
      linha.valores.forEach((valor, indice) => {
        const erro = erroFormula(valor);
        if (erro) errosFormula.push({ aba: aba.aba, linha: linha.linha, coluna: indice + 1, ...erro });
      });
    }

    itens.push(...itensAba);
    abas.push({
      nome: aba.aba,
      linhasPreenchidas: aba.linhas?.length || 0,
      tabelasMateriais: cabecalhos.length,
      itensMateriais: itensAba.length
    });
  }

  const quantidades = itens.filter(item => item.quantidade != null);
  const cotados = itens.filter(item => item.valorUnitario != null || item.cotacoesExistentes.length);
  return {
    tipoDetectado: itens.length ? "lista_de_materiais" : "planilha_generica",
    abas,
    itens,
    resumo: {
      totalAbas: abas.length,
      totalItens: itens.length,
      itensComQuantidade: quantidades.length,
      itensComAlgumPreco: cotados.length,
      errosFormula: errosFormula.length
    },
    errosFormula,
    alertas: [
      ...(errosFormula.length ? [`A planilha contém ${errosFormula.length} fórmula(s) com erro ou referência quebrada.`] : []),
      ...(itens.length ? [] : ["Não foi encontrada uma tabela com cabeçalhos de material e unidade/quantidade."])
    ]
  };
}
