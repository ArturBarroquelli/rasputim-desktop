import fs from "node:fs/promises";
import path from "node:path";
import { normalizarTexto, texto } from "./utils.js";

const MEMORY_FILE = path.resolve("./dados/memoria.json");
const LEGACY_MEMORY_FILE = path.resolve("./memoria.json");

async function garantirArquivo() {
  await fs.mkdir(path.dirname(MEMORY_FILE), { recursive: true });
  try {
    await fs.access(MEMORY_FILE);
  } catch {
    let memoriasAnteriores = [];
    try {
      const legado = JSON.parse(await fs.readFile(LEGACY_MEMORY_FILE, "utf8"));
      if (Array.isArray(legado)) {
        memoriasAnteriores = legado.filter(item => item?.conteudo).map(item => ({
          id: item.id || crypto.randomUUID(),
          tipo: texto(item.tipo, 80) || "memoria_v4",
          conteudo: texto(item.conteudo, 10000),
          metadados: { migradoDaVersao: 4, ...(item.metadados || {}) },
          criadoEm: item.criadoEm || new Date().toISOString()
        }));
      }
    } catch {}
    await fs.writeFile(MEMORY_FILE, `${JSON.stringify(memoriasAnteriores, null, 2)}\n`, "utf8");
  }
}

export async function carregarMemorias() {
  await garantirArquivo();
  try {
    const data = await fs.readFile(MEMORY_FILE, "utf8");
    const memorias = JSON.parse(data || "[]");
    return Array.isArray(memorias) ? memorias : [];
  } catch {
    return [];
  }
}

export async function salvarMemoria(conteudo, tipo = "geral", metadados = {}) {
  const valor = texto(conteudo, 10000);
  if (!valor) throw new Error("Não é possível salvar uma memória vazia.");

  const memorias = await carregarMemorias();
  const registro = {
    id: crypto.randomUUID(),
    tipo: texto(tipo, 80) || "geral",
    conteudo: valor,
    metadados,
    criadoEm: new Date().toISOString()
  };

  memorias.push(registro);
  const temporario = `${MEMORY_FILE}.tmp`;
  await fs.writeFile(temporario, `${JSON.stringify(memorias, null, 2)}\n`, "utf8");
  await fs.rename(temporario, MEMORY_FILE);
  return registro;
}

export async function buscarMemoriasRelevantes(pergunta, limite = 12) {
  const memorias = await carregarMemorias();
  const palavras = [...new Set(normalizarTexto(pergunta).split(/\W+/).filter(p => p.length > 3))];
  if (!palavras.length) return [];

  return memorias
    .map(memoria => {
      const conteudo = normalizarTexto(memoria?.conteudo);
      const pontuacao = palavras.reduce((soma, palavra) => soma + (conteudo.includes(palavra) ? 1 : 0), 0);
      return { memoria, pontuacao };
    })
    .filter(item => item.pontuacao > 0)
    .sort((a, b) => b.pontuacao - a.pontuacao)
    .slice(0, limite)
    .map(item => item.memoria);
}

export async function montarContextoMemoria(pergunta) {
  const todas = await carregarMemorias();
  const relevantes = await buscarMemoriasRelevantes(pergunta, 10);
  const recentes = todas.slice(-5);
  const unicas = new Map();

  for (const memoria of [...relevantes, ...recentes]) {
    if (memoria?.conteudo) unicas.set(normalizarTexto(memoria.conteudo), memoria);
  }

  const selecionadas = [...unicas.values()].slice(0, 12);
  if (!selecionadas.length) return "Nenhuma memória relevante encontrada.";
  return selecionadas.map((memoria, i) => `${i + 1}. ${memoria.conteudo}`).join("\n");
}
