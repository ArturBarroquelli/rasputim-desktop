export class AppError extends Error {
  constructor(message, { status = 500, code = "INTERNAL_ERROR", details = null } = {}) {
    super(message);
    this.name = "AppError";
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export function codigoErroRede(error) {
  return error?.cause?.code || error?.code || null;
}

export function serializarErro(error) {
  return {
    erro: error?.message || "Erro interno.",
    codigo: error?.code || codigoErroRede(error) || "INTERNAL_ERROR",
    detalhes: error?.details || undefined
  };
}
