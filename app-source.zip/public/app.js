const $ = seletor => document.querySelector(seletor);
const $$ = seletor => [...document.querySelectorAll(seletor)];

let ultimoRelatorio = null;
let ultimoArquivoLido = null;

function limpar(no) {
  while (no.firstChild) no.removeChild(no.firstChild);
}

function elemento(tag, atributos = {}, filhos = []) {
  const no = document.createElement(tag);
  for (const [chave, valor] of Object.entries(atributos)) {
    if (chave === "class") no.className = valor;
    else if (chave === "text") no.textContent = valor ?? "";
    else if (chave === "href") {
      no.href = valor;
      no.target = "_blank";
      no.rel = "noopener noreferrer";
    } else no.setAttribute(chave, valor);
  }
  for (const filho of Array.isArray(filhos) ? filhos : [filhos]) {
    if (filho) no.append(filho);
  }
  return no;
}

function dinheiro(valor) {
  return valor == null || !Number.isFinite(Number(valor))
    ? "Não confirmado"
    : new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(valor));
}

function dataHora(valor) {
  if (!valor) return "—";
  const data = new Date(valor);
  return Number.isNaN(data.getTime()) ? String(valor) : data.toLocaleString("pt-BR");
}

function mostrarErro(error) {
  const toast = $("#toast");
  toast.classList.remove("success");
  const detalhe = error?.detalhes && typeof error.detalhes === "string" ? ` — ${error.detalhes}` : "";
  toast.textContent = `${error?.erro || error?.message || "Algo deu errado."}${detalhe}`;
  toast.classList.remove("hidden");
  clearTimeout(mostrarErro.timer);
  mostrarErro.timer = setTimeout(() => toast.classList.add("hidden"), 7000);
}

async function api(caminho, opcoes = {}) {
  const resposta = await fetch(caminho, {
    ...opcoes,
    headers: { "Content-Type": "application/json", ...(opcoes.headers || {}) }
  });
  let dados;
  try { dados = await resposta.json(); } catch { dados = { erro: `Resposta HTTP ${resposta.status} inválida.` }; }
  if (!resposta.ok) throw dados;
  return dados;
}

function estadoPill(seletor, estado, texto) {
  const no = $(seletor);
  no.className = `status-pill ${estado}`;
  no.lastChild.textContent = texto;
}

async function carregarStatus() {
  try {
    const status = await api("/status");
    const iaConfigurada = status.modelo?.configurado !== false;
    estadoPill(
      "#status-modelo",
      status.modelo?.online ? "ok" : (iaConfigurada ? "error" : "warn"),
      status.modelo?.online ? "Qwen online" : (iaConfigurada ? "IA indisponível" : "Configurar IA")
    );
    const pesquisaOk = status.pesquisa?.serperConfigurado || status.pesquisa?.braveConfigurado;
    estadoPill("#status-pesquisa", pesquisaOk ? "ok" : "warn", pesquisaOk ? "Pesquisa configurada" : "Falta chave de pesquisa");
  } catch {
    estadoPill("#status-modelo", "error", "Servidor indisponível");
    estadoPill("#status-pesquisa", "error", "Servidor indisponível");
  }

  try {
    const rede = await api("/health/internet");
    estadoPill("#status-rede", rede.internet ? "ok" : "error", rede.internet ? "Internet ativa" : "Falha de rede");
  } catch (erro) {
    estadoPill("#status-rede", "error", erro.codigo === "ENOTFOUND" ? "Falha de DNS" : "Internet indisponível");
  }
}

function trocarView(nome) {
  $$(".view").forEach(view => view.classList.toggle("active", view.id === `view-${nome}`));
  $$(".nav-button").forEach(botao => botao.classList.toggle("active", botao.dataset.view === nome));
  history.replaceState(null, "", `#${nome}`);
  if (nome === "historico") carregarHistorico();
  if (nome === "diagnostico") executarDiagnostico();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function criarMetrica(rotulo, valor) {
  return elemento("div", { class: "metric" }, [
    elemento("span", { text: rotulo }),
    elemento("strong", { text: valor })
  ]);
}

function renderizarPesquisa(relatorio) {
  ultimoRelatorio = relatorio;
  $("#resultado-produto").textContent = relatorio.produto || relatorio.consulta || "Pesquisa de mercado";
  $("#resultado-resumo").textContent = relatorio.resumo || "Relatório gerado.";
  $("#resultado-data").textContent = `Coletado em ${dataHora(relatorio.coletadoEm)} · ${relatorio.provedorPesquisa || "provedor não informado"}`;

  const download = $("#download-excel");
  if (relatorio.download) {
    download.href = relatorio.download;
    download.classList.remove("hidden");
  } else download.classList.add("hidden");

  const ofertas = Array.isArray(relatorio.ofertas) ? relatorio.ofertas : [];
  const precos = ofertas.filter(o => o.preco != null).map(o => Number(o.preco)).filter(Number.isFinite);
  const metricas = $("#metricas-pesquisa");
  limpar(metricas);
  metricas.append(
    criarMetrica("Fontes", String(relatorio.fontes?.length || 0)),
    criarMetrica("Ofertas", String(ofertas.length)),
    criarMetrica("Menor preço", precos.length ? dinheiro(Math.min(...precos)) : "—"),
    criarMetrica("Região", relatorio.regiao || "Brasil")
  );

  const tbody = $("#tabela-ofertas");
  limpar(tbody);
  for (const oferta of ofertas) {
    const tr = elemento("tr", { class: oferta.fonteId === relatorio.melhorOfertaFonteId ? "best-row" : "" });
    tr.append(
      elemento("td", { text: oferta.fonteId || "—" }),
      elemento("td", {}, [
        elemento("strong", { text: oferta.fornecedor || "Fornecedor não identificado" }),
        elemento("span", { text: oferta.descricao || "" })
      ]),
      elemento("td", { class: "price", text: dinheiro(oferta.preco) }),
      elemento("td", { text: oferta.unidade || "—" }),
      elemento("td", {}, elemento("span", { class: `confidence ${oferta.confianca || "baixa"}`, text: oferta.confianca || "baixa" })),
      elemento("td", {}, oferta.url ? elemento("a", { class: "source-link", href: oferta.url, text: "Abrir fonte ↗" }) : null)
    );
    tbody.append(tr);
  }
  $("#sem-ofertas").classList.toggle("hidden", ofertas.length > 0);

  const alertas = $("#lista-alertas");
  limpar(alertas);
  const lista = relatorio.alertas?.length ? relatorio.alertas : ["Confirme preço, unidade, frete e estoque antes de comprar."];
  lista.forEach(alerta => alertas.append(elemento("li", { text: alerta })));
  $("#resultado-conclusao").textContent = relatorio.conclusao || "Consulte as fontes e confirme as condições comerciais.";

  const fontes = $("#lista-fontes");
  limpar(fontes);
  for (const fonte of relatorio.fontes || []) {
    fontes.append(elemento("article", { class: "source-card" }, [
      elemento("span", { class: "source-id", text: fonte.id || "F?" }),
      elemento("div", {}, [
        elemento("strong", { text: fonte.titulo || fonte.url || "Fonte" }),
        elemento("p", { text: fonte.resumo || fonte.conteudo?.slice(0, 280) || "Sem trecho disponível." }),
        elemento("span", { class: "source-meta", text: `${fonte.fornecedor || "Fornecedor não identificado"} · ${fonte.leitura || "resultado de busca"}` })
      ]),
      fonte.url ? elemento("a", { class: "source-link", href: fonte.url, text: "Visitar ↗" }) : null
    ]));
  }

  $("#resultado-pesquisa").classList.remove("hidden");
  $("#resultado-pesquisa").scrollIntoView({ behavior: "smooth", block: "start" });
}

function inputTabela(tipo, papel, valor = "", extras = {}) {
  return elemento("input", {
    type: tipo,
    "data-role": papel,
    value: valor ?? "",
    ...extras
  });
}

function botaoRemoverLinha(linha) {
  const botao = elemento("button", { type: "button", class: "remove-row", text: "×", title: "Remover" });
  botao.addEventListener("click", () => linha.remove());
  return botao;
}

function adicionarPecaChapa(dados = {}) {
  const linha = elemento("tr", { class: "piece-input-row" });
  const veio = elemento("select", { "data-role": "veio" }, [
    elemento("option", { value: "livre", text: "Livre — pode girar" }),
    elemento("option", { value: "direcional", text: "Direcional — não girar" })
  ]);
  veio.value = dados.veio === "direcional" || dados.permitirGiro === false ? "direcional" : "livre";
  linha.append(
    elemento("td", {}, inputTabela("text", "nome", dados.nome, { required: "", maxlength: "300", placeholder: "Ex.: Lateral" })),
    elemento("td", {}, inputTabela("number", "largura", dados.largura, { required: "", min: "1", step: "0.1", placeholder: "mm" })),
    elemento("td", {}, inputTabela("number", "altura", dados.altura, { required: "", min: "1", step: "0.1", placeholder: "mm" })),
    elemento("td", {}, inputTabela("number", "quantidade", dados.quantidade ?? 1, { required: "", min: "1", step: "1" })),
    elemento("td", {}, veio),
    elemento("td", {}, botaoRemoverLinha(linha))
  );
  $("#pecas-chapas").append(linha);
}

function adicionarPecaBarra(dados = {}) {
  const linha = elemento("tr", { class: "piece-input-row" });
  linha.append(
    elemento("td", {}, inputTabela("text", "nome", dados.nome, { required: "", maxlength: "300", placeholder: "Ex.: Cabideiro" })),
    elemento("td", {}, inputTabela("number", "comprimento", dados.comprimento, { required: "", min: "1", step: "0.1", placeholder: "mm" })),
    elemento("td", {}, inputTabela("number", "quantidade", dados.quantidade ?? 1, { required: "", min: "1", step: "1" })),
    elemento("td", {}, botaoRemoverLinha(linha))
  );
  $("#pecas-barras").append(linha);
}

function lerLinhasPecas(seletor, tipo) {
  return $$(`${seletor} tr`).map(linha => {
    const valor = papel => linha.querySelector(`[data-role="${papel}"]`)?.value;
    if (tipo === "chapas") {
      const veio = valor("veio") || "livre";
      return {
        nome: valor("nome"),
        largura: Number(valor("largura")),
        altura: Number(valor("altura")),
        quantidade: Number(valor("quantidade")),
        veio,
        permitirGiro: veio === "livre"
      };
    }
    return { nome: valor("nome"), comprimento: Number(valor("comprimento")), quantidade: Number(valor("quantidade")) };
  });
}

function corPeca(nome) {
  const paleta = ["#c99d55", "#6f9dc9", "#64a98b", "#a979bd", "#c47c72", "#7fa66a", "#b68d6d", "#5fa6aa"];
  let hash = 0;
  for (const caractere of String(nome || "")) hash = (hash * 31 + caractere.charCodeAt(0)) >>> 0;
  return paleta[hash % paleta.length];
}

function svgNo(tag, atributos = {}) {
  const no = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const [chave, valor] of Object.entries(atributos)) no.setAttribute(chave, valor);
  return no;
}

function mapaChapa(chapa, plano) {
  const figura = elemento("figure", { class: "cut-map" });
  const svg = svgNo("svg", {
    viewBox: `0 0 ${chapa.largura} ${chapa.altura}`,
    role: "img",
    "aria-label": `Plano da chapa ${chapa.indice}`,
    preserveAspectRatio: "xMidYMid meet"
  });
  svg.append(svgNo("rect", { x: 0, y: 0, width: chapa.largura, height: chapa.altura, class: "sheet-outline" }));
  const refilo = plano.parametros?.refilo || 0;
  if (refilo) svg.append(svgNo("rect", {
    x: refilo, y: refilo, width: chapa.largura - 2 * refilo, height: chapa.altura - 2 * refilo, class: "usable-outline"
  }));
  for (const peca of chapa.pecas || []) {
    const grupo = svgNo("g");
    grupo.append(svgNo("rect", {
      x: peca.x, y: peca.y, width: peca.largura, height: peca.altura,
      fill: corPeca(peca.grupoId || peca.nome), class: "piece-rect"
    }));
    if (peca.largura >= 130 && peca.altura >= 90) {
      const fonte = Math.max(18, Math.min(48, Math.min(peca.largura, peca.altura) / 6));
      const rotulo = svgNo("text", {
        x: peca.x + peca.largura / 2,
        y: peca.y + peca.altura / 2,
        "text-anchor": "middle",
        "dominant-baseline": "middle",
        "font-size": fonte,
        class: "piece-label"
      });
      rotulo.textContent = `${peca.nome.slice(0, 22)} · ${peca.largura}×${peca.altura}`;
      grupo.append(rotulo);
    }
    svg.append(grupo);
  }
  figura.append(
    elemento("figcaption", {}, [
      elemento("strong", { text: `Chapa ${chapa.indice}` }),
      elemento("span", { text: `${chapa.pecas?.length || 0} peças · ${chapa.cortesEstimados || 0} cortes estimados` })
    ]),
    svg
  );
  return figura;
}

function mapaBarra(barra) {
  const figura = elemento("figure", { class: "cut-map linear-map" });
  const svg = svgNo("svg", { viewBox: `0 0 ${barra.comprimento} 140`, role: "img", "aria-label": `Plano da barra ${barra.indice}`, preserveAspectRatio: "none" });
  svg.append(svgNo("rect", { x: 0, y: 30, width: barra.comprimento, height: 80, class: "sheet-outline" }));
  for (const peca of barra.pecas || []) {
    svg.append(svgNo("rect", { x: peca.inicio, y: 30, width: peca.comprimento, height: 80, fill: corPeca(peca.grupoId || peca.nome), class: "piece-rect" }));
    if (peca.comprimento > barra.comprimento * .08) {
      const rotulo = svgNo("text", { x: peca.inicio + peca.comprimento / 2, y: 73, "text-anchor": "middle", class: "piece-label", "font-size": 38 });
      rotulo.textContent = `${peca.comprimento} mm`;
      svg.append(rotulo);
    }
  }
  figura.append(
    elemento("figcaption", {}, [elemento("strong", { text: `Barra ${barra.indice}` }), elemento("span", { text: `Sobra: ${barra.restante} mm` })]),
    svg
  );
  return figura;
}

function renderizarPlanoCorte(plano) {
  const chapas = plano.tipo === "otimizacao_chapas_2d";
  $("#corte-titulo").textContent = plano.material;
  const item = chapas ? plano.compra.chapa : plano.compra.barra;
  const substantivo = chapas ? "chapa(s)" : "barra(s)";
  $("#corte-recomendacao").textContent = `Comprar ${plano.compra.quantidade} ${substantivo} de ${item.nome}. ${plano.compra.custoTotal == null ? "Informe o preço unitário para calcular o valor." : `Custo estimado: ${dinheiro(plano.compra.custoTotal)}.`}`;
  $("#corte-parametros").textContent = `Serra: ${plano.parametros.serra} mm · Refilo: ${plano.parametros.refilo} mm · ${plano.quantidadePecas} peças`;

  const download = $("#download-corte");
  if (plano.download) { download.href = plano.download; download.classList.remove("hidden"); }
  else download.classList.add("hidden");

  const metricas = $("#metricas-corte");
  limpar(metricas);
  metricas.append(
    criarMetrica(chapas ? "Chapas para comprar" : "Barras para comprar", String(plano.compra.quantidade)),
    criarMetrica("Custo total", plano.compra.custoTotal == null ? "—" : dinheiro(plano.compra.custoTotal)),
    criarMetrica("Aproveitamento", `${plano.metricas.aproveitamentoPercentual}%`),
    criarMetrica(chapas ? "Perda total" : "Sobra total", chapas ? `${plano.metricas.perdaTotalM2} m²` : `${plano.metricas.sobraTotalM} m`)
  );

  const mapas = $("#mapas-corte");
  limpar(mapas);
  if (chapas) (plano.chapas || []).forEach(chapa => mapas.append(mapaChapa(chapa, plano)));
  else (plano.barras || []).forEach(barra => mapas.append(mapaBarra(barra)));

  const sobras = $("#sobras-corte");
  limpar(sobras);
  if (plano.sobrasReutilizaveis?.length) {
    for (const sobra of plano.sobrasReutilizaveis) {
      sobras.append(elemento("div", { class: "compact-list-row" }, [
        elemento("strong", { text: chapas ? `Chapa ${sobra.chapa}` : `Barra ${sobra.barra}` }),
        elemento("span", { text: chapas ? `${sobra.largura} × ${sobra.altura} mm · ${sobra.areaM2} m²` : `${sobra.comprimento} mm` })
      ]));
    }
  } else sobras.append(elemento("p", { class: "empty-message", text: "Nenhuma sobra atingiu o tamanho mínimo definido." }));

  const alertas = $("#alertas-corte");
  limpar(alertas);
  (plano.alertas || []).forEach(alerta => alertas.append(elemento("li", { text: alerta })));
  $("#resultado-corte").classList.remove("hidden");
  $("#resultado-corte").scrollIntoView({ behavior: "smooth", block: "start" });
}

async function calcularChapas(evento) {
  evento.preventDefault();
  if (!$("#pecas-chapas tr")) return mostrarErro({ erro: "Adicione pelo menos uma peça." });
  const botao = $("#calcular-chapas");
  botao.disabled = true;
  botao.textContent = "Otimizando…";
  try {
    const preco = $("#chapa-preco").value;
    const plano = await api("/materiais/otimizar-chapas", {
      method: "POST",
      body: JSON.stringify({
        material: $("#corte-material").value,
        chapa: {
          largura: Number($("#chapa-largura").value),
          altura: Number($("#chapa-altura").value),
          preco: preco === "" ? null : Number(preco)
        },
        serra: Number($("#chapa-serra").value),
        refilo: Number($("#chapa-refilo").value),
        sobraMinima: { largura: Number($("#chapa-sobra-minima").value), altura: Number($("#chapa-sobra-minima").value) },
        objetivo: $("#chapa-objetivo").value,
        pecas: lerLinhasPecas("#pecas-chapas", "chapas"),
        gerarExcel: true
      })
    });
    renderizarPlanoCorte(plano);
  } catch (erro) { mostrarErro(erro); }
  finally { botao.disabled = false; botao.textContent = "Calcular compra e corte"; }
}

async function calcularBarras(evento) {
  evento.preventDefault();
  if (!$("#pecas-barras tr")) return mostrarErro({ erro: "Adicione pelo menos um trecho." });
  const botao = $("#calcular-barras");
  botao.disabled = true;
  botao.textContent = "Otimizando…";
  try {
    const preco = $("#barra-preco").value;
    const plano = await api("/materiais/otimizar-barras", {
      method: "POST",
      body: JSON.stringify({
        material: $("#barra-material").value,
        barra: { comprimento: Number($("#barra-comprimento").value), preco: preco === "" ? null : Number(preco) },
        serra: Number($("#barra-serra").value),
        refilo: Number($("#barra-refilo").value),
        sobraMinima: Number($("#barra-sobra-minima").value),
        pecas: lerLinhasPecas("#pecas-barras", "barras"),
        gerarExcel: true
      })
    });
    renderizarPlanoCorte(plano);
  } catch (erro) { mostrarErro(erro); }
  finally { botao.disabled = false; botao.textContent = "Calcular compra e corte"; }
}

async function gerarPecasModulo() {
  try {
    const modulo = await api("/materiais/calcular-modulo", {
      method: "POST",
      body: JSON.stringify({
        nome: $("#modulo-nome").value,
        largura: Number($("#modulo-largura").value),
        altura: Number($("#modulo-altura").value),
        profundidade: Number($("#modulo-profundidade").value),
        espessura: Number($("#modulo-espessura").value),
        quantidade: Number($("#modulo-quantidade").value),
        prateleiras: Number($("#modulo-prateleiras").value),
        recuoPrateleira: Number($("#modulo-recuo").value),
        montagem: $("#modulo-montagem").value
      })
    });
    $$("#pecas-chapas tr").filter(linha =>
      !linha.querySelector('[data-role="nome"]')?.value &&
      !linha.querySelector('[data-role="largura"]')?.value &&
      !linha.querySelector('[data-role="altura"]')?.value
    ).forEach(linha => linha.remove());
    modulo.pecas.forEach(adicionarPecaChapa);
    $("#toast").textContent = `${modulo.pecas.length} grupos de peças adicionados à lista.`;
    $("#toast").classList.add("success");
    $("#toast").classList.remove("hidden");
    clearTimeout(mostrarErro.timer);
    mostrarErro.timer = setTimeout(() => $("#toast").classList.add("hidden"), 4500);
  } catch (erro) { mostrarErro(erro); }
}

function trocarModoCorte(modo) {
  $$(".cut-mode").forEach(botao => botao.classList.toggle("active", botao.dataset.cutMode === modo));
  $("#form-corte-chapas").classList.toggle("hidden", modo !== "chapas");
  $("#form-corte-barras").classList.toggle("hidden", modo !== "barras");
  $("#resultado-corte").classList.add("hidden");
}

async function enviarPesquisa(evento) {
  evento.preventDefault();
  const botao = $("#botao-pesquisar");
  botao.disabled = true;
  botao.classList.add("busy");
  $("#progresso-pesquisa").classList.remove("hidden");
  $("#resultado-pesquisa").classList.add("hidden");

  try {
    const relatorio = await api("/pesquisa/mercado", {
      method: "POST",
      body: JSON.stringify({
        consulta: $("#consulta").value,
        regiao: $("#regiao").value,
        quantidade: $("#quantidade").value || null,
        unidade: $("#unidade").value || null,
        limite: Number($("#limite").value),
        gerarExcel: true
      })
    });
    renderizarPesquisa(relatorio);
  } catch (erro) {
    mostrarErro(erro);
  } finally {
    botao.disabled = false;
    botao.classList.remove("busy");
    $("#progresso-pesquisa").classList.add("hidden");
  }
}

function adicionarMensagem(tipo, texto, fontes = []) {
  const mensagens = $("#mensagens-chat");
  const conteudo = elemento("div", { text: texto });
  if (fontes.length) {
    const links = elemento("span", { class: "message-sources" });
    fontes.forEach(fonte => links.append(elemento("a", {
      href: fonte.url,
      text: `[${fonte.id}] ${fonte.titulo || fonte.url}`
    })));
    conteudo.append(links);
  }
  const mensagem = elemento("div", { class: `message ${tipo}` }, [
    elemento("span", { class: "avatar", text: tipo === "user" ? "V" : "R" }),
    conteudo
  ]);
  mensagens.append(mensagem);
  mensagens.scrollTop = mensagens.scrollHeight;
}

async function enviarChat(evento) {
  evento.preventDefault();
  const campo = $("#pergunta-chat");
  const pergunta = campo.value.trim();
  if (!pergunta) return;
  campo.value = "";
  adicionarMensagem("user", pergunta);
  const botao = $("#botao-chat");
  botao.disabled = true;
  botao.textContent = "Pensando…";
  try {
    const dados = await api("/chat", {
      method: "POST",
      body: JSON.stringify({
        pergunta,
        usarInternet: $("#modo-internet").value,
        contextoArquivo: prepararContextoArquivo(ultimoArquivoLido)
      })
    });
    adicionarMensagem("assistant", dados.resposta, dados.fontes || []);
  } catch (erro) {
    adicionarMensagem("assistant", `Não consegui concluir: ${erro.erro || erro.message || "erro desconhecido"}`);
  } finally {
    botao.disabled = false;
    botao.textContent = "Enviar";
  }
}

function arquivoEmBase64(arquivo) {
  return new Promise((resolve, reject) => {
    const leitor = new FileReader();
    leitor.onload = () => resolve(String(leitor.result).split(",").pop());
    leitor.onerror = () => reject(new Error("Não foi possível ler o arquivo."));
    leitor.readAsDataURL(arquivo);
  });
}

function usarItemNaPesquisa(item) {
  $("#consulta").value = item.material || "";
  $("#quantidade").value = item.quantidade ?? "";
  $("#unidade").value = item.unidade || "";
  trocarView("pesquisa");
  $("#consulta").focus();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderizarAnalisePlanilha(dados) {
  const raiz = $("#abas-planilha");
  limpar(raiz);
  const analise = dados.analise || {};
  const resumo = analise.resumo || {};

  const metricas = elemento("div", { class: "metric-grid sheet-metrics" }, [
    criarMetrica("Abas", String(resumo.totalAbas ?? dados.conteudo?.length ?? 0)),
    criarMetrica("Materiais", String(resumo.totalItens ?? 0)),
    criarMetrica("Com quantidade", String(resumo.itensComQuantidade ?? 0)),
    criarMetrica("Erros de fórmula", String(resumo.errosFormula ?? 0))
  ]);
  raiz.append(metricas);

  for (const alerta of analise.alertas || []) {
    raiz.append(elemento("div", { class: "sheet-alert", text: alerta }));
  }

  if (analise.itens?.length) {
    const bloco = elemento("section", { class: "sheet-block extracted-materials" }, [
      elemento("div", { class: "panel-title" }, [
        elemento("div", {}, [
          elemento("span", { class: "eyebrow", text: "ITENS RECONHECIDOS" }),
          elemento("h2", { text: "Materiais prontos para pesquisa" })
        ]),
        elemento("small", { text: "Use Pesquisar para levar o item ao comparador." })
      ])
    ]);
    const tabelaWrap = elemento("div", { class: "table-wrap" });
    const tabela = elemento("table");
    const head = elemento("thead", {}, elemento("tr", {}, [
      elemento("th", { text: "Aba / linha" }),
      elemento("th", { text: "Material" }),
      elemento("th", { text: "Qtd." }),
      elemento("th", { text: "Cotações existentes" }),
      elemento("th", { text: "" })
    ]));
    const corpo = elemento("tbody");
    for (const item of analise.itens.slice(0, 250)) {
      const cotacoes = (item.cotacoesExistentes || []).map(c => `${c.fornecedor}: ${dinheiro(c.valor)}`).join(" · ") || "—";
      const botao = elemento("button", { class: "inline-button", type: "button", text: "Pesquisar" });
      botao.addEventListener("click", () => usarItemNaPesquisa(item));
      corpo.append(elemento("tr", {}, [
        elemento("td", { text: `${item.aba} · ${item.linha}` }),
        elemento("td", {}, [
          elemento("strong", { text: item.material }),
          item.categoria ? elemento("span", { class: "source-meta", text: item.categoria }) : null
        ]),
        elemento("td", { text: `${item.quantidade ?? "—"} ${item.unidade || ""}`.trim() }),
        elemento("td", { text: cotacoes }),
        elemento("td", {}, botao)
      ]));
    }
    tabela.append(head, corpo);
    tabelaWrap.append(tabela);
    bloco.append(tabelaWrap);
    raiz.append(bloco);
  }

  if (analise.errosFormula?.length) {
    const detalhesErros = elemento("details", { class: "sheet-details formula-details" }, [
      elemento("summary", { text: `Ver ${analise.errosFormula.length} erros de fórmula encontrados` })
    ]);
    const lista = elemento("ul", { class: "formula-list" });
    for (const erro of analise.errosFormula) {
      lista.append(elemento("li", { text: `${erro.aba} · linha ${erro.linha}, coluna ${erro.coluna}: =${erro.formula} → ${erro.erro}` }));
    }
    detalhesErros.append(lista);
    raiz.append(detalhesErros);
  }

  const brutos = elemento("details", { class: "sheet-details" }, [
    elemento("summary", { text: "Ver conteúdo bruto das abas" })
  ]);
  for (const aba of dados.conteudo || []) {
    const bloco = elemento("section", { class: "sheet-block" }, [
      elemento("h3", { text: aba.aba }),
      elemento("p", { class: "sheet-summary", text: `${aba.linhas?.length || 0} linhas preenchidas` })
    ]);
    const tabelaWrap = elemento("div", { class: "table-wrap" });
    const tabela = elemento("table");
    const corpo = elemento("tbody");
    for (const linha of (aba.linhas || []).slice(0, 50)) {
      const tr = elemento("tr");
      tr.append(elemento("th", { text: String(linha.linha) }));
      for (const valor of linha.valores || []) {
        const exibido = valor && typeof valor === "object" ? JSON.stringify(valor) : String(valor ?? "");
        tr.append(elemento("td", { text: exibido }));
      }
      corpo.append(tr);
    }
    tabela.append(corpo);
    tabelaWrap.append(tabela);
    bloco.append(tabelaWrap);
    brutos.append(bloco);
  }
  raiz.append(brutos);
}

function tamanhoArquivo(bytes) {
  const valor = Number(bytes) || 0;
  if (valor < 1024) return `${valor} B`;
  if (valor < 1024 ** 2) return `${(valor / 1024).toFixed(1)} KB`;
  return `${(valor / 1024 ** 2).toFixed(1)} MB`;
}

function renderizarAlertasArquivo(raiz, alertas = []) {
  for (const alerta of alertas) raiz.append(elemento("div", { class: "sheet-alert", text: alerta }));
}

function tabelaDocumento(tabela) {
  const bloco = elemento("section", { class: "sheet-block document-table" }, [
    elemento("h3", { text: `Tabela ${tabela.indice}` })
  ]);
  const envoltorio = elemento("div", { class: "table-wrap" });
  const tabelaNo = elemento("table");
  const corpo = elemento("tbody");
  for (const linha of tabela.linhas || []) {
    corpo.append(elemento("tr", {}, linha.map(celula => elemento("td", { text: celula }))));
  }
  tabelaNo.append(corpo);
  envoltorio.append(tabelaNo);
  bloco.append(envoltorio);
  return bloco;
}

function renderizarAnaliseDocumento(dados) {
  const raiz = $("#abas-planilha");
  limpar(raiz);
  const analise = dados.analise || {};
  const resumo = analise.resumo || {};
  const pdf = analise.formato === ".pdf";
  raiz.append(elemento("div", { class: "metric-grid sheet-metrics" }, [
    criarMetrica("Formato", String(analise.formato || "documento").toUpperCase()),
    criarMetrica(pdf ? "Páginas" : "Parágrafos", String(pdf ? (resumo.paginas ?? 0) : (resumo.paragrafos ?? 0))),
    criarMetrica("Palavras", Number(resumo.palavras || 0).toLocaleString("pt-BR")),
    criarMetrica("Tabelas / links", `${resumo.tabelas || 0} / ${resumo.links || 0}`)
  ]));
  renderizarAlertasArquivo(raiz, analise.alertas);

  const metadados = Object.entries(analise.metadados || {});
  if (metadados.length) {
    raiz.append(elemento("section", { class: "sheet-block file-metadata" }, [
      elemento("h3", { text: "Metadados" }),
      ...metadados.map(([chave, valor]) => elemento("div", { class: "compact-list-row" }, [
        elemento("strong", { text: chave }),
        elemento("span", { text: String(valor) })
      ]))
    ]));
  }

  if (analise.conteudo?.titulos?.length) {
    raiz.append(elemento("section", { class: "sheet-block" }, [
      elemento("h3", { text: "Títulos reconhecidos" }),
      elemento("ul", { class: "document-outline" }, analise.conteudo.titulos.map(titulo =>
        elemento("li", { text: `${"· ".repeat(Math.max(0, titulo.nivel - 1))}${titulo.texto}` })
      ))
    ]));
  }

  for (const tabela of analise.conteudo?.tabelas || []) raiz.append(tabelaDocumento(tabela));

  const textoExtraido = analise.conteudo?.texto || "";
  raiz.append(elemento("details", { class: "sheet-details document-text-details", open: "" }, [
    elemento("summary", { text: `Texto extraído · ${Number(resumo.caracteres || 0).toLocaleString("pt-BR")} caracteres` }),
    elemento("pre", { class: "document-text", text: textoExtraido || "Nenhum texto extraível encontrado." })
  ]));
}

function listaEtiquetas(titulo, valores) {
  if (!valores?.length) return null;
  return elemento("section", { class: "sheet-block model-list" }, [
    elemento("h3", { text: titulo }),
    elemento("div", { class: "file-tags" }, valores.slice(0, 300).map(valor => elemento("span", { text: valor })))
  ]);
}

function renderizarAnaliseModelo(dados) {
  const raiz = $("#abas-planilha");
  limpar(raiz);
  const analise = dados.analise || {};
  const resumo = analise.resumo || {};
  const modelo = analise.modelo || {};
  raiz.append(elemento("div", { class: "metric-grid sheet-metrics" }, [
    criarMetrica("Formato", String(analise.formato || "modelo").toUpperCase()),
    criarMetrica("Tamanho", tamanhoArquivo(analise.tamanhoBytes)),
    criarMetrica("Vértices", resumo.vertices == null ? "—" : Number(resumo.vertices).toLocaleString("pt-BR")),
    criarMetrica("Faces", resumo.faces == null ? (resumo.triangulos == null ? "—" : Number(resumo.triangulos).toLocaleString("pt-BR")) : Number(resumo.faces).toLocaleString("pt-BR"))
  ]));
  renderizarAlertasArquivo(raiz, analise.alertas);

  if (modelo.dimensoes?.tamanho) {
    const d = modelo.dimensoes;
    raiz.append(elemento("section", { class: "sheet-block model-dimensions" }, [
      elemento("span", { class: "eyebrow", text: "ENVOLTÓRIA GEOMÉTRICA" }),
      elemento("h3", { text: `${d.tamanho.x} × ${d.tamanho.y} × ${d.tamanho.z} ${d.unidade}` }),
      elemento("p", { text: `Mínimo: ${d.minimo.x}, ${d.minimo.y}, ${d.minimo.z} · Máximo: ${d.maximo.x}, ${d.maximo.y}, ${d.maximo.z}` })
    ]));
  } else {
    raiz.append(elemento("section", { class: "sheet-block model-dimensions unavailable" }, [
      elemento("h3", { text: "Dimensões não disponíveis" }),
      elemento("p", { text: "O arquivo foi reconhecido, mas este formato não forneceu geometria confiável para cálculo." })
    ]));
  }

  [
    listaEtiquetas("Materiais", modelo.materiais),
    listaEtiquetas("Objetos / componentes", modelo.objetos || modelo.geometrias),
    listaEtiquetas("Grupos", modelo.grupos),
    listaEtiquetas("Nomes internos encontrados", modelo.nomesInternos)
  ].filter(Boolean).forEach(bloco => raiz.append(bloco));

  raiz.append(elemento("details", { class: "sheet-details" }, [
    elemento("summary", { text: "Ver relatório técnico" }),
    elemento("pre", { class: "document-text technical-report", text: JSON.stringify({ resumo, metadados: analise.metadados, modelo }, null, 2) })
  ]));
}

function dimensoesPecaPromob(peca) {
  if (peca.largura != null && peca.altura != null) return { largura: peca.largura, altura: peca.altura };
  if (peca.comprimento != null && peca.largura != null) return { largura: peca.comprimento, altura: peca.largura };
  if (peca.comprimento != null && peca.altura != null) return { largura: peca.comprimento, altura: peca.altura };
  return null;
}

function enviarPecasPromobAoCorte(pecas) {
  const validas = pecas.map(peca => ({ peca, dimensoes: dimensoesPecaPromob(peca) })).filter(item => item.dimensoes);
  if (!validas.length) return mostrarErro({ erro: "A exportação não trouxe duas dimensões utilizáveis para as peças." });
  $$("#pecas-chapas tr").forEach(linha => linha.remove());
  for (const { peca, dimensoes } of validas) {
    adicionarPecaChapa({
      nome: peca.nome,
      largura: dimensoes.largura,
      altura: dimensoes.altura,
      quantidade: Math.max(1, Math.round(Number(peca.quantidade) || 1)),
      veio: "livre",
      permitirGiro: true
    });
  }
  trocarView("corte");
  $("#toast").textContent = `${validas.length} grupos de peças do Promob foram enviados ao plano de corte. Confira veio, medidas e quantidades.`;
  $("#toast").classList.add("success");
  $("#toast").classList.remove("hidden");
  clearTimeout(mostrarErro.timer);
  mostrarErro.timer = setTimeout(() => $("#toast").classList.add("hidden"), 5000);
}

function renderizarAnalisePromob(dados) {
  const raiz = $("#abas-planilha");
  limpar(raiz);
  const analise = dados.analise || {};
  const resumo = analise.resumo || {};
  const promob = analise.promob || {};
  raiz.append(elemento("div", { class: "metric-grid sheet-metrics" }, [
    criarMetrica("Formato", String(analise.formato || "Promob").toUpperCase()),
    criarMetrica("Peças reconhecidas", Number(resumo.pecasDetectadas || 0).toLocaleString("pt-BR")),
    criarMetrica("Materiais", Number(resumo.materiais || 0).toLocaleString("pt-BR")),
    criarMetrica("Arquivos internos", Number(resumo.arquivosInternos || 0).toLocaleString("pt-BR"))
  ]));
  renderizarAlertasArquivo(raiz, analise.alertas);

  if (promob.pecas?.length) {
    const cabecalho = elemento("div", { class: "panel-title promob-parts-title" }, [
      elemento("div", {}, [elemento("span", { class: "eyebrow", text: "LISTA RECONHECIDA" }), elemento("h2", { text: "Peças do Promob" })])
    ]);
    const utilizaveis = promob.pecas.filter(dimensoesPecaPromob);
    if (utilizaveis.length) {
      const botao = elemento("button", { type: "button", class: "secondary-button compact-button", text: "Enviar ao plano de corte" });
      botao.addEventListener("click", () => enviarPecasPromobAoCorte(promob.pecas));
      cabecalho.append(botao);
    }
    const bloco = elemento("section", { class: "sheet-block extracted-materials" }, [cabecalho]);
    const envoltorio = elemento("div", { class: "table-wrap" });
    const tabela = elemento("table");
    const corpo = elemento("tbody");
    for (const peca of promob.pecas.slice(0, 1_000)) {
      const dimensoes = [
        peca.largura != null ? `L ${peca.largura}` : null,
        peca.altura != null ? `A ${peca.altura}` : null,
        peca.comprimento != null ? `C ${peca.comprimento}` : null,
        peca.profundidade != null ? `P ${peca.profundidade}` : null,
        peca.espessura != null ? `E ${peca.espessura}` : null
      ].filter(Boolean).join(" × ") || "—";
      corpo.append(elemento("tr", {}, [
        elemento("td", {}, [elemento("strong", { text: peca.nome }), elemento("span", { class: "source-meta", text: peca.material || "Material não informado" })]),
        elemento("td", { text: dimensoes }),
        elemento("td", { text: peca.quantidade == null ? "—" : String(peca.quantidade) })
      ]));
    }
    tabela.append(elemento("thead", {}, elemento("tr", {}, [elemento("th", { text: "Peça / material" }), elemento("th", { text: "Dimensões" }), elemento("th", { text: "Qtd." })])), corpo);
    envoltorio.append(tabela);
    bloco.append(envoltorio);
    raiz.append(bloco);
  }

  [
    listaEtiquetas("Materiais reconhecidos", promob.materiais),
    listaEtiquetas("Nomes internos encontrados", promob.nomesInternos),
    listaEtiquetas("Arquivos dentro do projeto", (promob.arquivosInternos || []).map(arquivo => arquivo.nome))
  ].filter(Boolean).forEach(bloco => raiz.append(bloco));

  raiz.append(elemento("details", { class: "sheet-details document-text-details" }, [
    elemento("summary", { text: "Ver conteúdo legível" }),
    elemento("pre", { class: "document-text", text: analise.conteudo?.texto || "Nenhum texto interno extraível." })
  ]));
}

function prepararContextoArquivo(dados) {
  if (!dados) return null;
  if (dados.tipoEntrada === "planilha") {
    const compacto = {
      nomeArquivo: dados.nomeArquivo,
      tipo: "planilha",
      resumo: dados.analise?.resumo,
      itens: dados.analise?.itens?.slice(0, 250),
      errosFormula: dados.analise?.errosFormula?.slice(0, 100),
      abas: (dados.conteudo || []).map(aba => ({ aba: aba.aba, linhas: (aba.linhas || []).slice(0, 80) }))
    };
    return JSON.stringify(compacto).slice(0, 14_000);
  }
  if (dados.tipoEntrada === "projeto_promob") {
    return JSON.stringify({
      nomeArquivo: dados.nomeArquivo,
      categoria: "projeto_promob",
      formato: dados.analise?.formato,
      resumo: dados.analise?.resumo,
      pecas: dados.analise?.promob?.pecas?.slice(0, 300),
      materiais: dados.analise?.promob?.materiais,
      alertas: dados.analise?.alertas,
      textoExtraido: dados.analise?.conteudo?.texto?.slice(0, 8_000)
    }).slice(0, 14_000);
  }
  return JSON.stringify({
    nomeArquivo: dados.nomeArquivo,
    categoria: dados.analise?.categoria,
    formato: dados.analise?.formato,
    resumo: dados.analise?.resumo,
    metadados: dados.analise?.metadados,
    conteudo: dados.analise?.conteudo,
    modelo: dados.analise?.modelo,
    promob: dados.analise?.promob,
    alertas: dados.analise?.alertas
  }).slice(0, 14_000);
}

function usarArquivoNoChat() {
  if (!ultimoArquivoLido) return mostrarErro({ erro: "Leia um arquivo antes de enviá-lo ao chat." });
  trocarView("chat");
  adicionarMensagem("assistant", `Arquivo ${ultimoArquivoLido.nomeArquivo} adicionado ao contexto. Ao enviar sua próxima pergunta, o trecho extraído será enviado à IA online.`);
  $("#pergunta-chat").focus();
}

async function enviarPlanilha(evento) {
  evento.preventDefault();
  const arquivo = $("#arquivo-planilha").files[0];
  if (!arquivo) return;
  if (arquivo.size > 24 * 1024 * 1024) return mostrarErro({ erro: "O arquivo excede o limite de 24 MB desta edição para computadores com 4 GB de RAM." });
  const botao = $("#botao-planilha");
  botao.disabled = true;
  botao.textContent = "Lendo…";
  try {
    const dados = await api("/arquivo/analisar", {
      method: "POST",
      body: JSON.stringify({ nomeArquivo: arquivo.name, arquivoBase64: await arquivoEmBase64(arquivo) })
    });
    dados.nomeArquivo = arquivo.name;
    ultimoArquivoLido = dados;
    $("#nome-planilha").textContent = arquivo.name;
    if (dados.tipoEntrada === "planilha") renderizarAnalisePlanilha(dados);
    else if (dados.tipoEntrada === "documento") renderizarAnaliseDocumento(dados);
    else if (dados.tipoEntrada === "projeto_promob") renderizarAnalisePromob(dados);
    else renderizarAnaliseModelo(dados);
    $("#usar-arquivo-chat").classList.remove("hidden");
    $("#resultado-planilha").classList.remove("hidden");
  } catch (erro) {
    mostrarErro(erro);
  } finally {
    botao.disabled = false;
    botao.textContent = "Ler arquivo";
  }
}

async function carregarHistorico() {
  const lista = $("#lista-historico");
  limpar(lista);
  try {
    const dados = await api("/pesquisas?limite=50");
    const pesquisas = dados.pesquisas || [];
    $("#sem-historico").classList.toggle("hidden", pesquisas.length > 0);
    for (const pesquisa of pesquisas) {
      const card = elemento("article", { class: "history-card", tabindex: "0" }, [
        elemento("small", { text: dataHora(pesquisa.coletadoEm) }),
        elemento("h3", { text: pesquisa.consulta || pesquisa.produto || pesquisa.id }),
        elemento("p", { text: `${pesquisa.regiao || "Brasil"} · ${pesquisa.totalFontes || pesquisa.fontes?.length || 0} fontes` })
      ]);
      const abrir = async () => {
        try {
          const relatorio = await api(`/pesquisas/${encodeURIComponent(pesquisa.id)}`);
          trocarView("pesquisa");
          renderizarPesquisa(relatorio);
        } catch (erro) { mostrarErro(erro); }
      };
      card.addEventListener("click", abrir);
      card.addEventListener("keydown", evento => { if (evento.key === "Enter") abrir(); });
      lista.append(card);
    }
  } catch (erro) {
    mostrarErro(erro);
  }
}

function cardDiagnostico(titulo, valor, estado) {
  return elemento("article", { class: `diagnostic-card ${estado}` }, [
    elemento("span", { text: titulo }),
    elemento("strong", { text: valor })
  ]);
}

async function executarDiagnostico() {
  const cards = $("#cards-diagnostico");
  limpar(cards);
  cards.append(cardDiagnostico("Diagnóstico", "Executando…", "warn"));
  const [status, rede] = await Promise.allSettled([api("/status"), api("/health/internet")]);
  limpar(cards);
  const s = status.status === "fulfilled" ? status.value : null;
  const r = rede.status === "fulfilled" ? rede.value : rede.reason;
  const pesquisaOk = s?.pesquisa?.serperConfigurado || s?.pesquisa?.braveConfigurado;
  const iaTitulo = s?.modelo?.modo === "local" ? "IA local" : "IA online";
  const iaConfigurada = s?.modelo?.configurado !== false;
  cards.append(
    cardDiagnostico("Servidor", s ? "Online" : "Offline", s ? "ok" : "error"),
    cardDiagnostico(iaTitulo, s?.modelo?.online ? "Online" : (iaConfigurada ? "Indisponível" : "Sem chave"), s?.modelo?.online ? "ok" : (iaConfigurada ? "error" : "warn")),
    cardDiagnostico("Chave de pesquisa", pesquisaOk ? "Configurada" : "Ausente", pesquisaOk ? "ok" : "warn"),
    cardDiagnostico("DNS / HTTPS da IA", r?.ia?.internet ? "Funcionando" : (r?.ia?.codigo || "Falha"), r?.ia?.internet ? "ok" : "error"),
    cardDiagnostico("DNS / HTTPS da busca", r?.busca?.internet ? "Funcionando" : (r?.busca?.codigo || "Falha"), r?.busca?.internet ? "ok" : "error")
  );
  $("#log-diagnostico").textContent = JSON.stringify({ servidor: s || status.reason, internet: r }, null, 2);
}

$$('.nav-button').forEach(botao => botao.addEventListener("click", () => trocarView(botao.dataset.view)));
$$(".cut-mode").forEach(botao => botao.addEventListener("click", () => trocarModoCorte(botao.dataset.cutMode)));
$("#form-pesquisa").addEventListener("submit", enviarPesquisa);
$("#form-corte-chapas").addEventListener("submit", calcularChapas);
$("#form-corte-barras").addEventListener("submit", calcularBarras);
$("#adicionar-peca-chapa").addEventListener("click", () => adicionarPecaChapa());
$("#adicionar-peca-barra").addEventListener("click", () => adicionarPecaBarra());
$("#gerar-modulo").addEventListener("click", gerarPecasModulo);
$("#form-chat").addEventListener("submit", enviarChat);
$("#form-planilha").addEventListener("submit", enviarPlanilha);
$("#usar-arquivo-chat").addEventListener("click", usarArquivoNoChat);
$("#atualizar-historico").addEventListener("click", carregarHistorico);
$("#executar-diagnostico").addEventListener("click", executarDiagnostico);
$("#arquivo-planilha").addEventListener("change", evento => {
  const arquivo = evento.target.files[0];
  if (arquivo) evento.target.closest("label").querySelector("strong").textContent = arquivo.name;
});

const inicial = location.hash.slice(1);
if (["pesquisa", "corte", "chat", "planilha", "historico", "diagnostico"].includes(inicial)) trocarView(inicial);
adicionarPecaChapa();
adicionarPecaBarra();
carregarStatus();
setInterval(carregarStatus, 60_000);
