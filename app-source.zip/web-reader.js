import dns from "node:dns/promises";
import net from "node:net";
import { load } from "cheerio";
import { CONFIG } from "./config.js";
import { AppError } from "./errors.js";
import { texto } from "./utils.js";

const MAX_DOWNLOAD_BYTES = 1_500_000;

function ipPrivado(endereco) {
  if (net.isIP(endereco) === 4) {
    const [a, b] = endereco.split(".").map(Number);
    return a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168);
  }

  if (net.isIP(endereco) === 6) {
    const valor = endereco.toLowerCase();
    return valor === "::1" || valor === "::" || valor.startsWith("fc") ||
      valor.startsWith("fd") || valor.startsWith("fe8") || valor.startsWith("fe9") ||
      valor.startsWith("fea") || valor.startsWith("feb") || valor.startsWith("::ffff:127.") ||
      valor.startsWith("::ffff:10.") || valor.startsWith("::ffff:192.168.");
  }

  return true;
}

async function validarUrlPublica(valor) {
  let url;
  try {
    url = new URL(valor);
  } catch {
    throw new AppError("URL de fonte inválida.", { status: 400, code: "INVALID_SOURCE_URL" });
  }

  if (!["http:", "https:"].includes(url.protocol)) {
    throw new AppError("Somente páginas HTTP ou HTTPS podem ser consultadas.", { status: 400, code: "SOURCE_PROTOCOL_BLOCKED" });
  }

  if (["localhost", "localhost.localdomain"].includes(url.hostname) || url.hostname.endsWith(".local")) {
    throw new AppError("Endereço local bloqueado.", { status: 403, code: "PRIVATE_SOURCE_BLOCKED" });
  }

  const enderecos = await dns.lookup(url.hostname, { all: true });
  if (!enderecos.length || enderecos.some(item => ipPrivado(item.address))) {
    throw new AppError("A fonte aponta para uma rede privada e foi bloqueada.", { status: 403, code: "PRIVATE_SOURCE_BLOCKED" });
  }
  return url;
}

async function lerCorpoLimitado(resposta) {
  if (!resposta.body) return "";
  const reader = resposta.body.getReader();
  const partes = [];
  let total = 0;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > MAX_DOWNLOAD_BYTES) {
      await reader.cancel();
      break;
    }
    partes.push(value);
  }

  const combinado = new Uint8Array(partes.reduce((soma, parte) => soma + parte.byteLength, 0));
  let offset = 0;
  for (const parte of partes) {
    combinado.set(parte, offset);
    offset += parte.byteLength;
  }
  return new TextDecoder("utf-8", { fatal: false }).decode(combinado);
}

function extrairTextoHtml(html, urlFinal) {
  const $ = load(html);
  $("script,style,noscript,svg,canvas,nav,footer,header,aside,form,dialog").remove();

  const titulo = texto($("title").first().text() || $("h1").first().text(), 500);
  const principal = $("article").first().text() || $("main").first().text() || $("body").text();
  return {
    titulo,
    url: urlFinal,
    texto: texto(principal, CONFIG.searchPageChars)
  };
}

export async function lerPagina(urlOriginal, opcoes = {}) {
  let atual = await validarUrlPublica(urlOriginal);
  const fetchImpl = opcoes.fetchImpl || fetch;

  for (let redirecionamentos = 0; redirecionamentos <= 3; redirecionamentos++) {
    let resposta;
    try {
      resposta = await fetchImpl(atual, {
        redirect: "manual",
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; RasputimMarketResearch/5.0)",
          Accept: "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.1",
          "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.5"
        },
        signal: AbortSignal.timeout(CONFIG.searchTimeoutMs)
      });
    } catch (error) {
      throw new AppError("Não foi possível abrir a fonte.", {
        status: 502,
        code: error?.cause?.code || error?.code || "SOURCE_NETWORK_ERROR",
        details: error.message
      });
    }

    if ([301, 302, 303, 307, 308].includes(resposta.status)) {
      const destino = resposta.headers.get("location");
      if (!destino) throw new AppError("Redirecionamento sem destino.", { status: 502, code: "SOURCE_REDIRECT_ERROR" });
      atual = await validarUrlPublica(new URL(destino, atual).href);
      continue;
    }

    if (!resposta.ok) {
      throw new AppError(`A fonte respondeu HTTP ${resposta.status}.`, {
        status: 502,
        code: "SOURCE_HTTP_ERROR"
      });
    }

    const tipo = String(resposta.headers.get("content-type") || "").toLowerCase();
    if (!(tipo.includes("text/html") || tipo.includes("application/xhtml+xml") || tipo.includes("text/plain"))) {
      throw new AppError(`Formato de fonte não suportado: ${tipo || "desconhecido"}.`, {
        status: 415,
        code: "SOURCE_CONTENT_TYPE_UNSUPPORTED"
      });
    }

    const bruto = await lerCorpoLimitado(resposta);
    if (tipo.includes("text/plain")) {
      return { titulo: "", url: atual.href, texto: texto(bruto, CONFIG.searchPageChars) };
    }
    return extrairTextoHtml(bruto, atual.href);
  }

  throw new AppError("A fonte excedeu o limite de redirecionamentos.", { status: 502, code: "SOURCE_REDIRECT_LIMIT" });
}

export async function lerFontes(resultados, limite = CONFIG.searchMaxPages) {
  const candidatos = resultados.filter(item => item?.url).slice(0, limite);
  const processados = await Promise.all(candidatos.map(async resultado => {
    try {
      const pagina = await lerPagina(resultado.url);
      return { ...pagina, urlOriginal: resultado.url, status: "lida" };
    } catch (error) {
      return {
        titulo: resultado.titulo,
        url: resultado.url,
        texto: resultado.resumo || "",
        status: "somente_resultado_busca",
        erro: error.code || error.message
      };
    }
  }));
  return processados;
}
