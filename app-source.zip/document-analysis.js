import fs from "node:fs/promises";
import path from "node:path";
import { load } from "cheerio";
import JSZip from "jszip";
import mammoth from "mammoth";
import { AppError } from "./errors.js";

export const EXTENSOES_ARQUIVO_SUPORTADAS = Object.freeze([
  ".pdf", ".docx", ".skp", ".skb", ".dae", ".obj", ".stl",
  ".promob", ".bak", ".cut", ".planner", ".xml", ".csv", ".txt"
]);

const LIMITE_TEXTO = 150_000;
const LIMITE_NOMES = 200;

function arredondar(valor, casas = 3) {
  if (!Number.isFinite(valor)) return null;
  const fator = 10 ** casas;
  return Math.round(valor * fator) / fator;
}

function textoLimpo(valor) {
  return String(valor ?? "")
    .replace(/\0/g, "")
    .replace(/\r\n?/g, "\n")
    .split("\n")
    .map(linha => linha.replace(/[\t ]+/g, " ").trimEnd())
    .join("\n")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim();
}

function limitarTexto(valor, alertas, descricao = "O texto") {
  const limpo = textoLimpo(valor);
  if (limpo.length <= LIMITE_TEXTO) return limpo;
  alertas.push(`${descricao} foi limitado a ${LIMITE_TEXTO.toLocaleString("pt-BR")} caracteres na visualização.`);
  return `${limpo.slice(0, LIMITE_TEXTO)}\n\n[conteúdo truncado]`;
}

function contarPalavras(valor) {
  const palavras = textoLimpo(valor).match(/[\p{L}\p{N}]+(?:[-'][\p{L}\p{N}]+)*/gu);
  return palavras?.length || 0;
}

function unicos(valores, limite = LIMITE_NOMES) {
  const resultado = [];
  const vistos = new Set();
  for (const valor of valores) {
    const limpo = String(valor ?? "").replace(/\s+/g, " ").trim();
    const chave = limpo.toLocaleLowerCase("pt-BR");
    if (!limpo || vistos.has(chave)) continue;
    vistos.add(chave);
    resultado.push(limpo.slice(0, 300));
    if (resultado.length >= limite) break;
  }
  return resultado;
}

function baseAnalise(nomeArquivo, buffer, categoria, formato) {
  return {
    categoria,
    formato,
    nomeArquivo: path.basename(String(nomeArquivo || `arquivo${formato}`)),
    tamanhoBytes: buffer.length,
    analisadoEm: new Date().toISOString(),
    alertas: []
  };
}

function metadadosPdf(info) {
  const origem = info?.info || {};
  const campos = {
    titulo: origem.Title ?? origem.title,
    autor: origem.Author ?? origem.author,
    assunto: origem.Subject ?? origem.subject,
    criador: origem.Creator ?? origem.creator,
    produtor: origem.Producer ?? origem.producer,
    criadoEm: origem.CreationDate ?? origem.creationDate,
    modificadoEm: origem.ModDate ?? origem.modDate
  };
  return Object.fromEntries(Object.entries(campos).filter(([, valor]) => valor != null && String(valor).trim()));
}

function achatarMarcadores(itens, nivel = 0, saida = []) {
  for (const item of itens || []) {
    if (saida.length >= LIMITE_NOMES) break;
    if (item?.title) saida.push({ titulo: String(item.title).slice(0, 300), nivel });
    achatarMarcadores(item?.items, nivel + 1, saida);
  }
  return saida;
}

async function analisarPdf(buffer, nomeArquivo) {
  const analise = baseAnalise(nomeArquivo, buffer, "documento", ".pdf");
  if (buffer.subarray(0, 5).toString("ascii") !== "%PDF-") {
    throw new AppError("O arquivo não possui uma assinatura PDF válida.", { status: 422, code: "PDF_INVALID" });
  }

  let PDFParse;
  try {
    ({ PDFParse } = await import("pdf-parse"));
  } catch (error) {
    throw new AppError("O leitor de PDF não pôde ser carregado. Reinstale as dependências oficiais conforme o README.", {
      status: 503,
      code: "PDF_RUNTIME_MISSING",
      details: error?.message
    });
  }

  const parser = new PDFParse({ data: buffer });
  let info = null;
  let resultado;
  try {
    try {
      info = await parser.getInfo({ parsePageInfo: true });
    } catch (error) {
      analise.alertas.push(`Os metadados do PDF não puderam ser lidos: ${error.message}`);
    }
    resultado = await parser.getText();
  } catch (error) {
    throw new AppError(`Não foi possível extrair o PDF: ${error.message}`, { status: 422, code: "PDF_READ_ERROR" });
  } finally {
    await parser.destroy().catch(() => {});
  }

  const textoCompleto = textoLimpo(resultado?.text);
  const texto = limitarTexto(textoCompleto, analise.alertas, "O texto do PDF");
  const paginas = [];
  let caracteresPaginas = 0;
  for (const pagina of resultado?.pages || []) {
    if (caracteresPaginas >= LIMITE_TEXTO) break;
    const paginaTexto = textoLimpo(pagina.text).slice(0, LIMITE_TEXTO - caracteresPaginas);
    caracteresPaginas += paginaTexto.length;
    paginas.push({ numero: pagina.num, texto: paginaTexto });
  }

  const links = unicos((info?.pages || []).flatMap(pagina => (pagina.links || []).map(link => link.url)));
  const tamanhosPaginas = unicos((info?.pages || []).map(pagina => {
    if (!Number.isFinite(pagina.width) || !Number.isFinite(pagina.height)) return null;
    return `${arredondar(pagina.width * 25.4 / 72, 1)} × ${arredondar(pagina.height * 25.4 / 72, 1)} mm`;
  }).filter(Boolean), 20);

  if (!textoCompleto) {
    analise.alertas.push("Nenhum texto selecionável foi encontrado. O PDF pode ser uma digitalização e precisar de OCR.");
  }

  return {
    ...analise,
    confiabilidade: textoCompleto ? "alta_para_texto" : "sem_texto_extraivel",
    resumo: {
      paginas: resultado?.total || info?.total || paginas.length,
      paginasComTexto: (resultado?.pages || []).filter(pagina => textoLimpo(pagina.text)).length,
      palavras: contarPalavras(textoCompleto),
      caracteres: textoCompleto.length,
      links: links.length
    },
    metadados: metadadosPdf(info),
    conteudo: {
      texto,
      paginas,
      links,
      marcadores: achatarMarcadores(info?.outline),
      tamanhosPaginas
    }
  };
}

async function analisarDocx(buffer, nomeArquivo) {
  const analise = baseAnalise(nomeArquivo, buffer, "documento", ".docx");
  if (buffer[0] !== 0x50 || buffer[1] !== 0x4b) {
    throw new AppError("O arquivo não possui uma estrutura DOCX válida.", { status: 422, code: "DOCX_INVALID" });
  }

  let htmlResultado;
  let textoResultado;
  try {
    [htmlResultado, textoResultado] = await Promise.all([
      mammoth.convertToHtml({ buffer }),
      mammoth.extractRawText({ buffer })
    ]);
  } catch (error) {
    throw new AppError(`Não foi possível extrair o DOCX: ${error.message}`, { status: 422, code: "DOCX_READ_ERROR" });
  }

  const $ = load(htmlResultado.value || "");
  const textoCompleto = textoLimpo(textoResultado.value);
  const titulos = [];
  $("h1,h2,h3,h4,h5,h6").each((_, elemento) => {
    titulos.push({ nivel: Number(elemento.tagName.slice(1)), texto: $(elemento).text().trim().slice(0, 500) });
  });
  const tabelas = [];
  $("table").slice(0, 50).each((_, tabela) => {
    const linhas = [];
    $(tabela).find("tr").slice(0, 150).each((__, linha) => {
      linhas.push($(linha).find("th,td").map((___, celula) => $(celula).text().replace(/\s+/g, " ").trim().slice(0, 1000)).get());
    });
    tabelas.push({ indice: tabelas.length + 1, linhas });
  });
  const links = unicos($("a[href]").map((_, link) => $(link).attr("href")).get());
  const mensagens = unicos([...(htmlResultado.messages || []), ...(textoResultado.messages || [])]
    .map(mensagem => `${mensagem.type || "aviso"}: ${mensagem.message || mensagem}`), 100);
  analise.alertas.push(...mensagens);
  if (!textoCompleto) analise.alertas.push("Nenhum texto foi encontrado dentro do DOCX.");

  return {
    ...analise,
    confiabilidade: textoCompleto ? "alta_para_texto_e_tabelas" : "sem_texto_extraivel",
    resumo: {
      palavras: contarPalavras(textoCompleto),
      caracteres: textoCompleto.length,
      paragrafos: $("p").length,
      titulos: titulos.length,
      tabelas: tabelas.length,
      imagensReferenciadas: $("img").length,
      links: links.length
    },
    conteudo: {
      texto: limitarTexto(textoCompleto, analise.alertas, "O texto do DOCX"),
      titulos: titulos.slice(0, LIMITE_NOMES),
      tabelas,
      links
    }
  };
}

function extrairStringsBinarias(buffer) {
  const candidatas = [];
  const ascii = buffer.toString("latin1").match(/[\x20-\x7e\xa0-\xff]{4,180}/g) || [];
  const utf16 = buffer.toString("utf16le").match(/[\x20-\x7e\u00a0-\u024f]{4,180}/g) || [];
  for (const candidata of [...ascii, ...utf16]) {
    const valor = candidata.replace(/\s+/g, " ").trim();
    const letras = (valor.match(/[\p{L}\p{N}]/gu) || []).length;
    const controle = (valor.match(/[^\p{L}\p{N}\s.,;:_()\[\]{}+\-/#@%&'=]/gu) || []).length;
    if (valor.length >= 4 && letras >= 3 && controle <= Math.max(2, valor.length * 0.15)) candidatas.push(valor);
  }
  return unicos(candidatas);
}

function analisarSkp(buffer, nomeArquivo, extensao) {
  const analise = baseAnalise(nomeArquivo, buffer, "modelo_sketchup", extensao);
  const strings = extrairStringsBinarias(buffer);
  const cabecalho = strings.find(valor => /sketchup model/i.test(valor));
  const versao = cabecalho?.match(/(?:version\s*)?([0-9]{1,4}(?:\.[0-9]+)?)/i)?.[1] || null;
  if (!cabecalho) analise.alertas.push("A assinatura textual do SketchUp não foi confirmada; o arquivo pode estar compactado ou usar uma versão não reconhecida.");
  analise.alertas.push("O arquivo SKP foi identificado, mas a geometria proprietária não foi decodificada. Dimensões e quantitativos não serão inventados.");
  analise.alertas.push("Para leitura geométrica local, exporte no SketchUp como DAE, OBJ ou STL. Para materiais e componentes, prefira também um relatório CSV.");

  return {
    ...analise,
    confiabilidade: "limitada_a_metadados",
    resumo: {
      versaoDetectada: versao,
      textosInternos: strings.length,
      geometriaLida: false
    },
    metadados: { cabecalho: cabecalho || null, versaoDetectada: versao },
    modelo: {
      leituraGeometrica: false,
      dimensoes: null,
      vertices: null,
      faces: null,
      materiais: [],
      nomesInternos: strings.filter(valor => !/sketchup model/i.test(valor)).slice(0, LIMITE_NOMES)
    }
  };
}

function criarLimites() {
  return {
    minimo: { x: Number.POSITIVE_INFINITY, y: Number.POSITIVE_INFINITY, z: Number.POSITIVE_INFINITY },
    maximo: { x: Number.NEGATIVE_INFINITY, y: Number.NEGATIVE_INFINITY, z: Number.NEGATIVE_INFINITY },
    pontos: 0
  };
}

function incluirPonto(limites, x, y, z) {
  if (![x, y, z].every(Number.isFinite)) return;
  limites.minimo.x = Math.min(limites.minimo.x, x);
  limites.minimo.y = Math.min(limites.minimo.y, y);
  limites.minimo.z = Math.min(limites.minimo.z, z);
  limites.maximo.x = Math.max(limites.maximo.x, x);
  limites.maximo.y = Math.max(limites.maximo.y, y);
  limites.maximo.z = Math.max(limites.maximo.z, z);
  limites.pontos++;
}

function dimensoesDosLimites(limites, unidade, escala = 1) {
  if (!limites.pontos) return null;
  const converter = ponto => ({
    x: arredondar(ponto.x * escala),
    y: arredondar(ponto.y * escala),
    z: arredondar(ponto.z * escala)
  });
  const minimo = converter(limites.minimo);
  const maximo = converter(limites.maximo);
  return {
    unidade,
    minimo,
    maximo,
    tamanho: {
      x: arredondar(maximo.x - minimo.x),
      y: arredondar(maximo.y - minimo.y),
      z: arredondar(maximo.z - minimo.z)
    }
  };
}

function analisarObj(buffer, nomeArquivo) {
  const analise = baseAnalise(nomeArquivo, buffer, "modelo_3d", ".obj");
  const limites = criarLimites();
  const objetos = [];
  const grupos = [];
  const materiais = [];
  const bibliotecasMateriais = [];
  let vertices = 0;
  let normais = 0;
  let faces = 0;
  let triangulosEstimados = 0;

  for (const linha of buffer.toString("utf8").split(/\r?\n/)) {
    const limpa = linha.trim();
    if (limpa.startsWith("v ")) {
      const valores = limpa.slice(2).trim().split(/\s+/).slice(0, 3).map(Number);
      incluirPonto(limites, valores[0], valores[1], valores[2]);
      vertices++;
    } else if (limpa.startsWith("vn ")) normais++;
    else if (limpa.startsWith("f ")) {
      const quantidade = limpa.slice(2).trim().split(/\s+/).filter(Boolean).length;
      faces++;
      triangulosEstimados += Math.max(0, quantidade - 2);
    } else if (limpa.startsWith("o ")) objetos.push(limpa.slice(2));
    else if (limpa.startsWith("g ")) grupos.push(limpa.slice(2));
    else if (limpa.startsWith("usemtl ")) materiais.push(limpa.slice(7));
    else if (limpa.startsWith("mtllib ")) bibliotecasMateriais.push(limpa.slice(7));
  }

  const dimensoes = dimensoesDosLimites(limites, "unidade não declarada");
  if (!vertices) analise.alertas.push("Nenhum vértice OBJ válido foi encontrado.");
  analise.alertas.push("O formato OBJ não declara uma unidade padrão. Confirme se as dimensões estão em milímetros, centímetros, metros ou polegadas.");

  return {
    ...analise,
    confiabilidade: vertices ? "alta_para_geometria_base" : "sem_geometria",
    resumo: { vertices, faces, triangulosEstimados, objetos: unicos(objetos).length, grupos: unicos(grupos).length, materiais: unicos(materiais).length },
    modelo: {
      leituraGeometrica: vertices > 0,
      dimensoes,
      vertices,
      normais,
      faces,
      triangulosEstimados,
      objetos: unicos(objetos),
      grupos: unicos(grupos),
      materiais: unicos(materiais),
      bibliotecasMateriais: unicos(bibliotecasMateriais)
    }
  };
}

function analisarDae(buffer, nomeArquivo) {
  const analise = baseAnalise(nomeArquivo, buffer, "modelo_3d", ".dae");
  const xml = buffer.toString("utf8");
  const $ = load(xml, { xmlMode: true });
  if (!$("COLLADA,collada").length) {
    throw new AppError("O arquivo não possui uma estrutura COLLADA/DAE válida.", { status: 422, code: "DAE_INVALID" });
  }

  const unidadeNo = $("asset unit").first();
  const metrosPorUnidade = Number(unidadeNo.attr("meter"));
  const escalaMm = Number.isFinite(metrosPorUnidade) && metrosPorUnidade > 0 ? metrosPorUnidade * 1000 : 1000;
  const nomeUnidade = unidadeNo.attr("name") || (escalaMm === 1000 ? "metro" : "unidade do arquivo");
  const fontesPosicao = new Set();
  $("vertices input").each((_, entrada) => {
    if (String($(entrada).attr("semantic") || "").toUpperCase() === "POSITION") {
      fontesPosicao.add(String($(entrada).attr("source") || "").replace(/^#/, ""));
    }
  });
  if (!fontesPosicao.size) {
    $("source[id]").each((_, fonte) => {
      const id = $(fonte).attr("id");
      if (/position/i.test(id || "")) fontesPosicao.add(id);
    });
  }

  const limites = criarLimites();
  let vertices = 0;
  for (const id of fontesPosicao) {
    const fonte = $("source").filter((_, no) => $(no).attr("id") === id).first();
    if (!fonte.length) continue;
    const numeros = fonte.find("float_array").first().text().trim().split(/\s+/).map(Number);
    const stride = Math.max(1, Number(fonte.find("accessor").first().attr("stride")) || 3);
    for (let indice = 0; indice + 2 < numeros.length; indice += stride) {
      incluirPonto(limites, numeros[indice], numeros[indice + 1], numeros[indice + 2]);
      vertices++;
    }
  }

  let triangulos = 0;
  $("triangles").each((_, no) => { triangulos += Number($(no).attr("count")) || 0; });
  let poligonos = 0;
  $("polylist").each((_, no) => { poligonos += Number($(no).attr("count")) || 0; });
  $("polygons").each((_, no) => { poligonos += $(no).children("p").length; });
  const geometrias = unicos($("library_geometries geometry").map((_, no) => $(no).attr("name") || $(no).attr("id")).get());
  const materiais = unicos($("library_materials material").map((_, no) => $(no).attr("name") || $(no).attr("id")).get());
  const nos = unicos($("visual_scene node").map((_, no) => $(no).attr("name") || $(no).attr("id")).get());
  const dimensoes = dimensoesDosLimites(limites, "mm", escalaMm);
  if (!vertices) analise.alertas.push("Nenhuma fonte de posições foi reconhecida no DAE.");
  analise.alertas.push("As dimensões DAE vêm das geometrias-base. Transformações e instâncias devem ser conferidas no SketchUp antes de fabricar.");

  return {
    ...analise,
    confiabilidade: vertices ? "boa_para_geometria_base" : "sem_geometria",
    resumo: { vertices, triangulos, poligonos, geometrias: geometrias.length, nos: nos.length, materiais: materiais.length },
    metadados: { unidadeDeclarada: nomeUnidade, metrosPorUnidade: Number.isFinite(metrosPorUnidade) ? metrosPorUnidade : null, eixoVertical: $("asset up_axis").first().text().trim() || null },
    modelo: {
      leituraGeometrica: vertices > 0,
      dimensoes,
      vertices,
      faces: triangulos + poligonos,
      triangulos,
      poligonos,
      geometrias,
      objetos: nos,
      materiais,
      imagensReferenciadas: $("library_images image").length
    }
  };
}

function analisarStl(buffer, nomeArquivo) {
  const analise = baseAnalise(nomeArquivo, buffer, "modelo_3d", ".stl");
  const limites = criarLimites();
  const possivelQuantidade = buffer.length >= 84 ? buffer.readUInt32LE(80) : 0;
  const binario = buffer.length >= 84 && 84 + possivelQuantidade * 50 <= buffer.length && !buffer.subarray(0, 5).toString("ascii").toLowerCase().startsWith("solid");
  let triangulos = 0;
  let nomeSolido = null;

  if (binario) {
    triangulos = Math.min(possivelQuantidade, Math.floor((buffer.length - 84) / 50));
    for (let indice = 0; indice < triangulos; indice++) {
      const inicio = 84 + indice * 50 + 12;
      for (let vertice = 0; vertice < 3; vertice++) {
        const posicao = inicio + vertice * 12;
        incluirPonto(limites, buffer.readFloatLE(posicao), buffer.readFloatLE(posicao + 4), buffer.readFloatLE(posicao + 8));
      }
    }
  } else {
    const texto = buffer.toString("utf8");
    nomeSolido = texto.match(/^\s*solid\s+(.+)$/im)?.[1]?.trim() || null;
    for (const correspondencia of texto.matchAll(/^\s*vertex\s+([-+\d.eE]+)\s+([-+\d.eE]+)\s+([-+\d.eE]+)/gim)) {
      incluirPonto(limites, Number(correspondencia[1]), Number(correspondencia[2]), Number(correspondencia[3]));
    }
    triangulos = Math.floor(limites.pontos / 3);
  }

  if (!triangulos) analise.alertas.push("Nenhum triângulo STL válido foi encontrado.");
  analise.alertas.push("O formato STL não grava a unidade de medida. Confirme a escala antes de usar as dimensões para compra ou corte.");
  return {
    ...analise,
    confiabilidade: triangulos ? "alta_para_malha" : "sem_geometria",
    resumo: { tipo: binario ? "binário" : "texto", triangulos, verticesProcessados: limites.pontos },
    modelo: {
      leituraGeometrica: triangulos > 0,
      dimensoes: dimensoesDosLimites(limites, "unidade não declarada"),
      vertices: limites.pontos,
      faces: triangulos,
      triangulos,
      objetos: nomeSolido ? [nomeSolido] : [],
      materiais: []
    }
  };
}

function normalizarChave(valor) {
  return String(valor ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function numeroEstruturado(valor) {
  if (typeof valor === "number") return Number.isFinite(valor) ? valor : null;
  let bruto = String(valor ?? "").trim().replace(/[^\d,.-]/g, "");
  if (!bruto) return null;
  if (bruto.includes(",") && bruto.includes(".")) bruto = bruto.replace(/\./g, "").replace(",", ".");
  else bruto = bruto.replace(",", ".");
  const numero = Number(bruto);
  return Number.isFinite(numero) ? numero : null;
}

function campoRegistro(registro, nomes) {
  for (const nome of nomes) {
    const valor = registro[normalizarChave(nome)];
    if (valor != null && String(valor).trim()) return valor;
  }
  return null;
}

function mapearPecaPromob(registro) {
  const nome = campoRegistro(registro, ["descricao", "descrição", "descricao_item", "descricao_do_item", "nome", "nome_item", "peca", "peça", "item", "produto", "referencia", "referência"]);
  const material = campoRegistro(registro, ["material", "tipo_material", "descricao_material", "materia_prima", "matéria prima", "chapa", "acabamento"]);
  const largura = numeroEstruturado(campoRegistro(registro, ["largura", "largura_peca", "largura_final", "width", "dimensao_x", "dimensão x"]));
  const altura = numeroEstruturado(campoRegistro(registro, ["altura", "altura_peca", "altura_final", "height", "dimensao_y", "dimensão y"]));
  const comprimento = numeroEstruturado(campoRegistro(registro, ["comprimento", "comprimento_peca", "comprimento_final", "length", "comp"]));
  const profundidade = numeroEstruturado(campoRegistro(registro, ["profundidade", "profundidade_peca", "depth", "dimensao_z", "dimensão z"]));
  const espessura = numeroEstruturado(campoRegistro(registro, ["espessura", "espessura_peca", "thickness"]));
  const quantidade = numeroEstruturado(campoRegistro(registro, ["quantidade", "quantidade_item", "qtd", "qtd_item", "qtde", "quant", "quantity"]));
  const dimensoes = [largura, altura, comprimento, profundidade, espessura].filter(valor => valor != null);
  if (!nome && !material && dimensoes.length < 2) return null;
  if (!dimensoes.length && quantidade == null) return null;
  return {
    nome: String(nome || material || "Peça sem descrição").trim().slice(0, 500),
    material: material == null ? null : String(material).trim().slice(0, 300),
    largura,
    altura,
    comprimento,
    profundidade,
    espessura,
    quantidade: quantidade == null ? null : quantidade
  };
}

function dividirLinhaDelimitada(linha, delimitador) {
  const campos = [];
  let atual = "";
  let aspas = false;
  for (let indice = 0; indice < linha.length; indice++) {
    const caractere = linha[indice];
    if (caractere === '"') {
      if (aspas && linha[indice + 1] === '"') { atual += '"'; indice++; }
      else aspas = !aspas;
    } else if (caractere === delimitador && !aspas) {
      campos.push(atual.trim());
      atual = "";
    } else atual += caractere;
  }
  campos.push(atual.trim());
  return campos;
}

function extrairPecasDelimitadas(texto) {
  const linhas = textoLimpo(texto).split("\n").filter(linha => linha.trim()).slice(0, 30_000);
  if (linhas.length < 2) return [];
  const delimitadores = [";", "\t", ",", "|"];
  const delimitador = delimitadores
    .map(valor => ({ valor, quantidade: (linhas[0].match(new RegExp(valor === "|" ? "\\|" : valor, "g")) || []).length }))
    .sort((a, b) => b.quantidade - a.quantidade)[0];
  if (!delimitador?.quantidade) return [];
  const cabecalhos = dividirLinhaDelimitada(linhas[0], delimitador.valor).map(normalizarChave);
  if (!cabecalhos.some(cabecalho => /^(descricao|nome|peca|item|produto|material|largura|altura|comprimento)$/.test(cabecalho))) return [];
  const pecas = [];
  for (const linha of linhas.slice(1)) {
    const valores = dividirLinhaDelimitada(linha, delimitador.valor);
    const registro = Object.fromEntries(cabecalhos.map((cabecalho, indice) => [cabecalho, valores[indice]]));
    const peca = mapearPecaPromob(registro);
    if (peca) pecas.push(peca);
    if (pecas.length >= 10_000) break;
  }
  return pecas;
}

function extrairPecasXml(xml) {
  let $;
  try { $ = load(xml, { xmlMode: true }); }
  catch { return []; }
  const pecas = [];
  $("*").each((_, no) => {
    if (pecas.length >= 10_000) return false;
    const tag = normalizarChave(no.tagName);
    if (!/(^|_)(item|produto|peca|part|component|composicao)(_|$)/.test(tag)) return;
    const registro = {};
    for (const [chave, valor] of Object.entries(no.attribs || {})) registro[normalizarChave(chave)] = valor;
    $(no).children().each((__, filho) => {
      const chave = normalizarChave(filho.tagName);
      if (chave && registro[chave] == null) registro[chave] = $(filho).text().trim();
    });
    $(no).find("*").slice(0, 200).each((__, descendente) => {
      const atributos = descendente.attribs || {};
      const chave = atributos.nome ?? atributos.NOME ?? atributos.name ?? atributos.NAME;
      const valor = atributos.valor ?? atributos.VALOR ?? atributos.value ?? atributos.VALUE;
      if (chave && valor != null) registro[normalizarChave(chave)] = valor;
    });
    const peca = mapearPecaPromob(registro);
    if (peca) pecas.push(peca);
  });
  return pecas;
}

function deduplicarPecas(pecas) {
  const vistas = new Set();
  const resultado = [];
  for (const peca of pecas) {
    const chave = JSON.stringify(peca);
    if (vistas.has(chave)) continue;
    vistas.add(chave);
    resultado.push(peca);
  }
  return resultado;
}

function pareceTexto(buffer) {
  const amostra = buffer.subarray(0, Math.min(buffer.length, 100_000));
  if (!amostra.length) return false;
  let legiveis = 0;
  for (const byte of amostra) if (byte === 9 || byte === 10 || byte === 13 || (byte >= 32 && byte <= 126) || byte >= 160) legiveis++;
  return legiveis / amostra.length > 0.82;
}

async function textosDeContainerZip(buffer, alertas) {
  if (buffer[0] !== 0x50 || buffer[1] !== 0x4b) return { arquivos: [], textos: [] };
  let zip;
  try { zip = await JSZip.loadAsync(buffer); }
  catch { return { arquivos: [], textos: [] }; }
  const arquivos = [];
  const textos = [];
  let totalExtraido = 0;
  for (const entrada of Object.values(zip.files).slice(0, 2_000)) {
    if (entrada.dir) continue;
    const tamanho = Number(entrada?._data?.uncompressedSize) || null;
    arquivos.push({ nome: entrada.name.slice(0, 500), tamanhoBytes: tamanho });
    if (!/\.(xml|json|txt|csv|ini|cfg|log)$/i.test(entrada.name)) continue;
    if (tamanho != null && tamanho > 3 * 1024 * 1024) continue;
    if (totalExtraido >= 6 * 1024 * 1024) break;
    try {
      const conteudo = await entrada.async("string");
      const limitado = conteudo.slice(0, Math.max(0, 6 * 1024 * 1024 - totalExtraido));
      totalExtraido += limitado.length;
      textos.push({ nome: entrada.name, conteudo: limitado });
    } catch {}
  }
  if (Object.keys(zip.files).length > 2_000) alertas.push("O contêiner possui mais de 2.000 entradas; somente as primeiras foram inventariadas.");
  if (totalExtraido >= 6 * 1024 * 1024) alertas.push("A extração de textos internos foi limitada a 6 MB para proteger a memória do computador.");
  return { arquivos, textos };
}

async function analisarPromob(buffer, nomeArquivo, extensao) {
  const nativo = [".promob", ".bak", ".cut", ".planner"].includes(extensao);
  const analise = baseAnalise(nomeArquivo, buffer, "projeto_promob", extensao);
  const container = await textosDeContainerZip(buffer, analise.alertas);
  const limiteLeitura = Math.min(buffer.length, 8 * 1024 * 1024);
  const textoPrincipal = [".xml", ".csv", ".txt"].includes(extensao) || pareceTexto(buffer)
    ? buffer.subarray(0, limiteLeitura).toString("utf8")
    : "";
  if (buffer.length > limiteLeitura && textoPrincipal) analise.alertas.push("A leitura estruturada foi limitada aos primeiros 8 MB para proteger a memória do computador.");
  const fontesTexto = [
    ...(textoPrincipal ? [{ nome: nomeArquivo, conteudo: textoPrincipal }] : []),
    ...container.textos
  ];
  const pecas = [];
  for (const fonte of fontesTexto) {
    pecas.push(...extrairPecasDelimitadas(fonte.conteudo));
    if (/^\s*</.test(fonte.conteudo)) pecas.push(...extrairPecasXml(fonte.conteudo));
  }
  const pecasUnicas = deduplicarPecas(pecas).slice(0, 3_000);
  const strings = extrairStringsBinarias(buffer);
  const materiais = unicos(pecasUnicas.map(peca => peca.material).filter(Boolean));

  if (nativo) {
    analise.alertas.push("O projeto nativo do Promob foi inspecionado localmente. Partes proprietárias ou vinculadas à nuvem podem não estar acessíveis fora do Promob.");
  }
  if (!pecasUnicas.length) {
    analise.alertas.push("Nenhuma lista estruturada de peças foi reconhecida. Para quantitativos confiáveis, exporte pelo Promob/Builder em CSV, XML ou TXT.");
  }
  if (extensao === ".cut") analise.alertas.push("Arquivos CUT pertencem ao Cut Pro; confirme o plano no próprio Cut Pro antes de enviar à produção.");

  const textoVisual = fontesTexto.map(fonte => `### ${fonte.nome}\n${fonte.conteudo}`).join("\n\n");
  return {
    ...analise,
    confiabilidade: pecasUnicas.length ? "boa_para_lista_exportada" : "limitada_a_metadados",
    resumo: {
      pecasDetectadas: pecasUnicas.length,
      materiais: materiais.length,
      arquivosInternos: container.arquivos.length,
      textosInternos: strings.length,
      leituraEstruturada: pecasUnicas.length > 0
    },
    promob: {
      projetoNativo: nativo,
      pecas: pecasUnicas,
      materiais,
      arquivosInternos: container.arquivos,
      nomesInternos: strings.slice(0, LIMITE_NOMES)
    },
    conteudo: {
      texto: limitarTexto(textoVisual || strings.join("\n"), analise.alertas, "O conteúdo legível do arquivo"),
      arquivosInternos: container.arquivos
    }
  };
}

export async function analisarBufferArquivo(bufferOriginal, nomeArquivo) {
  const buffer = Buffer.isBuffer(bufferOriginal) ? bufferOriginal : Buffer.from(bufferOriginal || []);
  const extensao = path.extname(String(nomeArquivo || "")).toLowerCase();
  if (!EXTENSOES_ARQUIVO_SUPORTADAS.includes(extensao)) {
    throw new AppError(`Formato ${extensao || "sem extensão"} não suportado.`, { status: 415, code: "FILE_TYPE_UNSUPPORTED" });
  }
  if (!buffer.length) throw new AppError("O arquivo está vazio.", { status: 422, code: "FILE_EMPTY" });

  if (extensao === ".pdf") return analisarPdf(buffer, nomeArquivo);
  if (extensao === ".docx") return analisarDocx(buffer, nomeArquivo);
  if (extensao === ".skp" || extensao === ".skb") return analisarSkp(buffer, nomeArquivo, extensao);
  if (extensao === ".obj") return analisarObj(buffer, nomeArquivo);
  if (extensao === ".dae") return analisarDae(buffer, nomeArquivo);
  if (extensao === ".stl") return analisarStl(buffer, nomeArquivo);
  return analisarPromob(buffer, nomeArquivo, extensao);
}

export async function analisarArquivoLocal(caminho, nomeArquivo = path.basename(caminho)) {
  return analisarBufferArquivo(await fs.readFile(caminho), nomeArquivo);
}
