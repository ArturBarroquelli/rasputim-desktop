import path from "node:path";

export function texto(valor, limite = 10000) {
  return String(valor ?? "").replace(/\s+/g, " ").trim().slice(0, limite);
}

export function normalizarTexto(valor) {
  return texto(valor)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

export function nomeSeguro(valor, padrao = "arquivo") {
  return normalizarTexto(valor || padrao)
    .replace(/[^a-z0-9-_]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 70) || padrao;
}

export function limitarNumero(valor, padrao, minimo, maximo) {
  const convertido = Number(valor);
  if (!Number.isFinite(convertido)) return padrao;
  return Math.min(Math.max(convertido, minimo), maximo);
}

export function caminhoFilhoSeguro(diretorio, nomeArquivo) {
  const raiz = path.resolve(diretorio);
  const destino = path.resolve(raiz, path.basename(String(nomeArquivo || "")));
  if (!destino.startsWith(`${raiz}${path.sep}`)) {
    throw new Error("Caminho de arquivo inválido.");
  }
  return destino;
}

export function extrairJSON(textoModelo) {
  const bruto = String(textoModelo || "").trim();
  const semCerca = bruto
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  try {
    return JSON.parse(semCerca);
  } catch {}

  const inicio = semCerca.indexOf("{");
  const fim = semCerca.lastIndexOf("}");
  if (inicio >= 0 && fim > inicio) {
    return JSON.parse(semCerca.slice(inicio, fim + 1));
  }

  throw new Error("O modelo não retornou JSON válido.");
}

export function removerRaciocinio(textoModelo) {
  const valor = String(textoModelo || "");
  const limpo = valor.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  return limpo || valor.trim();
}
