import ExcelJS from "exceljs";
import fs from "node:fs/promises";
import path from "node:path";

function numero(valor, padrao = 0) {
  const convertido = Number(valor);
  return Number.isFinite(convertido) ? convertido : padrao;
}

function nomeSeguro(texto) {
  return String(texto || "orcamento")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9-_]/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 60) || "orcamento";
}

function aplicarBorda(cell) {
  cell.border = {
    top: { style: "thin", color: { argb: "FFE5E7EB" } },
    left: { style: "thin", color: { argb: "FFE5E7EB" } },
    bottom: { style: "thin", color: { argb: "FFE5E7EB" } },
    right: { style: "thin", color: { argb: "FFE5E7EB" } }
  };
}

export async function gerarOrcamentoMoveis(dados = {}) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Rasputim";
  workbook.created = new Date();

  const sheet = workbook.addWorksheet("Orçamento", {
    views: [{ state: "frozen", ySplit: 8 }]
  });

  const cliente = dados.cliente || {};
  const projeto = dados.projeto || {};
  const itens = Array.isArray(dados.itens) ? dados.itens : [];
  const margemLucro = numero(dados.margemLucro, 30) / 100;
  const desconto = numero(dados.desconto, 0) / 100;

  sheet.columns = [
    { header: "Ambiente", key: "ambiente", width: 22 },
    { header: "Item", key: "item", width: 28 },
    { header: "Descrição", key: "descricao", width: 42 },
    { header: "Material", key: "material", width: 22 },
    { header: "Largura (m)", key: "largura", width: 14 },
    { header: "Altura (m)", key: "altura", width: 14 },
    { header: "Profundidade (m)", key: "profundidade", width: 17 },
    { header: "Qtd.", key: "quantidade", width: 10 },
    { header: "Área m²", key: "area", width: 12 },
    { header: "Custo material", key: "custoMaterial", width: 16 },
    { header: "Ferragens", key: "ferragens", width: 14 },
    { header: "Mão de obra", key: "maoObra", width: 14 },
    { header: "Custo total", key: "custoTotal", width: 14 },
    { header: "Preço venda", key: "precoVenda", width: 14 }
  ];

  sheet.mergeCells("A1:N1");
  sheet.getCell("A1").value = "ORÇAMENTO DE MÓVEIS PLANEJADOS";
  sheet.getCell("A1").font = { bold: true, size: 16, color: { argb: "FFFFFFFF" } };
  sheet.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F2937" } };
  sheet.getCell("A1").alignment = { horizontal: "center" };

  sheet.getCell("A3").value = "Cliente:";
  sheet.getCell("B3").value = cliente.nome || "";
  sheet.getCell("A4").value = "Telefone:";
  sheet.getCell("B4").value = cliente.telefone || "";
  sheet.getCell("A5").value = "Endereço:";
  sheet.getCell("B5").value = cliente.endereco || "";

  sheet.getCell("D3").value = "Projeto:";
  sheet.getCell("E3").value = projeto.nome || "";
  sheet.getCell("D4").value = "Data:";
  sheet.getCell("E4").value = new Date();
  sheet.getCell("E4").numFmt = "dd/mm/yyyy";
  sheet.getCell("D5").value = "Validade:";
  sheet.getCell("E5").value = projeto.validade || "7 dias";

  sheet.getCell("G3").value = "Margem:";
  sheet.getCell("H3").value = margemLucro;
  sheet.getCell("H3").numFmt = "0%";
  sheet.getCell("G4").value = "Desconto:";
  sheet.getCell("H4").value = desconto;
  sheet.getCell("H4").numFmt = "0%";

  for (const celula of ["A3", "A4", "A5", "D3", "D4", "D5", "G3", "G4"]) {
    sheet.getCell(celula).font = { bold: true };
  }

  const headerRow = 8;
  sheet.getRow(headerRow).values = [
    "Ambiente", "Item", "Descrição", "Material", "Largura (m)", "Altura (m)",
    "Profundidade (m)", "Qtd.", "Área m²", "Custo material", "Ferragens",
    "Mão de obra", "Custo total", "Preço venda"
  ];
  sheet.getRow(headerRow).font = { bold: true, color: { argb: "FFFFFFFF" } };
  sheet.getRow(headerRow).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF374151" } };
  sheet.getRow(headerRow).alignment = { horizontal: "center", vertical: "middle" };

  let linha = headerRow + 1;
  for (const item of itens) {
    sheet.getRow(linha).values = [
      item.ambiente || "",
      item.item || "",
      item.descricao || "",
      item.material || "",
      numero(item.largura),
      numero(item.altura),
      numero(item.profundidade),
      numero(item.quantidade, 1),
      null,
      numero(item.custoMaterial),
      numero(item.ferragens),
      numero(item.maoObra),
      null,
      null
    ];

    sheet.getCell(`I${linha}`).value = { formula: `E${linha}*F${linha}*H${linha}`, result: 0 };
    sheet.getCell(`M${linha}`).value = { formula: `(J${linha}+K${linha}+L${linha})*H${linha}`, result: 0 };
    sheet.getCell(`N${linha}`).value = { formula: `M${linha}*(1+$H$3)`, result: 0 };
    linha++;
  }

  const primeiraLinhaItens = headerRow + 1;
  const linhaResumo = linha + 2;

  sheet.getCell(`M${linhaResumo}`).value = "Subtotal:";
  sheet.getCell(`N${linhaResumo}`).value = itens.length ? { formula: `SUM(N${primeiraLinhaItens}:N${linha - 1})`, result: 0 } : 0;
  sheet.getCell(`M${linhaResumo + 1}`).value = "Desconto:";
  sheet.getCell(`N${linhaResumo + 1}`).value = { formula: `N${linhaResumo}*$H$4`, result: 0 };
  sheet.getCell(`M${linhaResumo + 2}`).value = "Total final:";
  sheet.getCell(`N${linhaResumo + 2}`).value = { formula: `N${linhaResumo}-N${linhaResumo + 1}`, result: 0 };

  for (let row = primeiraLinhaItens; row <= linha - 1; row++) {
    sheet.getRow(row).alignment = { vertical: "top", wrapText: true };
    for (const col of ["J", "K", "L", "M", "N"]) {
      sheet.getCell(`${col}${row}`).numFmt = 'R$ #,##0.00';
    }
    sheet.getCell(`I${row}`).numFmt = "0.00";
  }

  for (const cell of [`N${linhaResumo}`, `N${linhaResumo + 1}`, `N${linhaResumo + 2}`]) {
    sheet.getCell(cell).numFmt = 'R$ #,##0.00';
  }
  for (const cell of [`M${linhaResumo}`, `M${linhaResumo + 1}`, `M${linhaResumo + 2}`, `N${linhaResumo + 2}`]) {
    sheet.getCell(cell).font = { bold: true };
  }

  sheet.autoFilter = {
    from: { row: headerRow, column: 1 },
    to: { row: Math.max(linha - 1, headerRow), column: 14 }
  };

  for (let r = 1; r <= linhaResumo + 2; r++) {
    for (let c = 1; c <= 14; c++) {
      aplicarBorda(sheet.getCell(r, c));
    }
  }

  const materiais = workbook.addWorksheet("Materiais");
  materiais.columns = [
    { header: "Categoria", key: "categoria", width: 24 },
    { header: "Descrição", key: "descricao", width: 42 },
    { header: "Quantidade", key: "quantidade", width: 14 },
    { header: "Valor unitário", key: "valorUnitario", width: 16 },
    { header: "Total", key: "total", width: 16 }
  ];
  materiais.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
  materiais.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF374151" } };

  const materiaisDados = Array.isArray(dados.materiais) ? dados.materiais : [];
  let linhaMaterial = 2;
  for (const material of materiaisDados) {
    materiais.getRow(linhaMaterial).values = [
      material.categoria || "",
      material.descricao || "",
      numero(material.quantidade, 1),
      numero(material.valorUnitario),
      null
    ];
    materiais.getCell(`E${linhaMaterial}`).value = { formula: `C${linhaMaterial}*D${linhaMaterial}`, result: 0 };
    materiais.getCell(`D${linhaMaterial}`).numFmt = 'R$ #,##0.00';
    materiais.getCell(`E${linhaMaterial}`).numFmt = 'R$ #,##0.00';
    linhaMaterial++;
  }

  for (let r = 1; r <= Math.max(linhaMaterial, 2); r++) {
    for (let c = 1; c <= 5; c++) {
      aplicarBorda(materiais.getCell(r, c));
    }
  }

  const obs = workbook.addWorksheet("Observações");
  obs.getCell("A1").value = "Observações do orçamento";
  obs.getCell("A1").font = { bold: true, size: 14 };
  obs.getCell("A3").value = dados.observacoes || "Sem observações adicionais.";
  obs.getCell("A3").alignment = { wrapText: true, vertical: "top" };
  obs.getColumn("A").width = 90;
  obs.getRow(3).height = 120;

  await fs.mkdir("./orcamentos", { recursive: true });
  const nomeCliente = nomeSeguro(cliente.nome || "cliente");
  const nomeProjeto = nomeSeguro(projeto.nome || "projeto");
  const arquivo = path.resolve("./orcamentos", `orcamento_${nomeCliente}_${nomeProjeto}_${Date.now()}.xlsx`);

  await workbook.xlsx.writeFile(arquivo);
  return arquivo;
}

export async function lerPlanilhaExcel(caminhoArquivo) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(caminhoArquivo);

  const resultado = [];
  workbook.eachSheet((worksheet) => {
    const linhas = [];

    worksheet.eachRow((row, rowNumber) => {
      linhas.push({
        linha: rowNumber,
        valores: row.values.slice(1).map(valor => {
          if (valor && typeof valor === "object" && "formula" in valor) {
            return { formula: valor.formula, resultado: valor.result };
          }
          return valor;
        })
      });
    });

    resultado.push({ aba: worksheet.name, linhas });
  });

  return resultado;
}

export async function gerarPlanilhaPesquisaMercado(relatorio = {}) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Rasputim v5";
  workbook.created = new Date();

  const sheet = workbook.addWorksheet("Pesquisa de mercado", {
    views: [{ state: "frozen", ySplit: 8 }]
  });

  sheet.columns = [
    { width: 12 },
    { width: 24 },
    { width: 48 },
    { width: 16 },
    { width: 15 },
    { width: 16 },
    { width: 22 },
    { width: 14 },
    { width: 18 }
  ];

  sheet.mergeCells("A1:I1");
  sheet.getCell("A1").value = "PESQUISA DE MERCADO E MATERIAIS";
  sheet.getCell("A1").font = { bold: true, size: 16, color: { argb: "FFFFFFFF" } };
  sheet.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F2937" } };
  sheet.getCell("A1").alignment = { horizontal: "center", vertical: "middle" };
  sheet.getRow(1).height = 28;

  sheet.getCell("A3").value = "Consulta:";
  sheet.getCell("B3").value = relatorio.consulta || "";
  sheet.mergeCells("B3:E3");
  sheet.getCell("F3").value = "Região:";
  sheet.getCell("G3").value = relatorio.regiao || "Brasil";
  sheet.mergeCells("G3:I3");

  sheet.getCell("A4").value = "Coletado em:";
  sheet.getCell("B4").value = relatorio.coletadoEm ? new Date(relatorio.coletadoEm) : new Date();
  sheet.getCell("B4").numFmt = "dd/mm/yyyy hh:mm";
  sheet.getCell("F4").value = "Provedor:";
  sheet.getCell("G4").value = relatorio.provedorPesquisa || "";

  sheet.getCell("A5").value = "Resumo:";
  sheet.getCell("B5").value = relatorio.resumo || "";
  sheet.mergeCells("B5:I6");
  sheet.getCell("B5").alignment = { wrapText: true, vertical: "top" };

  for (const endereco of ["A3", "F3", "A4", "F4", "A5"]) {
    sheet.getCell(endereco).font = { bold: true };
  }

  const cabecalhos = ["Fonte", "Fornecedor", "Descrição", "Preço", "Unidade", "Frete", "Disponibilidade", "Confiança", "Link"];
  sheet.getRow(8).values = cabecalhos;
  sheet.getRow(8).font = { bold: true, color: { argb: "FFFFFFFF" } };
  sheet.getRow(8).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF374151" } };
  sheet.getRow(8).alignment = { horizontal: "center", vertical: "middle" };

  const ofertas = Array.isArray(relatorio.ofertas) ? relatorio.ofertas : [];
  let linha = 9;
  for (const oferta of ofertas) {
    sheet.getRow(linha).values = [
      oferta.fonteId || "",
      oferta.fornecedor || "",
      oferta.descricao || "",
      oferta.preco == null ? null : numero(oferta.preco, 0),
      oferta.unidade || "",
      oferta.frete == null ? null : numero(oferta.frete, 0),
      oferta.disponibilidade || "",
      oferta.confianca || "baixa",
      oferta.url ? { text: "Abrir fonte", hyperlink: oferta.url } : ""
    ];
    sheet.getCell(`D${linha}`).numFmt = 'R$ #,##0.00';
    sheet.getCell(`F${linha}`).numFmt = 'R$ #,##0.00';
    sheet.getRow(linha).alignment = { vertical: "top", wrapText: true };

    if (oferta.fonteId && oferta.fonteId === relatorio.melhorOfertaFonteId) {
      sheet.getRow(linha).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFD1FAE5" } };
      sheet.getRow(linha).font = { bold: true };
    }
    linha++;
  }

  if (!ofertas.length) {
    sheet.mergeCells("A9:I10");
    sheet.getCell("A9").value = "Nenhuma oferta com preço confirmado foi encontrada.";
    sheet.getCell("A9").alignment = { horizontal: "center", vertical: "middle" };
    linha = 11;
  }

  const linhaAlertas = linha + 2;
  sheet.getCell(`A${linhaAlertas}`).value = "Alertas e limitações";
  sheet.getCell(`A${linhaAlertas}`).font = { bold: true, color: { argb: "FF991B1B" } };
  sheet.mergeCells(`A${linhaAlertas}:I${linhaAlertas}`);

  const alertas = Array.isArray(relatorio.alertas) ? relatorio.alertas : [];
  let linhaAlerta = linhaAlertas + 1;
  for (const alerta of alertas) {
    sheet.getCell(`A${linhaAlerta}`).value = `• ${alerta}`;
    sheet.mergeCells(`A${linhaAlerta}:I${linhaAlerta}`);
    sheet.getCell(`A${linhaAlerta}`).alignment = { wrapText: true };
    linhaAlerta++;
  }

  const fontesSheet = workbook.addWorksheet("Fontes");
  fontesSheet.columns = [
    { header: "ID", key: "id", width: 10 },
    { header: "Título", key: "titulo", width: 45 },
    { header: "Fornecedor", key: "fornecedor", width: 24 },
    { header: "Preço exibido", key: "preco", width: 18 },
    { header: "Leitura", key: "leitura", width: 22 },
    { header: "URL", key: "url", width: 70 },
    { header: "Trecho", key: "trecho", width: 80 }
  ];
  fontesSheet.getRow(1).font = { bold: true, color: { argb: "FFFFFFFF" } };
  fontesSheet.getRow(1).fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF374151" } };
  fontesSheet.views = [{ state: "frozen", ySplit: 1 }];

  for (const fonte of Array.isArray(relatorio.fontes) ? relatorio.fontes : []) {
    fontesSheet.addRow({
      id: fonte.id,
      titulo: fonte.titulo,
      fornecedor: fonte.fornecedor,
      preco: fonte.precoExibido,
      leitura: fonte.leitura,
      url: fonte.url,
      trecho: fonte.resumo || fonte.conteudo
    });
  }
  fontesSheet.eachRow((row, rowNumber) => {
    row.alignment = { vertical: "top", wrapText: rowNumber > 1 };
  });

  const especificacoesSheet = workbook.addWorksheet("Critérios");
  especificacoesSheet.getCell("A1").value = "Especificações consideradas";
  especificacoesSheet.getCell("A1").font = { bold: true, size: 14 };
  especificacoesSheet.getColumn("A").width = 90;
  let linhaEspecificacao = 3;
  for (const especificacao of Array.isArray(relatorio.especificacoes) ? relatorio.especificacoes : []) {
    especificacoesSheet.getCell(`A${linhaEspecificacao++}`).value = `• ${especificacao}`;
  }
  especificacoesSheet.getCell(`A${linhaEspecificacao + 1}`).value = "Conclusão";
  especificacoesSheet.getCell(`A${linhaEspecificacao + 1}`).font = { bold: true, size: 12 };
  especificacoesSheet.getCell(`A${linhaEspecificacao + 2}`).value = relatorio.conclusao || "";
  especificacoesSheet.getCell(`A${linhaEspecificacao + 2}`).alignment = { wrapText: true, vertical: "top" };
  especificacoesSheet.getRow(linhaEspecificacao + 2).height = 90;

  await fs.mkdir("./orcamentos", { recursive: true });
  const nome = nomeSeguro(relatorio.consulta || "pesquisa_mercado");
  const arquivo = path.resolve("./orcamentos", `pesquisa_mercado_${nome}_${Date.now()}.xlsx`);
  await workbook.xlsx.writeFile(arquivo);
  return arquivo;
}

function estilizarCabecalhoTabela(linha) {
  linha.font = { bold: true, color: { argb: "FFFFFFFF" } };
  linha.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF374151" } };
  linha.alignment = { horizontal: "center", vertical: "middle" };
  linha.height = 24;
}

function criarResumoPlanoCorte(workbook, plano) {
  const sheet = workbook.addWorksheet("Resumo e compra", { views: [{ state: "frozen", ySplit: 9 }] });
  sheet.columns = [
    { width: 27 }, { width: 34 }, { width: 15 }, { width: 18 }, { width: 18 }, { width: 24 }
  ];
  sheet.mergeCells("A1:F1");
  sheet.getCell("A1").value = "PLANO DE COMPRA E APROVEITAMENTO";
  sheet.getCell("A1").font = { bold: true, size: 16, color: { argb: "FFFFFFFF" } };
  sheet.getCell("A1").fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1F2937" } };
  sheet.getCell("A1").alignment = { horizontal: "center", vertical: "middle" };
  sheet.getRow(1).height = 30;

  sheet.getCell("A3").value = "Material:";
  sheet.getCell("B3").value = plano.material || "";
  sheet.mergeCells("B3:D3");
  sheet.getCell("E3").value = "Calculado em:";
  sheet.getCell("F3").value = plano.calculadoEm ? new Date(plano.calculadoEm) : new Date();
  sheet.getCell("F3").numFmt = "dd/mm/yyyy hh:mm";
  sheet.getCell("A4").value = "Método:";
  sheet.getCell("B4").value = plano.tipo === "otimizacao_chapas_2d" ? "Chapas — encaixe guilhotinado 2D" : "Barras — corte linear 1D";
  sheet.mergeCells("B4:D4");
  sheet.getCell("E4").value = "Unidade:";
  sheet.getCell("F4").value = plano.unidade || "mm";
  for (const endereco of ["A3", "E3", "A4", "E4"]) sheet.getCell(endereco).font = { bold: true };

  sheet.getRow(7).values = ["Item de compra", "Dimensão comercial", "Quantidade", "Preço unitário", "Total", "Objetivo"];
  estilizarCabecalhoTabela(sheet.getRow(7));
  if (plano.tipo === "otimizacao_chapas_2d") {
    const chapa = plano.compra.chapa;
    sheet.getRow(8).values = [
      chapa.nome || plano.material,
      `${chapa.largura} × ${chapa.altura} mm`,
      plano.compra.quantidade,
      chapa.preco,
      null,
      plano.objetivo === "custo" ? "Menor custo" : "Menor desperdício"
    ];
  } else {
    const barra = plano.compra.barra;
    sheet.getRow(8).values = [
      barra.nome || plano.material,
      `${barra.comprimento} mm`,
      plano.compra.quantidade,
      barra.preco,
      null,
      barra.preco == null ? "Menor desperdício" : "Menor custo"
    ];
  }
  sheet.getCell("E8").value = { formula: 'IF(D8="","",C8*D8)', result: plano.compra.custoTotal ?? 0 };
  sheet.getCell("D8").numFmt = 'R$ #,##0.00';
  sheet.getCell("E8").numFmt = 'R$ #,##0.00';

  sheet.getCell("A11").value = "INDICADORES";
  sheet.getCell("A11").font = { bold: true, size: 13, color: { argb: "FFD3A95F" } };
  const indicadores = plano.tipo === "otimizacao_chapas_2d"
    ? [
        ["Área útil das peças", plano.metricas.areaPecasM2, "m²"],
        ["Área comprada", plano.metricas.areaCompradaM2, "m²"],
        ["Perda total", plano.metricas.perdaTotalM2, "m²"],
        ["Sobra reutilizável", plano.metricas.areaReutilizavelM2, "m²"],
        ["Aproveitamento", plano.metricas.aproveitamentoPercentual / 100, "%"],
        ["Cortes estimados", plano.metricas.cortesEstimados, "cortes"]
      ]
    : [
        ["Comprimento útil das peças", plano.metricas.comprimentoPecasM, "m"],
        ["Comprimento comprado", plano.metricas.comprimentoCompradoM, "m"],
        ["Sobra total", plano.metricas.sobraTotalM, "m"],
        ["Sobra reutilizável", plano.metricas.sobraReutilizavelM, "m"],
        ["Aproveitamento", plano.metricas.aproveitamentoPercentual / 100, "%"],
        ["Cortes estimados", plano.metricas.cortesEstimados, "cortes"]
      ];
  let linhaIndicador = 13;
  for (const [rotulo, valor, unidade] of indicadores) {
    sheet.getCell(`A${linhaIndicador}`).value = rotulo;
    sheet.getCell(`B${linhaIndicador}`).value = valor;
    sheet.getCell(`C${linhaIndicador}`).value = unidade;
    sheet.getCell(`A${linhaIndicador}`).font = { bold: true };
    if (unidade === "%") sheet.getCell(`B${linhaIndicador}`).numFmt = "0.00%";
    else if (["m", "m²"].includes(unidade)) sheet.getCell(`B${linhaIndicador}`).numFmt = "0.0000";
    linhaIndicador++;
  }

  const linhaAlertas = linhaIndicador + 2;
  sheet.getCell(`A${linhaAlertas}`).value = "PREMISSAS E ALERTAS";
  sheet.getCell(`A${linhaAlertas}`).font = { bold: true, size: 13, color: { argb: "FFB45309" } };
  let linhaAlerta = linhaAlertas + 2;
  for (const alerta of plano.alertas || []) {
    sheet.getCell(`A${linhaAlerta}`).value = `• ${alerta}`;
    sheet.mergeCells(`A${linhaAlerta}:F${linhaAlerta}`);
    sheet.getCell(`A${linhaAlerta}`).alignment = { wrapText: true, vertical: "top" };
    sheet.getRow(linhaAlerta).height = 32;
    linhaAlerta++;
  }
  return sheet;
}

function criarDetalhesChapas(workbook, plano) {
  const sheet = workbook.addWorksheet("Plano de corte", { views: [{ state: "frozen", ySplit: 1 }] });
  sheet.columns = [
    { header: "Chapa", key: "chapa", width: 10 },
    { header: "ID", key: "id", width: 20 },
    { header: "Peça", key: "nome", width: 42 },
    { header: "X (mm)", key: "x", width: 13 },
    { header: "Y (mm)", key: "y", width: 13 },
    { header: "Largura (mm)", key: "largura", width: 16 },
    { header: "Altura (mm)", key: "altura", width: 15 },
    { header: "Girou 90°", key: "girada", width: 13 },
    { header: "Veio", key: "veio", width: 14 },
    { header: "Área (m²)", key: "area", width: 14 }
  ];
  estilizarCabecalhoTabela(sheet.getRow(1));
  let linha = 2;
  for (const chapa of plano.chapas || []) {
    for (const peca of chapa.pecas || []) {
      sheet.getRow(linha).values = [chapa.indice, peca.id, peca.nome, peca.x, peca.y, peca.largura, peca.altura, peca.girada ? "Sim" : "Não", peca.veio, null];
      sheet.getCell(`J${linha}`).value = { formula: `F${linha}*G${linha}/1000000`, result: peca.largura * peca.altura / 1_000_000 };
      sheet.getCell(`J${linha}`).numFmt = "0.0000";
      sheet.getRow(linha).alignment = { vertical: "top", wrapText: true };
      linha++;
    }
  }
  sheet.autoFilter = { from: "A1", to: `J${Math.max(1, linha - 1)}` };

  const sobras = workbook.addWorksheet("Sobras reutilizáveis", { views: [{ state: "frozen", ySplit: 1 }] });
  sobras.columns = [
    { header: "Chapa", key: "chapa", width: 12 },
    { header: "ID", key: "id", width: 16 },
    { header: "X (mm)", key: "x", width: 14 },
    { header: "Y (mm)", key: "y", width: 14 },
    { header: "Largura (mm)", key: "largura", width: 18 },
    { header: "Altura (mm)", key: "altura", width: 17 },
    { header: "Área (m²)", key: "areaM2", width: 15 }
  ];
  estilizarCabecalhoTabela(sobras.getRow(1));
  for (const sobra of plano.sobrasReutilizaveis || []) sobras.addRow(sobra);
  sobras.getColumn("G").numFmt = "0.0000";
}

function criarDetalhesBarras(workbook, plano) {
  const sheet = workbook.addWorksheet("Plano de corte", { views: [{ state: "frozen", ySplit: 1 }] });
  sheet.columns = [
    { header: "Barra", key: "barra", width: 10 },
    { header: "ID", key: "id", width: 20 },
    { header: "Peça", key: "nome", width: 46 },
    { header: "Início (mm)", key: "inicio", width: 17 },
    { header: "Comprimento (mm)", key: "comprimento", width: 22 },
    { header: "Fim (mm)", key: "fim", width: 16 }
  ];
  estilizarCabecalhoTabela(sheet.getRow(1));
  let linha = 2;
  for (const barra of plano.barras || []) {
    for (const peca of barra.pecas || []) {
      sheet.getRow(linha).values = [barra.indice, peca.id, peca.nome, peca.inicio, peca.comprimento, null];
      sheet.getCell(`F${linha}`).value = { formula: `D${linha}+E${linha}`, result: peca.inicio + peca.comprimento };
      linha++;
    }
  }
  sheet.autoFilter = { from: "A1", to: `F${Math.max(1, linha - 1)}` };

  const sobras = workbook.addWorksheet("Sobras reutilizáveis", { views: [{ state: "frozen", ySplit: 1 }] });
  sobras.columns = [
    { header: "Barra", key: "barra", width: 14 },
    { header: "Comprimento restante (mm)", key: "comprimento", width: 30 }
  ];
  estilizarCabecalhoTabela(sobras.getRow(1));
  for (const sobra of plano.sobrasReutilizaveis || []) sobras.addRow(sobra);
}

export async function gerarPlanilhaPlanoCorte(plano = {}) {
  if (!["otimizacao_chapas_2d", "otimizacao_barras_1d"].includes(plano.tipo)) {
    throw new Error("Tipo de plano de corte não suportado.");
  }
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "Rasputim v5";
  workbook.created = new Date();
  workbook.calcProperties.fullCalcOnLoad = true;
  criarResumoPlanoCorte(workbook, plano);
  if (plano.tipo === "otimizacao_chapas_2d") criarDetalhesChapas(workbook, plano);
  else criarDetalhesBarras(workbook, plano);

  await fs.mkdir("./orcamentos", { recursive: true });
  const tipo = plano.tipo === "otimizacao_chapas_2d" ? "chapas" : "barras";
  const nome = nomeSeguro(plano.material || "material");
  const arquivo = path.resolve("./orcamentos", `plano_corte_${tipo}_${nome}_${Date.now()}.xlsx`);
  await workbook.xlsx.writeFile(arquivo);
  return arquivo;
}
