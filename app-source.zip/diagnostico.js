import fs from "node:fs";
import os from "node:os";

const itens = [
  ["Rasputim", "5.4.0"],
  ["Node.js", process.version],
  ["Windows/OS", `${os.platform()} ${os.release()} ${os.arch()}`],
  ["RAM total", `${(os.totalmem() / 1073741824).toFixed(1)} GB`],
  ["RAM livre", `${(os.freemem() / 1073741824).toFixed(1)} GB`],
  ["Processadores", String(os.cpus().length)],
  ["node_modules", fs.existsSync("node_modules") ? "OK" : "AUSENTE"],
  [".env", fs.existsSync(".env") ? "OK" : "AUSENTE"],
  ["server.js", fs.existsSync("server.js") ? "OK" : "AUSENTE"]
];

console.log("\nDIAGNOSTICO LOCAL DO RASPUTIM\n");
for (const [nome, valor] of itens) console.log(`${nome}: ${valor}`);
console.log("\nEste diagnostico nao executa PowerShell, nao baixa arquivos e nao altera o Windows.");
