import { CONFIG } from "./config.js";
import { AppError } from "./errors.js";
import { limitarNumero, texto } from "./utils.js";

const cache = new Map();
const CACHE_MS = 15 * 60 * 1000;

export function selecionarProvedor(preferido = CONFIG.searchProvider) {
  const serper = Boolean(process.env.SERPER_API_KEY);
  const brave = Boolean(process.env.BRAVE_API_KEY);

  if (preferido === "serper") {
    if (!serper) throw new AppError("SERPER_API_KEY não configurada.", { status: 503, code: "SEARCH_KEY_MISSING" });
    return "serper";
  }
  if (preferido === "brave") {
    if (!brave) throw new AppError("BRAVE_API_KEY não configurada.", { status: 503, code: "SEARCH_KEY_MISSING" });
    return "brave";
  }
  if (serper) return "serper";
  if (brave) return "brave";

  throw new AppError("Nenhuma API de pesquisa foi configurada.", {
    status: 503,
    code: "SEARCH_NOT_CONFIGURED",
    details: "Preencha SERPER_API_KEY ou BRAVE_API_KEY no arquivo .env."
  });
}

export function normalizarResultadosSerper(dados, modo = "web", limite = 5) {
  const origem = modo === "shopping" ? dados?.shopping : dados?.organic;
  return (Array.isArray(origem) ? origem : []).slice(0, limite).map((item, indice) => ({
    posicao: Number(item.position) || indice + 1,
    titulo: texto(item.title, 500),
    url: texto(item.link, 2000),
    resumo: texto(item.snippet || item.delivery || "", 1500),
    fornecedor: texto(item.source || "", 300) || null,
    precoExibido: texto(item.price || "", 100) || null,
    avaliacao: Number(item.rating) || null,
    avaliacoes: Number(item.ratingCount || item.reviews) || null,
    data: texto(item.date || "", 100) || null,
    tipo: modo,
    provedor: "serper"
  })).filter(item => item.titulo || item.url);
}

export function normalizarResultadosBrave(dados, limite = 5) {
  const origem = dados?.web?.results;
  return (Array.isArray(origem) ? origem : []).slice(0, limite).map((item, indice) => ({
    posicao: indice + 1,
    titulo: texto(item.title, 500),
    url: texto(item.url, 2000),
    resumo: texto(item.description, 1500),
    fornecedor: texto(item.profile?.long_name || item.profile?.name || "", 300) || null,
    precoExibido: null,
    avaliacao: null,
    avaliacoes: null,
    data: texto(item.age || item.page_age || "", 100) || null,
    tipo: "web",
    provedor: "brave"
  })).filter(item => item.titulo || item.url);
}

async function pesquisarSerper(consulta, { limite, modo, fetchImpl }) {
  const endpoint = modo === "shopping" ? "shopping" : "search";
  const resposta = await fetchImpl(`https://google.serper.dev/${endpoint}`, {
    method: "POST",
    headers: {
      "X-API-KEY": process.env.SERPER_API_KEY,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ q: consulta, gl: "br", hl: "pt-br", num: limite }),
    signal: AbortSignal.timeout(CONFIG.searchTimeoutMs)
  });

  if (!resposta.ok) {
    const detalhe = (await resposta.text()).slice(0, 1000);
    const code = resposta.status === 429 ? "SEARCH_QUOTA_EXCEEDED" : "SEARCH_HTTP_ERROR";
    throw new AppError(`A pesquisa Serper respondeu HTTP ${resposta.status}.`, {
      status: resposta.status === 429 ? 429 : 502,
      code,
      details: detalhe
    });
  }

  return normalizarResultadosSerper(await resposta.json(), modo, limite);
}

async function pesquisarBrave(consulta, { limite, fetchImpl }) {
  const url = new URL("https://api.search.brave.com/res/v1/web/search");
  url.searchParams.set("q", consulta);
  url.searchParams.set("count", String(limite));
  url.searchParams.set("country", "BR");
  url.searchParams.set("search_lang", "pt-br");
  url.searchParams.set("safesearch", "moderate");

  const resposta = await fetchImpl(url, {
    headers: {
      Accept: "application/json",
      "X-Subscription-Token": process.env.BRAVE_API_KEY
    },
    signal: AbortSignal.timeout(CONFIG.searchTimeoutMs)
  });

  if (!resposta.ok) {
    const detalhe = (await resposta.text()).slice(0, 1000);
    const code = resposta.status === 429 ? "SEARCH_QUOTA_EXCEEDED" : "SEARCH_HTTP_ERROR";
    throw new AppError(`A pesquisa Brave respondeu HTTP ${resposta.status}.`, {
      status: resposta.status === 429 ? 429 : 502,
      code,
      details: detalhe
    });
  }

  return normalizarResultadosBrave(await resposta.json(), limite);
}

export async function pesquisarWeb(consulta, opcoes = {}) {
  const query = texto(consulta, 500);
  if (!query) throw new AppError("Informe o que deve ser pesquisado.", { status: 400, code: "SEARCH_QUERY_EMPTY" });

  const limite = limitarNumero(opcoes.limite, CONFIG.searchMaxResults, 1, 10);
  const modoSolicitado = opcoes.modo === "shopping" ? "shopping" : "web";
  const preferencia = String(opcoes.provedor || CONFIG.searchProvider || "auto").toLowerCase();
  let provedor = selecionarProvedor(preferencia);
  let modo = provedor === "brave" ? "web" : modoSolicitado;
  const chaveCache = JSON.stringify({ provedor, modo, query: query.toLowerCase(), limite });
  const armazenado = cache.get(chaveCache);

  if (armazenado && Date.now() - armazenado.criadoEm < CACHE_MS) {
    return { ...armazenado.valor, cache: true };
  }

  const fetchImpl = opcoes.fetchImpl || fetch;
  let resultados;
  let fallbackDe = null;
  try {
    resultados = provedor === "serper"
      ? await pesquisarSerper(query, { limite, modo, fetchImpl })
      : await pesquisarBrave(query, { limite, fetchImpl });
  } catch (error) {
    const podeAlternar = preferencia === "auto" && process.env.SERPER_API_KEY && process.env.BRAVE_API_KEY;
    if (podeAlternar) {
      fallbackDe = provedor;
      provedor = provedor === "serper" ? "brave" : "serper";
      modo = provedor === "brave" ? "web" : modoSolicitado;
      try {
        resultados = provedor === "serper"
          ? await pesquisarSerper(query, { limite, modo, fetchImpl })
          : await pesquisarBrave(query, { limite, fetchImpl });
      } catch (fallbackError) {
        if (fallbackError instanceof AppError) throw fallbackError;
        throw new AppError("Os dois provedores de pesquisa falharam.", {
          status: 503,
          code: fallbackError?.cause?.code || fallbackError?.code || "SEARCH_NETWORK_ERROR",
          details: fallbackError.message
        });
      }
    } else {
      if (error instanceof AppError) throw error;
      throw new AppError("Falha de rede durante a pesquisa.", {
        status: 503,
        code: error?.cause?.code || error?.code || "SEARCH_NETWORK_ERROR",
        details: error.message
      });
    }
  }

  const valor = {
    consulta: query,
    provedor,
    modo,
    resultados,
    total: resultados.length,
    pesquisadoEm: new Date().toISOString(),
    fallbackDe,
    cache: false
  };
  const chaveFinal = JSON.stringify({ provedor, modo, query: query.toLowerCase(), limite });
  cache.set(chaveCache, { criadoEm: Date.now(), valor });
  cache.set(chaveFinal, { criadoEm: Date.now(), valor });
  return valor;
}

export function limparCachePesquisa() {
  cache.clear();
}
