import { CONFIG } from "./config.js";
import { AppError } from "./errors.js";
import { chamarModelo } from "./llama-client.js";
import { pesquisarWeb } from "./web-search.js";
import { lerFontes } from "./web-reader.js";
import { salvarPesquisa } from "./research-store.js";
import { extrairJSON, limitarNumero, texto } from "./utils.js";

function urlCanonica(valor) {
  try {
    const url = new URL(valor);
    url.hash = "";
    for (const parametro of [...url.searchParams.keys()]) {
      if (/^(utm_|gclid|fbclid)/i.test(parametro)) url.searchParams.delete(parametro);
    }
    return url.href.replace(/\/$/, "");
  } catch {
    return texto(valor, 2000);
  }
}

export function numeroPreco(valor) {
  if (typeof valor === "number") return Number.isFinite(valor) && valor >= 0 ? valor : null;
  const bruto = texto(valor, 100).replace(/[^\d,.-]/g, "");
  if (!bruto) return null;

  let normalizado = bruto;
  const ultimaVirgula = bruto.lastIndexOf(",");
  const ultimoPonto = bruto.lastIndexOf(".");

  if (ultimaVirgula >= 0 && ultimoPonto >= 0) {
    const decimal = ultimaVirgula > ultimoPonto ? "," : ".";
    const milhar = decimal === "," ? "." : ",";
    normalizado = bruto.split(milhar).join("");
    if (decimal === ",") normalizado = normalizado.replace(",", ".");
  } else {
    const separador = ultimaVirgula >= 0 ? "," : ultimoPonto >= 0 ? "." : null;
    if (separador) {
      const partes = bruto.split(separador);
      const casasFinais = partes.at(-1).length;
      const pareceMilhar = casasFinais === 3 && partes.slice(1).every(parte => parte.length === 3);
      if (pareceMilhar) normalizado = partes.join("");
      else {
        const inteiro = partes.slice(0, -1).join("");
        normalizado = `${inteiro}.${partes.at(-1)}`;
      }
    }
  }

  const numero = Number(normalizado);
  return Number.isFinite(numero) && numero >= 0 ? numero : null;
}

function precosExplicitamentePresentes(fonte) {
  const candidatos = [];
  if (fonte.precoExibido) candidatos.push(numeroPreco(fonte.precoExibido));

  const conteudo = `${fonte.resumo || ""} ${fonte.conteudo || ""}`;
  const expressoes = conteudo.match(/(?:R\$|BRL)\s*\d[\d.,]*(?:\s*(?:à vista|no pix))?/gi) || [];
  for (const expressao of expressoes.slice(0, 100)) candidatos.push(numeroPreco(expressao));
  return candidatos.filter(valor => valor != null);
}

function precoSustentadoPelaFonte(preco, fonte) {
  if (preco == null) return false;
  return precosExplicitamentePresentes(fonte).some(candidato =>
    Math.abs(candidato - preco) <= Math.max(0.02, Math.abs(preco) * 0.001)
  );
}

function deduplicarResultados(resultados) {
  const mapa = new Map();
  for (const resultado of resultados) {
    const chave = urlCanonica(resultado.url) || `${resultado.titulo}|${resultado.fornecedor}`;
    const anterior = mapa.get(chave);
    if (!anterior || (!anterior.precoExibido && resultado.precoExibido)) mapa.set(chave, resultado);
  }
  return [...mapa.values()];
}

function criarFontes(resultados, paginas) {
  const paginaPorUrl = new Map();
  for (const pagina of paginas) {
    paginaPorUrl.set(urlCanonica(pagina.urlOriginal || pagina.url), pagina);
    paginaPorUrl.set(urlCanonica(pagina.url), pagina);
  }
  return resultados.map((resultado, indice) => {
    const pagina = paginaPorUrl.get(urlCanonica(resultado.url));
    return {
      id: `F${indice + 1}`,
      titulo: resultado.titulo,
      url: resultado.url,
      fornecedor: resultado.fornecedor,
      precoExibido: resultado.precoExibido,
      resumo: resultado.resumo,
      conteudo: pagina?.texto || resultado.resumo || "",
      leitura: pagina?.status || "resultado_busca",
      pesquisadoEm: new Date().toISOString()
    };
  });
}

function promptPesquisa({ consulta, regiao, quantidade, unidade, fontes }) {
  const fontesTexto = fontes.map(fonte => [
    `[${fonte.id}]`,
    `Título: ${fonte.titulo}`,
    `Fornecedor informado: ${fonte.fornecedor || "não identificado"}`,
    `Preço exibido pela busca: ${fonte.precoExibido || "não informado"}`,
    `URL exata: ${fonte.url}`,
    `Trecho coletado: ${fonte.conteudo}`
  ].join("\n")).join("\n\n");

  return `
Faça uma pesquisa de mercado baseada EXCLUSIVAMENTE nas fontes fornecidas.

Produto ou material: ${consulta}
Região: ${regiao || "Brasil"}
Quantidade pretendida: ${quantidade || "não informada"}
Unidade pretendida: ${unidade || "não informada"}
Data da coleta: ${new Date().toISOString()}

Regras obrigatórias:
- Não invente fornecedor, preço, frete, estoque ou URL.
- Toda oferta deve usar exatamente um fonteId existente, como F1.
- Se o preço não estiver explícito, use null.
- Não transforme parcelamento em preço à vista.
- Informe quando produtos não forem diretamente comparáveis.
- Considere diferença de unidade, medida, espessura, marca, acabamento e região.
- Responda somente com JSON válido, sem Markdown.

Formato obrigatório:
{
  "resumo": "texto curto",
  "produto": "material identificado",
  "especificacoes": ["especificação considerada"],
  "ofertas": [
    {
      "fonteId": "F1",
      "fornecedor": "nome ou null",
      "descricao": "descrição",
      "preco": 0.0,
      "unidade": "unidade ou null",
      "frete": null,
      "disponibilidade": "informação explícita ou não informada",
      "evidencia": "trecho curto que sustenta a oferta",
      "confianca": "alta, media ou baixa"
    }
  ],
  "melhorOfertaFonteId": "F1 ou null",
  "alertas": ["alerta"],
  "conclusao": "conclusão"
}

Fontes:
${fontesTexto}
`.trim();
}

function relatorioDeterministico({ consulta, fontes, motivo }) {
  const ofertas = fontes
    .filter(fonte => fonte.precoExibido)
    .map(fonte => ({
      fonteId: fonte.id,
      fornecedor: fonte.fornecedor,
      descricao: fonte.titulo,
      preco: numeroPreco(fonte.precoExibido),
      unidade: null,
      frete: null,
      disponibilidade: "não informada",
      evidencia: fonte.precoExibido,
      confianca: "baixa"
    }));

  return {
    resumo: "Resultados coletados, mas a análise estruturada do modelo não pôde ser concluída.",
    produto: consulta,
    especificacoes: [],
    ofertas,
    melhorOfertaFonteId: null,
    alertas: [motivo, "Confirme preços, unidade, frete e disponibilidade diretamente no fornecedor."],
    conclusao: "Os resultados brutos foram preservados para conferência manual."
  };
}

export function validarAnaliseModelo(analise, fontes) {
  const mapaFontes = new Map(fontes.map(fonte => [fonte.id, fonte]));
  let precosDescartados = 0;
  const ofertas = (Array.isArray(analise?.ofertas) ? analise.ofertas : [])
    .filter(oferta => mapaFontes.has(oferta?.fonteId))
    .map(oferta => {
      const fonte = mapaFontes.get(oferta.fonteId);
      const confianca = ["alta", "media", "baixa"].includes(oferta.confianca) ? oferta.confianca : "baixa";
      const precoProposto = numeroPreco(oferta.preco);
      const precoVerificado = precoSustentadoPelaFonte(precoProposto, fonte);
      if (precoProposto != null && !precoVerificado) precosDescartados++;
      return {
        fonteId: oferta.fonteId,
        fornecedor: texto(oferta.fornecedor || fonte.fornecedor, 300) || null,
        descricao: texto(oferta.descricao || fonte.titulo, 700),
        preco: precoVerificado ? precoProposto : null,
        precoVerificado,
        unidade: texto(oferta.unidade, 100) || null,
        frete: numeroPreco(oferta.frete),
        disponibilidade: texto(oferta.disponibilidade, 300) || "não informada",
        evidencia: texto(oferta.evidencia, 700),
        confianca: precoProposto != null && !precoVerificado ? "baixa" : confianca,
        url: fonte.url,
        tituloFonte: fonte.titulo
      };
    });

  const melhorValida = ofertas.some(oferta => oferta.fonteId === analise?.melhorOfertaFonteId && oferta.preco != null)
    ? analise.melhorOfertaFonteId
    : null;

  return {
    resumo: texto(analise?.resumo, 2000),
    produto: texto(analise?.produto, 500),
    especificacoes: (Array.isArray(analise?.especificacoes) ? analise.especificacoes : []).map(v => texto(v, 500)).filter(Boolean).slice(0, 30),
    ofertas,
    melhorOfertaFonteId: melhorValida,
    alertas: [
      ...(Array.isArray(analise?.alertas) ? analise.alertas : []).map(v => texto(v, 700)).filter(Boolean),
      ...(precosDescartados ? [`${precosDescartados} preço(s) sugerido(s) pelo modelo foram descartados por não aparecerem explicitamente na fonte.`] : [])
    ].slice(0, 30),
    conclusao: texto(analise?.conclusao, 3000)
  };
}

export async function executarPesquisaMercado(entrada = {}) {
  const consulta = texto(entrada.consulta || entrada.material || entrada.produto, 500);
  if (!consulta) throw new Error("Informe o material ou produto no campo 'consulta'.");

  const regiao = texto(entrada.regiao || entrada.cidade || "Brasil", 200);
  const quantidade = limitarNumero(entrada.quantidade, null, 0, 1_000_000);
  const unidade = texto(entrada.unidade, 100) || null;
  const limite = limitarNumero(entrada.limite, CONFIG.searchMaxResults, 2, 10);
  const query = `${consulta} preço fornecedor ${regiao}`.trim();

  const web = await pesquisarWeb(query, { limite, modo: "web" });
  let shopping = { resultados: [] };
  if (web.provedor === "serper") {
    try {
      shopping = await pesquisarWeb(`${consulta} ${regiao}`.trim(), { limite, modo: "shopping", provedor: "serper" });
    } catch {
      shopping = { resultados: [] };
    }
  }

  const resultados = deduplicarResultados([...shopping.resultados, ...web.resultados]).slice(0, limite * 2);
  if (!resultados.length) {
    throw new AppError("Nenhuma fonte foi encontrada para esta consulta. Tente incluir marca, medida, região e unidade.", {
      status: 404,
      code: "SEARCH_NO_RESULTS"
    });
  }
  const paginas = await lerFontes(resultados.filter(item => item.tipo === "web"), CONFIG.searchMaxPages);
  const fontes = criarFontes(resultados, paginas);

  let analise;
  try {
    const resposta = await chamarModelo([
      {
        role: "system",
        content: "Você é um analista de compras e materiais. Trabalhe somente com evidências fornecidas. /no_think"
      },
      { role: "user", content: promptPesquisa({ consulta, regiao, quantidade, unidade, fontes }) }
    ], {
      maxTokens: CONFIG.researchMaxTokens,
      temperature: 0.15,
      responseFormat: "json"
    });
    analise = validarAnaliseModelo(extrairJSON(resposta), fontes);
  } catch (error) {
    analise = validarAnaliseModelo(relatorioDeterministico({
      consulta,
      fontes,
      motivo: `Análise automática indisponível: ${error.code || error.message}`
    }), fontes);
  }

  const relatorio = {
    id: crypto.randomUUID(),
    tipo: "pesquisa_mercado_material",
    consulta,
    regiao,
    quantidade,
    unidade,
    coletadoEm: new Date().toISOString(),
    provedorPesquisa: web.provedor,
    ...analise,
    fontes
  };

  const salvo = await salvarPesquisa(relatorio);
  return { ...relatorio, arquivoPesquisa: salvo.nome };
}
